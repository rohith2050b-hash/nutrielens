-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "guestKey" TEXT NOT NULL,
    "displayName" TEXT NOT NULL DEFAULT 'Campus Guest',
    "weightKg" REAL NOT NULL DEFAULT 65.0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Snack" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "servingSizeGrams" REAL NOT NULL,
    "servingUnit" TEXT NOT NULL DEFAULT 'g',
    "servingLabel" TEXT NOT NULL,
    "isHealthyAlternative" BOOLEAN NOT NULL DEFAULT false,
    "texture" TEXT NOT NULL,
    "tasteProfile" TEXT NOT NULL,
    "priceInrMin" INTEGER NOT NULL,
    "priceInrMax" INTEGER NOT NULL,
    "availability" TEXT NOT NULL,
    "imageUrl" TEXT NOT NULL,
    "barcode" TEXT,
    "dataSource" TEXT NOT NULL,
    "verificationStatus" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "NutritionalProfile" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "snackId" TEXT NOT NULL,
    "calories" REAL NOT NULL,
    "totalFat" REAL NOT NULL,
    "saturatedFat" REAL NOT NULL,
    "carbohydrates" REAL NOT NULL,
    "sugar" REAL NOT NULL,
    "protein" REAL NOT NULL,
    "fiber" REAL NOT NULL,
    "sodium" REAL NOT NULL,
    "healthGrade" TEXT NOT NULL,
    "gradeScore" INTEGER NOT NULL,
    "isBeverage" BOOLEAN NOT NULL DEFAULT false,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "NutritionalProfile_snackId_fkey" FOREIGN KEY ("snackId") REFERENCES "Snack" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "SwapRule" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "fromSnackId" TEXT NOT NULL,
    "toSnackId" TEXT NOT NULL,
    "rationale" TEXT NOT NULL,
    "priorityBoost" REAL NOT NULL DEFAULT 0.15,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "SwapRule_fromSnackId_fkey" FOREIGN KEY ("fromSnackId") REFERENCES "Snack" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "SwapRule_toSnackId_fkey" FOREIGN KEY ("toSnackId") REFERENCES "Snack" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "UserSwapLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "originalSnackId" TEXT NOT NULL,
    "replacementSnackId" TEXT NOT NULL,
    "basis" TEXT NOT NULL DEFAULT 'serving',
    "caloriesSaved" REAL NOT NULL,
    "sugarReduced" REAL NOT NULL,
    "sodiumReduced" REAL NOT NULL,
    "saturatedFatReduced" REAL NOT NULL,
    "proteinGained" REAL NOT NULL,
    "fiberGained" REAL NOT NULL,
    "swappedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "UserSwapLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "UserSwapLog_originalSnackId_fkey" FOREIGN KEY ("originalSnackId") REFERENCES "Snack" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "UserSwapLog_replacementSnackId_fkey" FOREIGN KEY ("replacementSnackId") REFERENCES "Snack" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "WeeklyChallenge" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "targetDays" INTEGER NOT NULL DEFAULT 7,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "ChallengeProgress" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "challengeId" TEXT NOT NULL,
    "dayNumber" INTEGER NOT NULL,
    "completedDate" TEXT NOT NULL,
    "swapLogId" TEXT,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ChallengeProgress_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ChallengeProgress_challengeId_fkey" FOREIGN KEY ("challengeId") REFERENCES "WeeklyChallenge" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Achievement" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "code" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "criteria" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "UserAchievement" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "achievementId" TEXT NOT NULL,
    "unlockedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "UserAchievement_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "UserAchievement_achievementId_fkey" FOREIGN KEY ("achievementId") REFERENCES "Achievement" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "HostelHack" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "approxCostInr" TEXT NOT NULL,
    "prepTimeMinutes" INTEGER NOT NULL,
    "equipmentNeeded" TEXT NOT NULL,
    "ingredients" TEXT NOT NULL,
    "instructions" TEXT NOT NULL,
    "practicalWhy" TEXT NOT NULL,
    "caloriesPerServing" REAL NOT NULL,
    "proteinPerServing" REAL NOT NULL,
    "fiberPerServing" REAL NOT NULL,
    "sugarPerServing" REAL NOT NULL,
    "linkedSnackSlug" TEXT,
    "imageUrl" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE UNIQUE INDEX "User_guestKey_key" ON "User"("guestKey");

-- CreateIndex
CREATE UNIQUE INDEX "Snack_slug_key" ON "Snack"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "Snack_barcode_key" ON "Snack"("barcode");

-- CreateIndex
CREATE INDEX "Snack_category_idx" ON "Snack"("category");

-- CreateIndex
CREATE INDEX "Snack_isHealthyAlternative_idx" ON "Snack"("isHealthyAlternative");

-- CreateIndex
CREATE INDEX "Snack_name_idx" ON "Snack"("name");

-- CreateIndex
CREATE UNIQUE INDEX "NutritionalProfile_snackId_key" ON "NutritionalProfile"("snackId");

-- CreateIndex
CREATE INDEX "NutritionalProfile_healthGrade_idx" ON "NutritionalProfile"("healthGrade");

-- CreateIndex
CREATE INDEX "NutritionalProfile_calories_idx" ON "NutritionalProfile"("calories");

-- CreateIndex
CREATE INDEX "SwapRule_fromSnackId_idx" ON "SwapRule"("fromSnackId");

-- CreateIndex
CREATE UNIQUE INDEX "SwapRule_fromSnackId_toSnackId_key" ON "SwapRule"("fromSnackId", "toSnackId");

-- CreateIndex
CREATE INDEX "UserSwapLog_userId_swappedAt_idx" ON "UserSwapLog"("userId", "swappedAt");

-- CreateIndex
CREATE INDEX "ChallengeProgress_userId_challengeId_idx" ON "ChallengeProgress"("userId", "challengeId");

-- CreateIndex
CREATE UNIQUE INDEX "ChallengeProgress_userId_challengeId_dayNumber_key" ON "ChallengeProgress"("userId", "challengeId", "dayNumber");

-- CreateIndex
CREATE UNIQUE INDEX "Achievement_code_key" ON "Achievement"("code");

-- CreateIndex
CREATE UNIQUE INDEX "UserAchievement_userId_achievementId_key" ON "UserAchievement"("userId", "achievementId");

-- CreateIndex
CREATE UNIQUE INDEX "HostelHack_slug_key" ON "HostelHack"("slug");
