import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import { LandingLayout, WorkspaceLayout } from './components/Layout.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ExplorerPage } from './pages/ExplorerPage.tsx';
import { SnackDetailPage } from './pages/SnackDetailPage.tsx';
import { ComparePage } from './pages/ComparePage.tsx';
import { RecommendationsPage } from './pages/RecommendationsPage.tsx';
import { SwapsPage } from './pages/SwapsPage.tsx';
import { ChallengePage } from './pages/ChallengePage.tsx';
import { ScannerPage } from './pages/ScannerPage.tsx';
import { HostelHacksPage } from './pages/HostelHacksPage.tsx';
import { MethodologyPage } from './pages/MethodologyPage.tsx';

function NotFoundPage() {
  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-10 text-center space-y-3">
      <h1 className="text-xl font-bold text-neutral-900">Page Not Found</h1>
      <p className="text-sm text-neutral-600">
        The route you visited does not exist in NutriLens.
      </p>
      <Link
        to="/"
        className="inline-block px-4 py-2 text-sm font-semibold text-white bg-[#14532D] rounded-lg"
      >
        Return Home
      </Link>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <LandingLayout>
              <LandingPage />
            </LandingLayout>
          }
        />
        <Route
          path="/dashboard"
          element={
            <WorkspaceLayout>
              <DashboardPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/snacks"
          element={
            <WorkspaceLayout>
              <ExplorerPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/snacks/:id"
          element={
            <WorkspaceLayout>
              <SnackDetailPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/compare"
          element={
            <WorkspaceLayout>
              <ComparePage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/recommendations"
          element={
            <WorkspaceLayout>
              <RecommendationsPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/swaps"
          element={
            <WorkspaceLayout>
              <SwapsPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/challenge"
          element={
            <WorkspaceLayout>
              <ChallengePage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/scanner"
          element={
            <WorkspaceLayout>
              <ScannerPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/hostel-hacks"
          element={
            <WorkspaceLayout>
              <HostelHacksPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="/methodology"
          element={
            <WorkspaceLayout>
              <MethodologyPage />
            </WorkspaceLayout>
          }
        />
        <Route
          path="*"
          element={
            <WorkspaceLayout>
              <NotFoundPage />
            </WorkspaceLayout>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
