import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, Compass, Flame, History, Scale } from 'lucide-react';
import { api } from '../services/api.ts';
import { DashboardData } from '../types/index.ts';
import { GradeBadge } from '../components/GradeBadge.tsx';
import { SwapHistoryChart } from '../components/SwapHistoryChart.tsx';

export function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api
      .getDashboard()
      .then((res) => {
        if (active) setData(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Failed to load dashboard.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-24 rounded-xl border border-neutral-200 bg-white animate-pulse" />
          ))}
        </div>
        <div className="h-72 rounded-xl border border-neutral-200 bg-white animate-pulse" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-900">
        {error || 'Dashboard data unavailable.'}
      </div>
    );
  }

  const { catalogStats, swapSummary, recentSwaps, weeklyProgress, challengeSummary, recommendedAlternatives } = data;
  const hasSwaps = swapSummary.totalSwaps > 0;

  const kpis = [
    {
      label: 'Snacks in Catalog',
      value: String(catalogStats.totalSnacks),
      sub: `${catalogStats.healthyAlternatives} healthy · ${catalogStats.commonSnacks} common`,
    },
    {
      label: 'Swaps Completed',
      value: String(swapSummary.totalSwaps),
      sub: hasSwaps ? 'Logged to database' : 'No swaps logged yet',
    },
    {
      label: 'Calories Saved',
      value: `${swapSummary.caloriesSaved} kcal`,
      sub: 'Cumulative difference',
    },
    {
      label: 'Sugar Saved',
      value: `${swapSummary.sugarReduced}g`,
      sub: `${(swapSummary.sugarReduced / 4).toFixed(1)} sugar cubes (4g)`,
    },
    {
      label: 'Sodium Saved',
      value: `${swapSummary.sodiumReduced} mg`,
      sub: 'Cumulative difference',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            Nutrition &amp; Swap Dashboard
          </h1>
          <p className="text-sm text-neutral-600 mt-0.5">
            Real-time nutritional aggregates computed from your recorded snack swaps and active challenge.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/snacks"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-neutral-800 bg-white border border-neutral-300 hover:bg-neutral-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <Compass className="w-4 h-4" />
            <span>Explore Snacks</span>
          </Link>
          <Link
            to="/compare?a=potato-chips&b=roasted-salted-makhana"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap"
          >
            <Scale className="w-4 h-4" />
            <span>Compare &amp; Log Swap</span>
          </Link>
        </div>
      </div>

      {/* Top KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="rounded-xl border border-neutral-200 bg-white p-4">
            <div className="text-xs font-medium text-neutral-500">{kpi.label}</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-1">
              {kpi.value}
            </div>
            <div className="text-xs text-neutral-500 mt-1">{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Weekly Progress & Challenge Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="text-base font-bold text-neutral-900">Weekly Calorie Savings Progress</h2>
              <p className="text-xs text-neutral-500">Calculated directly from recorded swap timestamps</p>
            </div>
            <Link to="/swaps" className="text-xs font-semibold text-[#14532D] hover:underline">
              View Full History
            </Link>
          </div>

          {weeklyProgress.length === 0 ? (
            <div className="h-[220px] flex flex-col items-center justify-center rounded-lg border border-dashed border-neutral-200 bg-neutral-50/70 p-6 text-center">
              <History className="w-7 h-7 text-neutral-400 mb-2" />
              <div className="text-sm font-semibold text-neutral-800">No swap activity recorded yet</div>
              <p className="text-xs text-neutral-500 mt-1 max-w-sm">
                Compare two snacks and click &ldquo;I Swapped This!&rdquo; to populate your daily savings chart.
              </p>
              <Link
                to="/snacks?q=Potato+Chips"
                className="mt-4 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors"
              >
                Start With Potato Chips
              </Link>
            </div>
          ) : (
            <SwapHistoryChart buckets={weeklyProgress} />
          )}
        </div>

        <div className="lg:col-span-5 rounded-xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#14532D]" />
                <h2 className="text-base font-bold text-neutral-900">Weekly Challenge</h2>
              </div>
              <span className="text-xs font-mono font-semibold text-[#14532D] tabular-nums">
                {challengeSummary.completedCount} / {challengeSummary.targetDays} days
              </span>
            </div>
            <p className="text-xs text-neutral-600">{challengeSummary.title}</p>

            <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden mt-3">
              <div
                className="h-full bg-[#14532D] transition-all"
                style={{ width: `${challengeSummary.completionPercent}%` }}
              />
            </div>

            <div className="grid grid-cols-7 gap-2 mt-4">
              {challengeSummary.days.map((d) => (
                <div
                  key={d.dayNumber}
                  className={`rounded-lg border py-2 text-center text-xs font-mono tabular-nums ${
                    d.completed
                      ? 'border-[#14532D] bg-[#14532D]/10 text-[#14532D] font-bold'
                      : 'border-neutral-200 bg-neutral-50 text-neutral-500'
                  }`}
                >
                  D{d.dayNumber}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-neutral-700">
              <Flame className="w-4 h-4 text-[#C2410C]" />
              <span>
                Streak: <strong className="font-mono tabular-nums">{challengeSummary.streak} days</strong> ·{' '}
                Badges: <strong className="font-mono tabular-nums">{challengeSummary.unlockedBadgesCount}/{challengeSummary.totalBadgesCount}</strong>
              </span>
            </div>
            <Link to="/challenge" className="font-semibold text-[#14532D] hover:underline">
              Open Challenge
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Swaps & Recommended Healthy Alternatives */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-neutral-900">Recent Snack Swaps</h2>
            {hasSwaps && (
              <Link to="/swaps" className="text-xs font-semibold text-[#14532D] hover:underline">
                Manage All ({swapSummary.totalSwaps})
              </Link>
            )}
          </div>

          {!hasSwaps ? (
            <div className="rounded-lg border border-dashed border-neutral-200 bg-neutral-50/60 p-6 text-center">
              <p className="text-sm font-medium text-neutral-800">
                Your swap log is currently empty.
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                Every swap you log automatically calculates calorie, sugar, sodium, and saturated fat savings.
              </p>
              <Link
                to="/compare?a=potato-chips&b=roasted-salted-makhana"
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg"
              >
                <span>Log First Swap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {recentSwaps.map((log) => (
                <div key={log.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-neutral-900">
                      {log.originalSnack.name} <span className="text-neutral-400 mx-1">→</span>{' '}
                      <span className="text-[#14532D]">{log.replacementSnack.name}</span>
                    </div>
                    <div className="text-xs text-neutral-500 mt-0.5 tabular-nums">
                      {new Date(log.swappedAt).toLocaleString()} · Basis: {log.basis === 'serving' ? 'Per Serving' : 'Per 100g/ml'}
                    </div>
                  </div>
                  <div className="text-right font-mono text-xs tabular-nums">
                    <div className="font-semibold text-[#14532D]">
                      {log.caloriesSaved >= 0 ? `${Math.round(log.caloriesSaved)} kcal saved` : `${Math.abs(Math.round(log.caloriesSaved))} kcal more`}
                    </div>
                    <div className="text-neutral-500">
                      {log.sodiumReduced}mg Na · {log.sugarReduced}g sugar
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-5 rounded-xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-neutral-900">Top-Rated Healthy Alternatives</h2>
            <Link to="/snacks?healthyOnly=true" className="text-xs font-semibold text-[#14532D] hover:underline">
              See All
            </Link>
          </div>
          <div className="space-y-3">
            {recommendedAlternatives.map((snack) => (
              <Link
                key={snack.id}
                to={`/snacks/${snack.slug}`}
                className="flex items-center justify-between gap-3 p-3 rounded-lg border border-neutral-200 hover:border-[#14532D]/40 hover:bg-neutral-50 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-neutral-900 truncate">{snack.name}</div>
                  <div className="text-xs text-neutral-500 mt-0.5 truncate">
                    {snack.category} · ₹{snack.priceInrMin}–₹{snack.priceInrMax} · {snack.availability}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-xs font-mono tabular-nums text-neutral-700">
                    {snack.nutrition?.calories} kcal
                  </span>
                  <GradeBadge grade={snack.nutrition?.healthGrade ?? 'A'} size="sm" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
