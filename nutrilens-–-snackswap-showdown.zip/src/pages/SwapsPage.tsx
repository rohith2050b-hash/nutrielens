import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Trash2 } from 'lucide-react';
import { api } from '../services/api.ts';
import { ComparisonBasis, HistoryBucket, Snack, SwapLogEntry, SwapSummary } from '../types/index.ts';
import { SwapHistoryChart } from '../components/SwapHistoryChart.tsx';

export function SwapsPage() {
  const [summary, setSummary] = useState<SwapSummary | null>(null);
  const [logs, setLogs] = useState<SwapLogEntry[]>([]);
  const [history, setHistory] = useState<{
    daily: HistoryBucket[];
    weekly: HistoryBucket[];
    monthly: HistoryBucket[];
  }>({ daily: [], weekly: [], monthly: [] });
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Quick Log Swap Form State
  const [snacks, setSnacks] = useState<Snack[]>([]);
  const [origId, setOrigId] = useState('potato-chips');
  const [replId, setReplId] = useState('roasted-salted-makhana');
  const [basis, setBasis] = useState<ComparisonBasis>('serving');
  const [submitting, setSubmitting] = useState(false);
  const [formMsg, setFormMsg] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [swapRes, snacksRes] = await Promise.all([
        api.getSwaps(),
        snacks.length === 0 ? api.searchSnacks({ limit: 100 }) : Promise.resolve(null),
      ]);
      setSummary(swapRes.summary);
      setLogs(swapRes.logs);
      setHistory(swapRes.history);
      if (snacksRes) setSnacks(snacksRes.items);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load swap history.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogNewSwap = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFormMsg(null);
    try {
      await api.recordSwap({
        originalSnackId: origId,
        replacementSnackId: replId,
        basis,
      });
      setFormMsg('Swap logged successfully.');
      await loadData();
    } catch (err) {
      setFormMsg(err instanceof Error ? err.message : 'Could not log swap.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUndo = async (id: string) => {
    try {
      await api.deleteSwap(id);
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete swap.');
    }
  };

  const activeBuckets = history[period];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
          My Snack Swaps Tracker
        </h1>
        <p className="text-sm text-neutral-600 mt-0.5">
          Every recorded swap is stored in SQLite and aggregated across daily, weekly, and monthly timelines.
        </p>
      </div>

      {/* Cumulative KPI Strip */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { label: 'Total Swaps', val: String(summary.totalSwaps) },
            { label: 'Calories Saved', val: `${summary.caloriesSaved} kcal` },
            { label: 'Sugar Reduced', val: `${summary.sugarReduced}g` },
            { label: 'Sodium Reduced', val: `${summary.sodiumReduced} mg` },
            { label: 'Sat. Fat Reduced', val: `${summary.saturatedFatReduced}g` },
            { label: 'Protein Gained', val: `+${summary.proteinGained}g` },
          ].map((k) => (
            <div key={k.label} className="rounded-xl border border-neutral-200 bg-white p-4">
              <div className="text-xs text-neutral-500">{k.label}</div>
              <div className="text-lg font-bold font-mono tabular-nums text-neutral-900 mt-1">
                {k.val}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Quick Log Form + Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleLogNewSwap}
          className="lg:col-span-5 rounded-xl border border-neutral-200 bg-white p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-[#14532D]" />
            <h2 className="text-base font-bold text-neutral-900">Log a Snack Swap</h2>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Replaced Snack</label>
            <select
              value={origId}
              onChange={(e) => setOrigId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white"
            >
              {snacks.map((s) => (
                <option key={s.id} value={s.slug}>
                  {s.name} ({s.nutrition?.healthGrade})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Chosen Alternative</label>
            <select
              value={replId}
              onChange={(e) => setReplId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white"
            >
              {snacks.map((s) => (
                <option key={s.id} value={s.slug}>
                  {s.name} ({s.nutrition?.healthGrade})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Calculation Basis</label>
            <div className="inline-flex p-1 bg-neutral-100 rounded-lg text-xs">
              {(['serving', '100g'] as const).map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBasis(b)}
                  className={`px-3 py-1 rounded-md font-medium ${
                    basis === b ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
                  }`}
                >
                  {b === 'serving' ? 'Per Serving' : 'Per 100g/ml'}
                </button>
              ))}
            </div>
          </div>

          {formMsg && <p className="text-xs font-medium text-[#14532D]">{formMsg}</p>}

          <button
            type="submit"
            disabled={submitting || origId === replId}
            className="w-full px-4 py-2.5 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-50 rounded-lg transition-colors"
          >
            {submitting ? 'Logging...' : 'I Swapped This!'}
          </button>
        </form>

        <div className="lg:col-span-7 rounded-xl border border-neutral-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h2 className="text-base font-bold text-neutral-900">Savings Timeline</h2>
            <div className="inline-flex p-1 bg-neutral-100 rounded-lg text-xs">
              {(['daily', 'weekly', 'monthly'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPeriod(p)}
                  className={`px-2.5 py-1 rounded-md font-medium capitalize ${
                    period === p ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {activeBuckets.length === 0 ? (
            <div className="h-[220px] flex items-center justify-center rounded-lg border border-dashed border-neutral-200 bg-neutral-50 text-xs text-neutral-500">
              Log your first swap to view {period} savings progress.
            </div>
          ) : (
            <SwapHistoryChart buckets={activeBuckets} />
          )}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900">
          {error}
        </div>
      )}

      {/* History Table */}
      <div className="rounded-xl border border-neutral-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-base font-bold text-neutral-900">Recorded Swap History</h2>
          <span className="text-xs text-neutral-500 font-mono tabular-nums">{logs.length} entries</span>
        </div>

        {loading ? (
          <div className="p-6 text-sm text-neutral-500">Loading history...</div>
        ) : logs.length === 0 ? (
          <div className="p-8 text-center text-sm text-neutral-600">
            No snack swaps logged yet. Use the form above or visit{' '}
            <Link to="/compare" className="text-[#14532D] font-semibold underline">
              Compare Snacks
            </Link>
            .
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-neutral-50 border-b border-neutral-200 text-xs text-neutral-600">
                <tr>
                  <th className="text-left font-semibold px-5 py-3">Date &amp; Time</th>
                  <th className="text-left font-semibold px-4 py-3">Swap</th>
                  <th className="text-right font-semibold px-4 py-3">Calories</th>
                  <th className="text-right font-semibold px-4 py-3">Sugar</th>
                  <th className="text-right font-semibold px-4 py-3">Sodium</th>
                  <th className="text-right font-semibold px-4 py-3">Protein</th>
                  <th className="text-right font-semibold px-5 py-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-neutral-50/70">
                    <td className="px-5 py-3 text-xs text-neutral-500 font-mono tabular-nums whitespace-nowrap">
                      {new Date(log.swappedAt).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-medium text-neutral-900">{log.originalSnack.name}</span>
                      <span className="text-neutral-400 mx-1.5">→</span>
                      <span className="font-semibold text-[#14532D]">{log.replacementSnack.name}</span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-800">
                      {Math.round(log.caloriesSaved)} kcal
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-800">
                      {log.sugarReduced}g
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-800">
                      {Math.round(log.sodiumReduced)}mg
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-[#14532D]">
                      {log.proteinGained >= 0 ? `+${log.proteinGained}g` : `${log.proteinGained}g`}
                    </td>
                    <td className="px-5 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => handleUndo(log.id)}
                        title="Undo / Delete swap"
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 rounded-md border border-transparent hover:border-red-200 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Undo</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
