import { useEffect, useState } from 'react';
import { Award, CheckCircle2, Flame, Lock } from 'lucide-react';
import { api } from '../services/api.ts';
import { ChallengeOverview } from '../types/index.ts';

export function ChallengePage() {
  const [data, setData] = useState<ChallengeOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [submittingDay, setSubmittingDay] = useState<number | null>(null);
  const [noteInput, setNoteInput] = useState('');
  const [banner, setBanner] = useState<string | null>(null);

  const loadChallenge = async () => {
    setLoading(true);
    try {
      const res = await api.getChallenges();
      setData(res);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadChallenge();
  }, []);

  const handleMarkDay = async (dayNumber: number) => {
    if (!data) return;
    setSubmittingDay(dayNumber);
    setBanner(null);
    try {
      const res = await api.recordChallengeProgress(data.challenge.id, {
        dayNumber,
        notes: noteInput.trim() || `Completed Day ${dayNumber} healthy snack swap.`,
      });
      setNoteInput('');
      if (res.newlyUnlockedAchievements.length > 0) {
        setBanner(
          `Day ${dayNumber} completed! Unlocked: ${res.newlyUnlockedAchievements
            .map((a) => a.title)
            .join(', ')}`
        );
      } else {
        setBanner(`Day ${dayNumber} marked complete.`);
      }
      await loadChallenge();
    } finally {
      setSubmittingDay(null);
    }
  };

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="h-36 rounded-xl border border-neutral-200 bg-white animate-pulse" />
        <div className="h-64 rounded-xl border border-neutral-200 bg-white animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            {data.challenge.title}
          </h1>
          <p className="text-sm text-neutral-600 mt-0.5">{data.challenge.description}</p>
        </div>

        <div className="flex items-center gap-4 rounded-xl border border-neutral-200 bg-white px-4 py-2.5">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-neutral-900">
            <Flame className="w-4 h-4 text-[#C2410C]" />
            <span className="font-mono tabular-nums">{data.streak}-Day Streak</span>
          </div>
          <span className="text-neutral-300">|</span>
          <div className="text-sm font-mono font-bold text-[#14532D] tabular-nums">
            {data.completedCount}/{data.targetDays} Days ({data.completionPercent}%)
          </div>
        </div>
      </div>

      {banner && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-950">
          {banner}
        </div>
      )}

      {/* Progress Bar & Optional Note */}
      <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
        <div className="flex items-center justify-between text-xs text-neutral-600">
          <span>Overall 7-Day Completion</span>
          <span className="font-mono font-semibold tabular-nums">{data.completionPercent}%</span>
        </div>
        <div className="w-full h-2.5 bg-neutral-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#14532D] transition-all"
            style={{ width: `${data.completionPercent}%` }}
          />
        </div>

        <div className="pt-2">
          <label className="block text-xs font-medium text-neutral-600 mb-1">
            Optional note before marking a day complete (swaps also auto-advance your challenge)
          </label>
          <input
            type="text"
            value={noteInput}
            onChange={(e) => setNoteInput(e.target.value)}
            placeholder="e.g. Swapped evening samosa for roasted chana..."
            className="w-full max-w-lg px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
          />
        </div>
      </div>

      {/* 7-Day Tracker Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
        {data.days.map((day) => (
          <div
            key={day.dayNumber}
            className={`rounded-xl border p-4 flex flex-col justify-between ${
              day.completed
                ? 'border-[#14532D]/40 bg-emerald-50/40'
                : 'border-neutral-200 bg-white'
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-mono font-bold text-neutral-900">
                  Day {day.dayNumber}
                </span>
                {day.completed ? (
                  <CheckCircle2 className="w-4 h-4 text-[#14532D]" />
                ) : (
                  <span className="text-[11px] text-neutral-400">Pending</span>
                )}
              </div>
              {day.completed ? (
                <div className="text-xs text-neutral-600 space-y-1">
                  <div className="font-mono text-[11px] text-[#14532D]">{day.completedDate}</div>
                  {day.notes && <p className="line-clamp-3 leading-relaxed">{day.notes}</p>}
                </div>
              ) : (
                <p className="text-xs text-neutral-500">
                  Complete one healthy swap to unlock Day {day.dayNumber}.
                </p>
              )}
            </div>

            {!day.completed && (
              <button
                type="button"
                disabled={submittingDay === day.dayNumber}
                onClick={() => handleMarkDay(day.dayNumber)}
                className="mt-4 w-full px-2.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-50 rounded-lg transition-colors"
              >
                {submittingDay === day.dayNumber ? 'Saving...' : 'Mark Done'}
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Achievement Badges */}
      <div className="rounded-xl border border-neutral-200 bg-white p-5">
        <div className="flex items-center gap-2 mb-4">
          <Award className="w-4 h-4 text-[#14532D]" />
          <h2 className="text-base font-bold text-neutral-900">Achievement Badges</h2>
          <span className="text-xs text-neutral-500 ml-auto">
            Unlocked strictly when database conditions are satisfied
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {data.achievements.map((ach) => (
            <div
              key={ach.id}
              className={`rounded-xl border p-4 ${
                ach.unlocked
                  ? 'border-[#14532D]/40 bg-emerald-50/50'
                  : 'border-neutral-200 bg-neutral-50/70 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-semibold text-neutral-900">{ach.title}</span>
                {ach.unlocked ? (
                  <Award className="w-4 h-4 text-[#14532D] shrink-0" />
                ) : (
                  <Lock className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                )}
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">{ach.description}</p>
              <div className="mt-3 pt-2 border-t border-neutral-200/70 text-[11px] text-neutral-500">
                {ach.unlocked && ach.unlockedAt
                  ? `Unlocked ${new Date(ach.unlockedAt).toLocaleDateString()}`
                  : `Criteria: ${ach.criteria}`}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
