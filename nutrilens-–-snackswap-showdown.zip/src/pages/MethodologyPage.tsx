import { Link } from 'react-router-dom';
import { BookOpen, Database, Scale, ShieldAlert } from 'lucide-react';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function MethodologyPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="rounded-2xl border border-neutral-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center">
          <p className="text-xs font-semibold text-[#14532D] mb-2">
            Academic Documentation &amp; Nutrition Engineering
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900">
            About &amp; Scoring Methodology
          </h1>
          <p className="text-sm text-neutral-600 mt-2 leading-relaxed">
            NutriLens – SnackSwap Showdown is designed for college students to demystify snack labels,
            standardize serving-size illusions, and evaluate swaps using documented nutritional profiling algorithms.
          </p>
        </div>
        <div className="lg:col-span-5 h-52 lg:h-auto bg-neutral-100">
          <ImageWithFallback
            src="/src/assets/images/methodology_nutrition_lab_1795108841586.jpg"
            alt="Precision food scale with whole grains, almonds, and measuring glass"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Section 1: Coherent Health Grading Engine */}
      <section className="rounded-xl border border-neutral-200 bg-white p-6 space-y-4">
        <div className="flex items-center gap-2 text-[#14532D]">
          <Scale className="w-5 h-5" />
          <h2 className="text-lg font-bold text-neutral-900">
            01. Health Grading Methodology (FSA / Nutri-Score Adapted Model)
          </h2>
        </div>

        <p className="text-sm text-neutral-700 leading-relaxed">
          To avoid mixing incompatible profiling frameworks, NutriLens implements a single coherent model
          based on the <strong>Santé Publique France Nutri-Score / UK FSA Nutrient Profiling System</strong> evaluated
          strictly on a standardized <strong>100g (solid food)</strong> or <strong>100ml (beverage)</strong> baseline.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
          <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-4 space-y-2">
            <h3 className="font-bold text-neutral-900 text-sm">Negative Points (N, 0–40)</h3>
            <ul className="space-y-1 text-neutral-700">
              <li><strong>Energy (kJ = kcal × 4.184):</strong> 0–10 points (solid &gt;335 kJ steps; beverages &gt;0–270 kJ steps)</li>
              <li><strong>Total Sugars (g):</strong> 0–10 points (solid &gt;4.5g steps; beverages &gt;1.5g steps)</li>
              <li><strong>Saturated Fat (g):</strong> 0–10 points (&gt;1g per step up to &gt;10g)</li>
              <li><strong>Sodium (mg):</strong> 0–10 points (&gt;90mg per step up to &gt;900mg)</li>
            </ul>
          </div>

          <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-4 space-y-2">
            <h3 className="font-bold text-neutral-900 text-sm">Positive Points (P, 0–10) &amp; Cap Rule</h3>
            <ul className="space-y-1 text-neutral-700">
              <li><strong>Dietary Fiber (g):</strong> 0–5 points (&gt;0.9g, &gt;1.9g, &gt;2.8g, &gt;3.7g, &gt;4.7g)</li>
              <li><strong>Protein (g):</strong> 0–5 points (&gt;1.6g, &gt;3.2g, &gt;4.8g, &gt;6.4g, &gt;8.0g)</li>
              <li><strong>Dataset Adaptation Note:</strong> Because Indian snack labels rarely declare Fruit/Vegetable/Legume %, when N ≥ 11, protein credit is capped at 0 (standard FSA safeguard against ultra-processed snacks masking high fat/salt with added protein).</li>
            </ul>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs border border-neutral-200 rounded-lg overflow-hidden">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-700">
              <tr>
                <th className="text-left px-4 py-2.5 font-semibold">Grade</th>
                <th className="text-left px-4 py-2.5 font-semibold">Interpretation</th>
                <th className="text-left px-4 py-2.5 font-semibold">Solid Food Score (N − P)</th>
                <th className="text-left px-4 py-2.5 font-semibold">Beverage Score (N − P)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-mono tabular-nums">
              <tr><td className="px-4 py-2 font-bold text-[#14532D]">A</td><td className="px-4 py-2 font-sans">Healthier Choice</td><td className="px-4 py-2">≤ -1</td><td className="px-4 py-2">Water / ≤ 0</td></tr>
              <tr><td className="px-4 py-2 font-bold text-[#4D7C0F]">B</td><td className="px-4 py-2 font-sans">Good Choice</td><td className="px-4 py-2">0 to 2</td><td className="px-4 py-2">1 to 2</td></tr>
              <tr><td className="px-4 py-2 font-bold text-[#B45309]">C</td><td className="px-4 py-2 font-sans">Moderate</td><td className="px-4 py-2">3 to 10</td><td className="px-4 py-2">3 to 5</td></tr>
              <tr><td className="px-4 py-2 font-bold text-[#C2410C]">D</td><td className="px-4 py-2 font-sans">Less Healthy</td><td className="px-4 py-2">11 to 18</td><td className="px-4 py-2">6 to 9</td></tr>
              <tr><td className="px-4 py-2 font-bold text-[#B91C1C]">E</td><td className="px-4 py-2 font-sans">Least Healthy</td><td className="px-4 py-2">≥ 19</td><td className="px-4 py-2">≥ 10</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Section 2: Swap Recommender & Exercise Math */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="rounded-xl border border-neutral-200 bg-white p-6 space-y-3">
          <div className="flex items-center gap-2 text-[#14532D]">
            <BookOpen className="w-5 h-5" />
            <h2 className="text-base font-bold text-neutral-900">
              02. Normalized Euclidean Swap Recommender
            </h2>
          </div>
          <p className="text-xs text-neutral-700 leading-relaxed">
            For any selected snack, NutriLens constructs an ideal healthier target vector (lowering calories,
            saturated fat, sugar, and sodium while elevating protein and fiber) normalized via min-max scaling
            across all snacks in SQLite.
          </p>
          <div className="rounded-lg bg-neutral-50 border border-neutral-200 p-3 font-mono text-xs text-neutral-800">
            d = √( Σ w_i · (target_i − candidate_i)² / Σ w_i )
          </div>
          <p className="text-xs text-neutral-600 leading-relaxed">
            Sensory context penalties account for texture alignment (crunchy/crispy/liquid), taste profile
            (salty/spicy/sweet/tangy), and INR affordability before ranking the top 3 alternatives.
          </p>
        </section>

        <section className="rounded-xl border border-neutral-200 bg-white p-6 space-y-3">
          <div className="flex items-center gap-2 text-[#14532D]">
            <Database className="w-5 h-5" />
            <h2 className="text-base font-bold text-neutral-900">
              03. Data Sources, Exercise &amp; Sugar Assumptions
            </h2>
          </div>
          <ul className="space-y-2 text-xs text-neutral-700 leading-relaxed">
            <li>
              <strong>Nutrition Sources:</strong> Grounded in IFCT 2017 (ICMR-NIN), USDA FoodData Central,
              and packaged product averages. Unpackaged street/canteen foods (e.g., Samosa, Vada Pav) are explicitly
              marked <em>Illustrative Estimate</em>.
            </li>
            <li>
              <strong>Exercise Equivalency:</strong> Uses Compendium of Physical Activities MET constants
              (Walking 3.5 MET, Cycling 6.0 MET, Jogging 7.0 MET) via <span className="font-mono">kcal/min = (MET × 3.5 × weightKg) ÷ 200</span>.
            </li>
            <li>
              <strong>Sugar Cubes:</strong> Configurable 4g (default level tsp) or 5g cube weight.
            </li>
          </ul>
        </section>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl border border-neutral-200 bg-neutral-50 p-5 flex items-start gap-3 text-xs text-neutral-700">
        <ShieldAlert className="w-5 h-5 text-[#C2410C] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-neutral-900">Educational &amp; Non-Medical Disclaimer</div>
          <p className="leading-relaxed">
            NutriLens provides standardized nutritional comparisons, energy equivalencies, and population-level food profiling
            for academic demonstration and general wellness awareness. It does not constitute medical advice, clinical nutrition therapy,
            or exercise prescriptions.
          </p>
          <div className="pt-2">
            <Link to="/snacks" className="font-semibold text-[#14532D] hover:underline">
              Explore the 44-snack database →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
