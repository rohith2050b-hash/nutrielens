import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeftRight, ChevronLeft, ChevronRight, Search, SlidersHorizontal } from 'lucide-react';
import { api } from '../services/api.ts';
import { ComparisonBasis, HealthGrade, Snack } from '../types/index.ts';
import { getUnitBasis, scaleSnackNutrient, setUnitBasis } from '../utils/nutrition.ts';
import { GradeBadge } from '../components/GradeBadge.tsx';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function ExplorerPage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [queryInput, setQueryInput] = useState(() => searchParams.get('q') ?? '');
  const [debouncedQuery, setDebouncedQuery] = useState(queryInput);
  const [category, setCategory] = useState(() => searchParams.get('category') ?? 'All');
  const [grade, setGrade] = useState<HealthGrade | ''>(
    () => (searchParams.get('grade') as HealthGrade | null) ?? ''
  );
  const [healthyOnly, setHealthyOnly] = useState<boolean>(
    () => searchParams.get('healthyOnly') === 'true'
  );
  const [sortBy, setSortBy] = useState<'name' | 'calories' | 'protein' | 'sugar' | 'sodium' | 'gradeScore'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [basis, setBasis] = useState<ComparisonBasis>(() => getUnitBasis());

  const [snacks, setSnacks] = useState<Snack[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Debounce instant search input (250ms)
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(queryInput);
      setPage(1);
    }, 250);
    return () => clearTimeout(timer);
  }, [queryInput]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    api
      .searchSnacks(
        {
          q: debouncedQuery || undefined,
          category: category !== 'All' ? category : undefined,
          grade: grade || undefined,
          healthyOnly: healthyOnly ? true : undefined,
          sortBy,
          sortOrder,
          page,
          limit: 12,
        },
        controller.signal
      )
      .then((res) => {
        setSnacks(res.items);
        setCategories(res.categories);
        setTotal(res.pagination.total);
        setTotalPages(res.pagination.totalPages);
      })
      .catch((err) => {
        if (err instanceof Error && err.name === 'AbortError') return;
        setError(err instanceof Error ? err.message : 'Unable to search snacks.');
      })
      .finally(() => {
        setLoading(false);
      });

    return () => controller.abort();
  }, [debouncedQuery, category, grade, healthyOnly, sortBy, sortOrder, page]);

  const handleBasisChange = (next: ComparisonBasis) => {
    setBasis(next);
    setUnitBasis(next);
  };

  const handleResetFilters = () => {
    setQueryInput('');
    setDebouncedQuery('');
    setCategory('All');
    setGrade('');
    setHealthyOnly(false);
    setSortBy('name');
    setSortOrder('asc');
    setPage(1);
    setSearchParams({});
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            Snack Nutrition Explorer
          </h1>
          <p className="text-sm text-neutral-600 mt-0.5">
            Search Indian canteen staples and healthier swaps with standardized nutrition facts.
          </p>
        </div>

        {/* Unit Basis Toggle */}
        <div
          className="inline-flex items-center p-1 bg-neutral-200/70 rounded-lg text-xs"
          role="group"
          aria-label="Nutrition display unit"
        >
          <button
            type="button"
            onClick={() => handleBasisChange('serving')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap shrink-0 transition-colors ${
              basis === 'serving'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Per Serving
          </button>
          <button
            type="button"
            onClick={() => handleBasisChange('100g')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap shrink-0 transition-colors ${
              basis === '100g'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Per 100g / 100ml
          </button>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="rounded-xl border border-neutral-200 bg-white p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={queryInput}
              onChange={(e) => setQueryInput(e.target.value)}
              placeholder="Search snacks (e.g. Potato Chips, Samosa, Makhana, Cola)..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
              aria-label="Search snacks"
            />
          </div>

          <div className="md:col-span-3">
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              aria-label="Filter by category"
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              <option value="All">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={grade}
              onChange={(e) => {
                setGrade(e.target.value as HealthGrade | '');
                setPage(1);
              }}
              aria-label="Filter by health grade"
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              <option value="">All Grades</option>
              <option value="A">Grade A (Healthier)</option>
              <option value="B">Grade B (Good)</option>
              <option value="C">Grade C (Moderate)</option>
              <option value="D">Grade D (Less Healthy)</option>
              <option value="E">Grade E (Least Healthy)</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={`${sortBy}:${sortOrder}`}
              onChange={(e) => {
                const [field, ord] = e.target.value.split(':') as [typeof sortBy, 'asc' | 'desc'];
                setSortBy(field);
                setSortOrder(ord);
                setPage(1);
              }}
              aria-label="Sort snacks"
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              <option value="name:asc">Name (A–Z)</option>
              <option value="calories:asc">Calories (Low–High)</option>
              <option value="calories:desc">Calories (High–Low)</option>
              <option value="protein:desc">Protein (High–Low)</option>
              <option value="sugar:asc">Sugar (Low–High)</option>
              <option value="sodium:asc">Sodium (Low–High)</option>
              <option value="gradeScore:asc">Healthiest First</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-neutral-100 text-xs">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                setHealthyOnly((v) => !v);
                setPage(1);
              }}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium border transition-colors ${
                healthyOnly
                  ? 'border-[#14532D] bg-[#14532D]/10 text-[#14532D]'
                  : 'border-neutral-200 bg-neutral-50 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Healthy Alternatives Only</span>
            </button>
            <span className="text-neutral-500 tabular-nums">
              Showing {snacks.length} of {total} snacks
            </span>
          </div>

          {(queryInput || category !== 'All' || grade || healthyOnly) && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="text-neutral-600 hover:text-neutral-900 font-medium underline"
            >
              Reset filters
            </button>
          )}
        </div>
      </div>

      {/* Results Grid */}
      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-64 rounded-xl border border-neutral-200 bg-white animate-pulse" />
          ))}
        </div>
      ) : snacks.length === 0 ? (
        <div className="rounded-xl border border-dashed border-neutral-300 bg-white p-10 text-center">
          <h2 className="text-base font-bold text-neutral-900">No matching snacks found</h2>
          <p className="text-sm text-neutral-600 mt-1">
            Try clearing your search query or switching category filters.
          </p>
          <button
            type="button"
            onClick={handleResetFilters}
            className="mt-4 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg"
          >
            Show All Snacks
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {snacks.map((snack) => {
            const scaled = snack.nutrition
              ? scaleSnackNutrient(snack.nutrition, snack.servingSizeGrams, basis)
              : null;

            return (
              <article
                key={snack.id}
                className="rounded-xl border border-neutral-200 bg-white overflow-hidden flex flex-col justify-between hover:border-neutral-300 transition-colors"
              >
                <div>
                  <div className="h-36 overflow-hidden bg-neutral-100">
                    <ImageWithFallback
                      src={snack.imageUrl}
                      alt={snack.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    {/* Zero-pill unboxed metadata */}
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="text-xs text-neutral-500 truncate">
                        {snack.category} · {snack.isHealthyAlternative ? 'Healthy Swap' : 'Common Snack'}
                      </span>
                      <GradeBadge grade={snack.nutrition?.healthGrade ?? 'C'} size="sm" />
                    </div>

                    <Link
                      to={`/snacks/${snack.slug}`}
                      className="text-base font-bold text-neutral-900 hover:text-[#14532D] transition-colors block"
                    >
                      {snack.name}
                    </Link>

                    <p className="text-xs text-neutral-600 mt-1 line-clamp-2">
                      {snack.description}
                    </p>

                    {scaled && (
                      <div className="mt-4 pt-3 border-t border-neutral-100 grid grid-cols-4 gap-2 text-xs font-mono tabular-nums">
                        <div>
                          <div className="text-[11px] font-sans text-neutral-500">Calories</div>
                          <div className="font-semibold text-neutral-900">{scaled.calories}</div>
                        </div>
                        <div>
                          <div className="text-[11px] font-sans text-neutral-500">Sugar</div>
                          <div className="font-semibold text-neutral-900">{scaled.sugar}g</div>
                        </div>
                        <div>
                          <div className="text-[11px] font-sans text-neutral-500">Sodium</div>
                          <div className="font-semibold text-neutral-900">{scaled.sodium}mg</div>
                        </div>
                        <div>
                          <div className="text-[11px] font-sans text-neutral-500">Protein</div>
                          <div className="font-semibold text-neutral-900">{scaled.protein}g</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="px-4 py-3 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between gap-2 text-xs">
                  <span className="text-neutral-500 truncate">
                    {basis === 'serving' ? snack.servingLabel : `Per 100${snack.servingUnit}`}
                  </span>
                  <div className="flex items-center gap-3 shrink-0">
                    <Link
                      to={`/compare?a=${snack.slug}`}
                      className="inline-flex items-center gap-1 font-medium text-neutral-700 hover:text-neutral-900"
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                      <span>Compare</span>
                    </Link>
                    <Link
                      to={`/snacks/${snack.slug}`}
                      className="font-semibold text-[#14532D] hover:underline"
                    >
                      Inspect
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border border-neutral-300 bg-white disabled:opacity-40 hover:bg-neutral-50"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>
          <span className="text-xs font-mono tabular-nums text-neutral-600">
            Page {page} of {totalPages}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border border-neutral-300 bg-white disabled:opacity-40 hover:bg-neutral-50"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
