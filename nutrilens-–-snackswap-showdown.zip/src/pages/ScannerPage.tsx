import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Html5Qrcode } from 'html5-qrcode';
import {
  AlertTriangle,
  ArrowLeftRight,
  Camera,
  CameraOff,
  CheckCircle2,
  Search,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { BarcodeLookupResult } from '../types/index.ts';
import { GradeBadge, TrafficLightGrid } from '../components/GradeBadge.tsx';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function ScannerPage() {
  const navigate = useNavigate();
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerElementId = 'nutrilens-barcode-reader';

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [result, setResult] = useState<BarcodeLookupResult | null>(null);

  const stopCamera = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch {
        // ignore cleanup error
      }
      scannerRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      void stopCamera();
    };
  }, []);

  const performLookup = async (code: string) => {
    const cleaned = code.trim();
    if (!/^\d{8,14}$/.test(cleaned)) {
      setLookupError('Invalid barcode format. Please enter an 8 to 14 digit numeric EAN/UPC barcode.');
      return;
    }

    setLookupLoading(true);
    setLookupError(null);
    setResult(null);

    try {
      const data = await api.lookupBarcode(cleaned);
      setResult(data);
    } catch (err) {
      setLookupError(
        err instanceof Error
          ? err.message
          : 'Unable to fetch barcode details. Please try manual snack search.'
      );
    } finally {
      setLookupLoading(false);
    }
  };

  const startCamera = async () => {
    setCameraError(null);
    setLookupError(null);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError(
        'Camera API is unavailable in this browser or context. Use manual barcode entry or snack search below.'
      );
      return;
    }

    try {
      const instance = new Html5Qrcode(scannerElementId);
      scannerRef.current = instance;
      setCameraActive(true);

      await instance.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 140 } },
        (decodedText) => {
          setManualCode(decodedText);
          void stopCamera();
          void performLookup(decodedText);
        },
        () => {
          // frame scan miss is normal while aiming
        }
      );
    } catch (err) {
      setCameraActive(false);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('notallowed')) {
        setCameraError(
          'Camera permission was denied. Allow camera access in your browser settings or enter a barcode manually below.'
        );
      } else {
        setCameraError(
          `Could not initialize camera (${msg}). Use manual barcode entry or fallback snack search below.`
        );
      }
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void performLookup(manualCode);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
          Barcode Scanner &amp; Open Food Facts Lookup
        </h1>
        <p className="text-sm text-neutral-600 mt-0.5">
          Scan packaged snack barcodes with your device camera or enter an EAN-8/EAN-13 barcode to fetch live nutrition facts and healthy alternatives.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Camera & Manual Input Panel */}
        <div className="lg:col-span-5 rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-base font-bold text-neutral-900">Camera Scanner</h2>
            {!cameraActive ? (
              <button
                type="button"
                onClick={startCamera}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Start Camera</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void stopCamera()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 hover:bg-red-100 rounded-lg transition-colors"
              >
                <CameraOff className="w-3.5 h-3.5" />
                <span>Stop Camera</span>
              </button>
            )}
          </div>

          <div className="rounded-lg border border-neutral-200 bg-neutral-950 overflow-hidden min-h-[210px] flex items-center justify-center relative">
            <div id={scannerElementId} className="w-full" />
            {!cameraActive && (
              <div className="text-center px-6 py-8 text-neutral-400 text-xs">
                <Camera className="w-7 h-7 mx-auto mb-2 text-neutral-500" />
                <p>Click &ldquo;Start Camera&rdquo; to request browser camera access and scan a product barcode.</p>
              </div>
            )}
          </div>

          {cameraError && (
            <div className="rounded-lg border border-orange-200 bg-orange-50 p-3 text-xs text-orange-950 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-[#C2410C] shrink-0 mt-0.5" />
              <span>{cameraError}</span>
            </div>
          )}

          {/* Manual Barcode Entry Fallback */}
          <form onSubmit={handleManualSubmit} className="pt-3 border-t border-neutral-100 space-y-2.5">
            <label className="block text-xs font-semibold text-neutral-700">
              Manual Barcode Lookup (Fallback)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                inputMode="numeric"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Enter 8–14 digit barcode (e.g. 8901491101813)"
                className="flex-1 px-3 py-2 text-sm font-mono rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
              />
              <button
                type="submit"
                disabled={lookupLoading}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-50 rounded-lg whitespace-nowrap"
              >
                {lookupLoading ? 'Checking...' : 'Lookup'}
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-neutral-500">
              <span>Test barcodes:</span>
              {[
                { label: 'Potato Chips', code: '8901491101813' },
                { label: 'Cola', code: '5449000000996' },
                { label: 'Instant Noodles', code: '8901058852417' },
                { label: 'Makhana', code: '8906090571014' },
              ].map((sample) => (
                <button
                  key={sample.code}
                  type="button"
                  onClick={() => {
                    setManualCode(sample.code);
                    void performLookup(sample.code);
                  }}
                  className="px-2 py-0.5 rounded bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-medium"
                >
                  {sample.label}
                </button>
              ))}
            </div>
          </form>

          <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-600">
            <span>Product missing or unlabelled?</span>
            <Link
              to="/snacks"
              className="inline-flex items-center gap-1 font-semibold text-[#14532D] hover:underline"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Manual Snack Search</span>
            </Link>
          </div>
        </div>

        {/* Lookup Result Panel */}
        <div className="lg:col-span-7 space-y-5">
          {lookupLoading && (
            <div className="h-72 rounded-xl border border-neutral-200 bg-white animate-pulse" />
          )}

          {lookupError && (
            <div className="rounded-xl border border-red-200 bg-red-50 p-5 space-y-3">
              <div className="flex items-start gap-2.5 text-sm text-red-900">
                <AlertTriangle className="w-5 h-5 text-[#B91C1C] shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold">Barcode Lookup Failed</div>
                  <p className="mt-1 text-xs leading-relaxed">{lookupError}</p>
                </div>
              </div>
              <Link
                to="/snacks"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-800 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search Snacks Manually</span>
              </Link>
            </div>
          )}

          {!lookupLoading && !lookupError && !result && (
            <div className="rounded-xl border border-dashed border-neutral-300 bg-white p-10 text-center">
              <h2 className="text-base font-bold text-neutral-900">Ready to Scan</h2>
              <p className="text-sm text-neutral-600 mt-1 max-w-md mx-auto">
                Scan a packaged snack barcode or pick one of the sample barcodes on the left to inspect its nutrition facts, health grade, and healthier Indian alternatives.
              </p>
            </div>
          )}

          {result && (
            <div className="space-y-5">
              <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 rounded-lg overflow-hidden border border-neutral-200 bg-neutral-100 shrink-0">
                      <ImageWithFallback
                        src={result.product.imageUrl}
                        alt={result.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="text-xs text-neutral-500">
                        {result.source === 'local_catalog' ? 'NutriLens Verified Catalog' : 'Open Food Facts Live API'} · Barcode {result.barcode}
                      </div>
                      <h2 className="text-xl font-bold text-neutral-900 mt-0.5">
                        {result.product.name}
                      </h2>
                      <div className="text-xs text-neutral-600 mt-0.5">
                        Brand: {result.product.brand} · Serving: {result.product.servingLabel}
                      </div>
                    </div>
                  </div>

                  <GradeBadge grade={result.gradeAnalysis.healthGrade} showLabel size="md" />
                </div>

                {result.product.missingFields.length > 0 && (
                  <div className="rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2 text-xs text-amber-950">
                    Note: Open Food Facts did not specify {result.product.missingFields.join(', ')} for this product.
                  </div>
                )}

                <TrafficLightGrid metrics={result.gradeAnalysis.trafficLights} />

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-mono tabular-nums">
                  <div className="p-2.5 rounded-lg bg-neutral-50 border border-neutral-200/70">
                    <div className="text-neutral-500 font-sans">Calories / 100{result.product.servingUnit}</div>
                    <div className="font-bold text-neutral-900 mt-0.5">{result.product.nutritionPer100g.calories} kcal</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-neutral-50 border border-neutral-200/70">
                    <div className="text-neutral-500 font-sans">Carbohydrates</div>
                    <div className="font-bold text-neutral-900 mt-0.5">{result.product.nutritionPer100g.carbohydrates}g</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-neutral-50 border border-neutral-200/70">
                    <div className="text-neutral-500 font-sans">Protein</div>
                    <div className="font-bold text-neutral-900 mt-0.5">{result.product.nutritionPer100g.protein}g</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-neutral-50 border border-neutral-200/70">
                    <div className="text-neutral-500 font-sans">Fiber</div>
                    <div className="font-bold text-neutral-900 mt-0.5">{result.product.nutritionPer100g.fiber}g</div>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-3">
                <h3 className="text-base font-bold text-neutral-900">
                  Healthier Alternatives for {result.product.name}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {result.recommendations.map((rec) => (
                    <div key={rec.snack.id} className="rounded-lg border border-neutral-200 bg-[#FAFAFA] p-3.5 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-xs font-mono font-semibold text-[#14532D] tabular-nums">
                            {rec.matchScore}% Match · {rec.priceRange}
                          </span>
                          <GradeBadge grade={rec.snack.nutrition?.healthGrade ?? 'A'} size="sm" />
                        </div>
                        <Link
                          to={`/snacks/${rec.snack.slug}`}
                          className="text-sm font-bold text-neutral-900 hover:text-[#14532D]"
                        >
                          {rec.snack.name}
                        </Link>
                        <ul className="mt-2 space-y-1 text-xs text-neutral-600">
                          {rec.advantages.slice(0, 2).map((adv, idx) => (
                            <li key={idx} className="flex items-start gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#14532D] shrink-0 mt-0.5" />
                              <span>{adv}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {result.product.id ? (
                        <button
                          type="button"
                          onClick={() =>
                            navigate(`/compare?a=${result.product.id}&b=${rec.snack.slug}`)
                          }
                          className="mt-3 w-full inline-flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-md"
                        >
                          <ArrowLeftRight className="w-3 h-3" />
                          <span>Compare</span>
                        </button>
                      ) : (
                        <Link
                          to={`/snacks/${rec.snack.slug}`}
                          className="mt-3 w-full inline-flex items-center justify-center px-2.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-md"
                        >
                          View Alternative
                        </Link>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
