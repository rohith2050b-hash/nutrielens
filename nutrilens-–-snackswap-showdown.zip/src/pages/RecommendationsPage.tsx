import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeftRight, Check, CheckCircle2, Sparkles } from 'lucide-react';
import { api } from '../services/api.ts';
import { RecommendationItem, Snack } from '../types/index.ts';
import { GradeBadge } from '../components/GradeBadge.tsx';

export function RecommendationsPage() {
  const navigate = useNavigate();
  const [commonSnacks, setCommonSnacks] = useState<Snack[]>([]);
  const [selectedSlug, setSelectedSlug] = useState('potato-chips');
  const [sourceSnack, setSourceSnack] = useState<Snack | null>(null);
  const [recommendations, setRecommendations] = useState<RecommendationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [swappingId, setSwappingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    api
      .searchSnacks({ healthyOnly: false, limit: 50, sortBy: 'name', sortOrder: 'asc' })
      .then((res) => setCommonSnacks(res.items))
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setFeedback(null);
    api
      .getRecommendations(selectedSlug, 3)
      .then((res) => {
        if (!active) return;
        setSourceSnack(res.sourceSnack);
        setRecommendations(res.recommendations);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedSlug]);

  const handleLogSwap = async (rec: RecommendationItem) => {
    if (!sourceSnack) return;
    setSwappingId(rec.snack.id);
    setFeedback(null);
    try {
      await api.recordSwap({
        originalSnackId: sourceSnack.id,
        replacementSnackId: rec.snack.id,
        basis: 'serving',
      });
      setFeedback(`Recorded swap: ${sourceSnack.name} → ${rec.snack.name}.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Unable to log swap.');
    } finally {
      setSwappingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
          Healthy Swap Recommendations
        </h1>
        <p className="text-sm text-neutral-600 mt-0.5">
          Select a common snack to view the top 3 healthier alternatives ranked by normalized Euclidean nutritional distance, texture, taste, and Indian campus affordability.
        </p>
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <div className="md:col-span-6">
            <label className="block text-xs font-medium text-neutral-600 mb-1">
              Choose a snack you want to swap
            </label>
            <select
              value={selectedSlug}
              onChange={(e) => setSelectedSlug(e.target.value)}
              className="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              {commonSnacks.length === 0 && <option value="potato-chips">Potato Chips</option>}
              {commonSnacks.map((s) => (
                <option key={s.id} value={s.slug}>
                  {s.name} (Grade {s.nutrition?.healthGrade}) · {s.category}
                </option>
              ))}
            </select>
          </div>

          {sourceSnack && (
            <div className="md:col-span-6 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-neutral-50 border border-neutral-200 px-4 py-2.5 text-xs">
              <div>
                <div className="font-semibold text-neutral-900">{sourceSnack.name}</div>
                <div className="text-neutral-500 mt-0.5 font-mono tabular-nums">
                  {sourceSnack.nutrition?.calories} kcal / 100{sourceSnack.servingUnit} ·{' '}
                  {sourceSnack.texture} · {sourceSnack.tasteProfile} · ₹{sourceSnack.priceInrMin}–₹{sourceSnack.priceInrMax}
                </div>
              </div>
              <GradeBadge grade={sourceSnack.nutrition?.healthGrade ?? 'D'} size="sm" />
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500 pt-2 border-t border-neutral-100">
          <span>Popular lookups:</span>
          {[
            { slug: 'potato-chips', label: 'Potato Chips' },
            { slug: 'samosa', label: 'Samosa' },
            { slug: 'cola', label: 'Cola' },
            { slug: 'cream-biscuits', label: 'Cream Biscuits' },
            { slug: 'french-fries', label: 'French Fries' },
            { slug: 'instant-noodles', label: 'Instant Noodles' },
          ].map((q) => (
            <button
              key={q.slug}
              type="button"
              onClick={() => setSelectedSlug(q.slug)}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                selectedSlug === q.slug
                  ? 'bg-[#14532D] text-white'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              {q.label}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-950 flex items-center justify-between gap-3">
          <span className="inline-flex items-center gap-2">
            <Check className="w-4 h-4 text-[#14532D]" />
            {feedback}
          </span>
          <Link to="/dashboard" className="text-xs font-semibold text-[#14532D] underline">
            Open Dashboard
          </Link>
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-72 rounded-xl border border-neutral-200 bg-white animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {recommendations.map((rec, idx) => (
            <div
              key={rec.snack.id}
              className="rounded-xl border border-neutral-200 bg-white p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-xs font-mono font-semibold text-[#14532D] tabular-nums">
                    #{idx + 1} · {rec.matchScore}% Match (d={rec.euclideanDistance})
                  </span>
                  <GradeBadge grade={rec.snack.nutrition?.healthGrade ?? 'A'} size="sm" />
                </div>

                <Link
                  to={`/snacks/${rec.snack.slug}`}
                  className="text-lg font-bold text-neutral-900 hover:text-[#14532D]"
                >
                  {rec.snack.name}
                </Link>

                <div className="text-xs text-neutral-500 mt-1 tabular-nums">
                  {rec.snack.nutrition?.calories} kcal / 100{rec.snack.servingUnit} · {rec.priceRange} · {rec.snack.availability}
                </div>

                <div className="mt-3 p-3 rounded-lg bg-neutral-50 border border-neutral-200/70 text-xs text-neutral-700 leading-relaxed">
                  <div className="flex items-center gap-1 font-semibold text-neutral-900 mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#14532D]" />
                    <span>Why it fits</span>
                  </div>
                  {rec.whySuitable}
                </div>

                <div className="mt-4">
                  <div className="text-xs font-semibold text-neutral-900 mb-1.5">
                    Nutritional Advantages
                  </div>
                  <ul className="space-y-1.5 text-xs text-neutral-700">
                    {rec.advantages.map((adv, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#14532D] shrink-0 mt-0.5" />
                        <span>{adv}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-neutral-100 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => navigate(`/compare?a=${selectedSlug}&b=${rec.snack.slug}`)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-800 bg-white border border-neutral-300 hover:bg-neutral-50 rounded-lg transition-colors"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>Compare</span>
                </button>
                <button
                  type="button"
                  disabled={swappingId === rec.snack.id}
                  onClick={() => handleLogSwap(rec)}
                  className="flex-1 px-3 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
                >
                  {swappingId === rec.snack.id ? 'Saving...' : 'I Swapped This!'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
