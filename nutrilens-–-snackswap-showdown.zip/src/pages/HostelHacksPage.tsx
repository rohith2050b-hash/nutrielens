import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, IndianRupee, Utensils } from 'lucide-react';
import { api } from '../services/api.ts';
import { HostelHackItem } from '../types/index.ts';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function HostelHacksPage() {
  const [hacks, setHacks] = useState<HostelHackItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api
      .getHostelHacks(activeCategory)
      .then((res) => {
        if (!active) return;
        setHacks(res.items);
        if (res.categories.length > 0) setCategories(res.categories);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [activeCategory]);

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="rounded-2xl border border-neutral-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center">
          <p className="text-xs font-semibold text-[#14532D] mb-2">
            Indian College &amp; PG Survival Guide
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900">
            Hostel Room Snack Hacks
          </h1>
          <p className="text-sm text-neutral-600 mt-2 leading-relaxed max-w-xl">
            Low-cost, high-protein, zero-stove snack combinations made from roasted chana, makhana,
            peanuts, bananas, curd, oats, sprouts, and boiled corn — ready in under 5 minutes.
          </p>
        </div>
        <div className="lg:col-span-5 h-52 lg:h-auto bg-neutral-100">
          <ImageWithFallback
            src="/src/assets/images/hostel_snacks_flatlay_1795108842239.jpg"
            alt="Affordable Indian hostel room snacks including bananas, peanuts, sprouts, corn, and oats"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-200/70 rounded-lg w-fit">
        {['All', ...categories].map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-72 rounded-xl border border-neutral-200 bg-white animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {hacks.map((hack) => (
            <article
              key={hack.id}
              className="rounded-xl border border-neutral-200 bg-white p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-500 mb-1.5">
                  <span>{hack.category} · {hack.equipmentNeeded}</span>
                  <div className="flex items-center gap-3 font-mono tabular-nums text-neutral-700">
                    <span className="inline-flex items-center gap-1">
                      <IndianRupee className="w-3 h-3" />
                      {hack.approxCostInr.replace('₹', '')}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {hack.prepTimeMinutes}m
                    </span>
                  </div>
                </div>

                <h2 className="text-lg font-bold text-neutral-900">{hack.name}</h2>

                <div className="mt-3 grid grid-cols-4 gap-2 rounded-lg bg-neutral-50 border border-neutral-200/70 p-3 text-xs font-mono tabular-nums">
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Calories</div>
                    <div className="font-bold text-neutral-900">{hack.caloriesPerServing} kcal</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Protein</div>
                    <div className="font-bold text-[#14532D]">{hack.proteinPerServing}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Fiber</div>
                    <div className="font-bold text-neutral-900">{hack.fiberPerServing}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Sugar</div>
                    <div className="font-bold text-neutral-900">{hack.sugarPerServing}g</div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <h3 className="font-semibold text-neutral-900 mb-1.5">Ingredients</h3>
                    <ul className="space-y-1 text-neutral-600 list-disc list-inside">
                      {hack.ingredients.map((ing, i) => (
                        <li key={i}>{ing}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold text-neutral-900 mb-1.5">Preparation Steps</h3>
                    <ol className="space-y-1 text-neutral-600 list-decimal list-inside">
                      {hack.instructions.map((step, i) => (
                        <li key={i}>{step}</li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                <p className="text-neutral-600 flex-1 min-w-[200px]">
                  <strong className="text-neutral-900">Why it works:</strong> {hack.practicalWhy}
                </p>
                {hack.linkedSnackSlug && (
                  <Link
                    to={`/snacks/${hack.linkedSnackSlug}`}
                    className="inline-flex items-center gap-1 font-semibold text-[#14532D] hover:underline whitespace-nowrap shrink-0"
                  >
                    <Utensils className="w-3.5 h-3.5" />
                    <span>Inspect Base Snack</span>
                  </Link>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
