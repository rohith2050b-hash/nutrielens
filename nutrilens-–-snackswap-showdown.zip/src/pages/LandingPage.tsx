import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeftRight, CheckCircle2, Scale, Sparkles, Utensils } from 'lucide-react';
import { api } from '../services/api.ts';
import { ComparisonResult } from '../types/index.ts';
import { GradeBadge } from '../components/GradeBadge.tsx';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function LandingPage() {
  const [preview, setPreview] = useState<ComparisonResult | null>(null);
  const [previewLoading, setPreviewLoading] = useState(true);

  useEffect(() => {
    let active = true;
    api
      .compareSnacks('potato-chips', 'roasted-salted-makhana', 'serving')
      .then((res) => {
        if (active) setPreview(res);
      })
      .catch(() => {
        // Silently leave preview absent if backend unavailable
      })
      .finally(() => {
        if (active) setPreviewLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="bg-[#FAFAFA]">
      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-12 pb-16 lg:pt-16 lg:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-medium text-[#14532D] tracking-wide mb-3">
              Indian Campus Nutrition &amp; Snack Swap Intelligence
            </p>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-neutral-900 leading-[1.08] [text-wrap:balance]">
              Eat Smarter. Swap Better.
            </h1>
            <p className="mt-5 text-base sm:text-lg text-neutral-600 leading-relaxed max-w-xl">
              Discover what&apos;s inside your favourite snacks and find healthier alternatives
              without compromising on taste.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/snacks"
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <span>Explore Snacks</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/recommendations"
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-neutral-800 bg-white border border-neutral-300 hover:bg-neutral-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <span>Discover Healthy Swaps</span>
              </Link>
            </div>

            <div className="mt-8 pt-6 border-t border-neutral-200 grid grid-cols-3 gap-4 text-left">
              <div>
                <div className="text-xl font-bold font-mono tabular-nums text-neutral-900">44</div>
                <div className="text-xs text-neutral-500 mt-0.5">Verified &amp; estimated snacks</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono tabular-nums text-neutral-900">100g / ml</div>
                <div className="text-xs text-neutral-500 mt-0.5">Standardized comparison</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono tabular-nums text-neutral-900">₹10–₹35</div>
                <div className="text-xs text-neutral-500 mt-0.5">Hostel-friendly swaps</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[320px] rounded-2xl overflow-hidden border border-neutral-200 bg-white">
              <ImageWithFallback
                src="/src/assets/images/hero_snack_swap_1795108841772.jpg"
                alt="Comparison of deep-fried potato chips versus roasted makhana, roasted chana, and fresh lemon water"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Live Database Comparison Preview */}
      <section className="border-y border-neutral-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900">
                Real-Time Snack Comparison Preview
              </h2>
              <p className="text-sm text-neutral-600 mt-1.5">
                Live numbers calculated from our SQLite nutrition database for a standard 30g serving.
              </p>
            </div>
            <Link
              to="/compare?a=potato-chips&b=roasted-salted-makhana"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#14532D] hover:underline whitespace-nowrap"
            >
              <span>Open Full Comparison</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {previewLoading ? (
            <div className="h-52 rounded-xl border border-neutral-200 bg-neutral-50 animate-pulse" />
          ) : preview ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-4 rounded-xl border border-neutral-200 bg-[#FAFAFA] p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs text-neutral-500">
                      {preview.snackA.category} · {preview.basisLabelA}
                    </span>
                    <GradeBadge grade={preview.snackA.nutrition?.healthGrade ?? 'E'} />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900">{preview.snackA.name}</h3>
                  <p className="text-xs text-neutral-600 mt-1">{preview.snackA.description}</p>
                </div>
                <div className="mt-5 pt-4 border-t border-neutral-200 grid grid-cols-3 gap-2 text-xs font-mono tabular-nums">
                  <div>
                    <div className="text-neutral-500 font-sans">Calories</div>
                    <div className="text-sm font-bold text-[#B91C1C]">{preview.snackA.scaledNutrition.calories} kcal</div>
                  </div>
                  <div>
                    <div className="text-neutral-500 font-sans">Sat. Fat</div>
                    <div className="text-sm font-bold text-[#C2410C]">{preview.snackA.scaledNutrition.saturatedFat}g</div>
                  </div>
                  <div>
                    <div className="text-neutral-500 font-sans">Sodium</div>
                    <div className="text-sm font-bold text-[#C2410C]">{preview.snackA.scaledNutrition.sodium}mg</div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-4 rounded-xl border border-neutral-200 bg-white p-5 flex flex-col justify-center">
                <div className="text-xs font-semibold text-[#14532D] mb-2">
                  Calculated Swap Impact
                </div>
                <ul className="space-y-2.5 text-sm text-neutral-800">
                  {preview.headlineInsights.slice(0, 4).map((line, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                      <span className="tabular-nums">{line}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/compare?a=potato-chips&b=roasted-salted-makhana"
                  className="mt-5 inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>Compare Side-by-Side</span>
                </Link>
              </div>

              <div className="lg:col-span-4 rounded-xl border border-[#14532D]/30 bg-[#F0FDF4]/50 p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs text-neutral-600">
                      {preview.snackB.category} · {preview.basisLabelB}
                    </span>
                    <GradeBadge grade={preview.snackB.nutrition?.healthGrade ?? 'A'} />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900">{preview.snackB.name}</h3>
                  <p className="text-xs text-neutral-600 mt-1">{preview.snackB.description}</p>
                </div>
                <div className="mt-5 pt-4 border-t border-emerald-200/70 grid grid-cols-3 gap-2 text-xs font-mono tabular-nums">
                  <div>
                    <div className="text-neutral-500 font-sans">Calories</div>
                    <div className="text-sm font-bold text-[#14532D]">{preview.snackB.scaledNutrition.calories} kcal</div>
                  </div>
                  <div>
                    <div className="text-neutral-500 font-sans">Sat. Fat</div>
                    <div className="text-sm font-bold text-[#14532D]">{preview.snackB.scaledNutrition.saturatedFat}g</div>
                  </div>
                  <div>
                    <div className="text-neutral-500 font-sans">Protein</div>
                    <div className="text-sm font-bold text-[#14532D]">{preview.snackB.scaledNutrition.protein}g</div>
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </section>

      {/* How NutriLens Works */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="max-w-2xl mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900">
            How NutriLens Works
          </h2>
          <p className="text-sm sm:text-base text-neutral-600 mt-2">
            Built around transparent food-composition data and reproducible mathematical models instead of guesswork.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              step: '01. Standardize',
              title: 'Normalize Any Serving',
              body: 'Switch seamlessly between per-100g/100ml baselines and actual canteen serving sizes so packet weights cannot hide excess fat or sugar.',
            },
            {
              step: '02. Grade',
              title: 'Nutri-Score Profiling',
              body: 'Every snack receives an A–E grade and UK FSA traffic-light flags from energy, sugar, saturated fat, sodium, fiber, and protein.',
            },
            {
              step: '03. Recommend',
              title: 'Euclidean Swap Matching',
              body: 'Our recommender matches texture, taste profile, and normalized nutritional distance to suggest affordable ₹10–₹35 Indian swaps.',
            },
            {
              step: '04. Track',
              title: 'Log Cumulative Savings',
              body: 'Click "I Swapped This!" to persist real calorie, sugar, and sodium savings to your dashboard and 7-day campus challenge.',
            },
          ].map((item) => (
            <div key={item.step} className="rounded-xl border border-neutral-200 bg-white p-5">
              <div className="text-xs font-mono font-semibold text-[#14532D]">{item.step}</div>
              <h3 className="text-base font-bold text-neutral-900 mt-2">{item.title}</h3>
              <p className="text-sm text-neutral-600 mt-2 leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Asymmetric Feature Capabilities + Student Benefits */}
      <section className="border-t border-neutral-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 rounded-2xl border border-neutral-200 bg-[#FAFAFA] p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#14532D] mb-2">
                  <Utensils className="w-4 h-4" />
                  <span>Built for Indian Hostels &amp; Canteens</span>
                </div>
                <h2 className="text-2xl font-bold text-neutral-900">
                  Practical Alternatives Under ₹35 With Zero Kitchen Setup
                </h2>
                <p className="text-sm text-neutral-600 mt-2 leading-relaxed max-w-xl">
                  From roasted chana and dry-roasted makhana to kettle boiled corn, sprouted moong,
                  and buttermilk, every swap is grounded in what students can actually buy at a hostel gate or kirana store.
                </p>
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-neutral-700">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                    <span>Interactive Sugar Cube Visualizer for colas and iced teas</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                    <span>Live Barcode Scanner powered by Open Food Facts API</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                    <span>MET-based walking, jogging, and cycling calorie context</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                    <span>7-Day Smart Swap Challenge with earned achievement badges</span>
                  </div>
                </div>
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  to="/hostel-hacks"
                  className="px-4 py-2 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors"
                >
                  Browse Hostel Hacks
                </Link>
                <Link
                  to="/scanner"
                  className="px-4 py-2 text-sm font-semibold text-neutral-800 bg-white border border-neutral-300 hover:bg-neutral-50 rounded-lg transition-colors"
                >
                  Try Barcode Scanner
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5 grid grid-cols-1 gap-6">
              <div className="rounded-2xl border border-neutral-200 overflow-hidden bg-white">
                <div className="h-48 overflow-hidden">
                  <ImageWithFallback
                    src="/src/assets/images/snacks_healthy_makhana_1795108841499.jpg"
                    alt="Roasted makhana and roasted chana healthy Indian snacks"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#14532D]">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Transparent Sources</span>
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 mt-1">
                    IFCT 2017, USDA &amp; Label Verification
                  </h3>
                  <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                    Every snack explicitly states its nutrition source and verification level — never presenting rough estimates as clinical facts.
                  </p>
                  <Link
                    to="/methodology"
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#14532D] mt-3 hover:underline"
                  >
                    <Scale className="w-3.5 h-3.5" />
                    <span>Inspect Scoring Methodology</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
