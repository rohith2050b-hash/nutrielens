import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeftRight,
  CheckCircle2,
  Minus,
  Sparkles,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { ComparisonBasis, ComparisonResult, Snack } from '../types/index.ts';
import { getUnitBasis, setUnitBasis } from '../utils/nutrition.ts';
import { GradeBadge } from '../components/GradeBadge.tsx';
import { NutritionBarChart } from '../components/NutritionBarChart.tsx';
import { NutritionRadarChart } from '../components/NutritionRadarChart.tsx';
import { SugarCubeVisualizer } from '../components/SugarCubeVisualizer.tsx';

export function ComparePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [allSnacks, setAllSnacks] = useState<Snack[]>([]);
  const [snackAId, setSnackAId] = useState(() => searchParams.get('a') || 'potato-chips');
  const [snackBId, setSnackBId] = useState(() => searchParams.get('b') || 'roasted-salted-makhana');
  const [basis, setBasis] = useState<ComparisonBasis>(() => getUnitBasis());

  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [swapSubmitting, setSwapSubmitting] = useState(false);
  const [swapMessage, setSwapMessage] = useState<string | null>(null);
  const [swapError, setSwapError] = useState<string | null>(null);
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);

  useEffect(() => {
    api
      .searchSnacks({ limit: 100, sortBy: 'name', sortOrder: 'asc' })
      .then((res) => setAllSnacks(res.items))
      .catch(() => {
        // handled if compare fails
      });
  }, []);

  useEffect(() => {
    if (!snackAId || !snackBId) return;
    let active = true;
    setLoading(true);
    setError(null);
    setSwapMessage(null);
    setSwapError(null);
    setUnlockedBadges([]);

    api
      .compareSnacks(snackAId, snackBId, basis)
      .then((res) => {
        if (active) setComparison(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to compare snacks.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [snackAId, snackBId, basis]);

  const handleSelectA = (val: string) => {
    setSnackAId(val);
    setSearchParams({ a: val, b: snackBId });
  };

  const handleSelectB = (val: string) => {
    setSnackBId(val);
    setSearchParams({ a: snackAId, b: val });
  };

  const handleFlip = () => {
    setSnackAId(snackBId);
    setSnackBId(snackAId);
    setSearchParams({ a: snackBId, b: snackAId });
  };

  const handleBasisChange = (next: ComparisonBasis) => {
    setBasis(next);
    setUnitBasis(next);
  };

  const handleRecordSwap = async () => {
    if (!comparison) return;
    setSwapSubmitting(true);
    setSwapMessage(null);
    setSwapError(null);
    setUnlockedBadges([]);
    try {
      const res = await api.recordSwap({
        originalSnackId: comparison.snackA.id,
        replacementSnackId: comparison.snackB.id,
        basis,
      });
      setSwapMessage(
        `Swap recorded: ${comparison.snackA.name} → ${comparison.snackB.name} (${res.swapLog.caloriesSaved} kcal difference).`
      );
      if (res.newlyUnlockedAchievements.length > 0) {
        setUnlockedBadges(res.newlyUnlockedAchievements.map((a) => a.title));
      }
    } catch (err) {
      setSwapError(err instanceof Error ? err.message : 'Could not record swap.');
    } finally {
      setSwapSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
            Side-by-Side Nutrition Comparison
          </h1>
          <p className="text-sm text-neutral-600 mt-0.5">
            Compare any two snacks per serving or on a standardized 100g/100ml baseline.
          </p>
        </div>

        <div
          className="inline-flex items-center p-1 bg-neutral-200/70 rounded-lg text-xs"
          role="group"
          aria-label="Comparison baseline"
        >
          <button
            type="button"
            onClick={() => handleBasisChange('serving')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap ${
              basis === 'serving' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
            }`}
          >
            Per Serving
          </button>
          <button
            type="button"
            onClick={() => handleBasisChange('100g')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap ${
              basis === '100g' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
            }`}
          >
            Per 100g / 100ml
          </button>
        </div>
      </div>

      {/* Snack Selector Bar */}
      <div className="rounded-xl border border-neutral-200 bg-white p-4">
        <div className="grid grid-cols-1 md:grid-cols-11 gap-3 items-end">
          <div className="md:col-span-5">
            <label className="block text-xs font-medium text-neutral-600 mb-1">
              Original Snack (Replacing)
            </label>
            <select
              value={snackAId}
              onChange={(e) => handleSelectA(e.target.value)}
              aria-label="Original snack"
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              {allSnacks.length === 0 && <option value={snackAId}>{snackAId}</option>}
              {allSnacks.map((s) => (
                <option key={s.id} value={s.slug}>
                  {s.name} ({s.nutrition?.healthGrade ?? '-'}) — {s.servingLabel}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-1 flex justify-center">
            <button
              type="button"
              onClick={handleFlip}
              title="Swap positions"
              aria-label="Swap snacks"
              className="p-2.5 rounded-lg border border-neutral-200 text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900 transition-colors"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          <div className="md:col-span-5">
            <label className="block text-xs font-medium text-neutral-600 mb-1">
              Alternative Snack (Swapping To)
            </label>
            <select
              value={snackBId}
              onChange={(e) => handleSelectB(e.target.value)}
              aria-label="Alternative snack"
              className="w-full px-3 py-2 text-sm rounded-lg border border-neutral-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
            >
              {allSnacks.length === 0 && <option value={snackBId}>{snackBId}</option>}
              {allSnacks.map((s) => (
                <option key={s.id} value={s.slug}>
                  {s.name} ({s.nutrition?.healthGrade ?? '-'}) — {s.servingLabel}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-neutral-100 flex flex-wrap items-center gap-2 text-xs text-neutral-500">
          <span>Quick presets:</span>
          {[
            { label: 'Potato Chips vs Roasted Makhana', a: 'potato-chips', b: 'roasted-salted-makhana' },
            { label: 'Samosa vs Baked Soya Crisps', a: 'samosa', b: 'baked-soya-crisps' },
            { label: 'Cola vs Unsweetened Lemon Water', a: 'cola', b: 'unsweetened-lemon-water' },
            { label: 'Instant Noodles vs Vegetable Poha', a: 'instant-noodles', b: 'vegetable-poha' },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => {
                setSnackAId(preset.a);
                setSnackBId(preset.b);
                setSearchParams({ a: preset.a, b: preset.b });
              }}
              className="px-2.5 py-1 rounded-md bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-medium transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900">
          {error}
        </div>
      )}

      {loading ? (
        <div className="h-96 rounded-xl border border-neutral-200 bg-white animate-pulse" />
      ) : comparison ? (
        <>
          {/* Summary + I Swapped This! CTA */}
          <div className="rounded-xl border border-[#14532D]/25 bg-white p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#14532D]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Comparison Summary ({basis === 'serving' ? 'Selected Servings' : 'Standardized 100g/ml'})</span>
              </div>
              <ul className="space-y-1.5 text-sm text-neutral-800">
                {comparison.headlineInsights.map((insight, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#14532D] shrink-0" />
                    <span className="font-medium tabular-nums">{insight}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-2 shrink-0">
              <button
                type="button"
                disabled={swapSubmitting || comparison.snackA.id === comparison.snackB.id}
                onClick={handleRecordSwap}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap"
              >
                {swapSubmitting ? 'Recording Swap...' : 'I Swapped This!'}
              </button>
              <span className="text-[11px] text-neutral-500">
                Saves nutritional savings to your tracker &amp; dashboard
              </span>
            </div>
          </div>

          {swapMessage && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-950 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="font-semibold">{swapMessage}</div>
                {unlockedBadges.length > 0 && (
                  <div className="text-xs text-[#14532D] mt-1">
                    Achievement unlocked: {unlockedBadges.join(', ')}
                  </div>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs font-semibold">
                <Link to="/dashboard" className="text-[#14532D] underline">
                  View Updated Dashboard
                </Link>
                <Link to="/swaps" className="text-[#14532D] underline">
                  My Snack Swaps
                </Link>
              </div>
            </div>
          )}

          {swapError && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950">
              {swapError}
            </div>
          )}

          {/* Side-by-Side Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {[
              { item: comparison.snackA, label: comparison.basisLabelA, role: 'Original Snack' },
              { item: comparison.snackB, label: comparison.basisLabelB, role: 'Alternative Snack' },
            ].map(({ item, label, role }) => (
              <div key={item.id + role} className="rounded-xl border border-neutral-200 bg-white p-5">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs text-neutral-500">
                    {role} · {item.category} · {label}
                  </span>
                  <GradeBadge grade={item.nutrition?.healthGrade ?? 'C'} showLabel size="sm" />
                </div>
                <Link
                  to={`/snacks/${item.slug}`}
                  className="text-lg font-bold text-neutral-900 hover:text-[#14532D]"
                >
                  {item.name}
                </Link>
                <p className="text-xs text-neutral-600 mt-1">{item.description}</p>
                <div className="mt-4 pt-3 border-t border-neutral-100 grid grid-cols-4 gap-2 text-xs font-mono tabular-nums">
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Calories</div>
                    <div className="font-bold text-neutral-900">{item.scaledNutrition.calories} kcal</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Sat. Fat</div>
                    <div className="font-bold text-neutral-900">{item.scaledNutrition.saturatedFat}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Sugar</div>
                    <div className="font-bold text-neutral-900">{item.scaledNutrition.sugar}g</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-sans text-neutral-500">Protein</div>
                    <div className="font-bold text-neutral-900">{item.scaledNutrition.protein}g</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Interactive Comparison Table */}
          <div className="rounded-xl border border-neutral-200 bg-white overflow-hidden">
            <div className="px-5 py-4 border-b border-neutral-200 flex items-center justify-between">
              <h2 className="text-base font-bold text-neutral-900">Detailed Nutritional Delta</h2>
              <span className="text-xs text-neutral-500">
                Green = Improvement · Red = Higher value requiring attention
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-neutral-50 border-b border-neutral-200 text-xs text-neutral-600">
                  <tr>
                    <th className="text-left font-semibold px-5 py-3">Nutrient</th>
                    <th className="text-right font-semibold px-4 py-3">{comparison.snackA.name}</th>
                    <th className="text-right font-semibold px-4 py-3">{comparison.snackB.name}</th>
                    <th className="text-right font-semibold px-4 py-3">Difference</th>
                    <th className="text-left font-semibold px-5 py-3">Assessment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {comparison.metrics.map((m) => {
                    const sign = m.delta > 0 ? '+' : '';
                    const badgeTone =
                      m.status === 'improvement'
                        ? 'text-[#14532D] bg-emerald-50 border-emerald-200'
                        : m.status === 'attention'
                          ? 'text-[#B91C1C] bg-red-50 border-red-200'
                          : 'text-neutral-600 bg-neutral-50 border-neutral-200';
                    const StatusIcon =
                      m.status === 'improvement'
                        ? CheckCircle2
                        : m.status === 'attention'
                          ? AlertTriangle
                          : Minus;
                    const statusLabel =
                      m.status === 'improvement'
                        ? 'Improvement'
                        : m.status === 'attention'
                          ? 'Needs attention'
                          : 'Neutral';

                    return (
                      <tr key={m.key} className="hover:bg-neutral-50/70">
                        <td className="px-5 py-3 font-medium text-neutral-900">{m.label}</td>
                        <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-700">
                          {m.snackAValue}{m.unit}
                        </td>
                        <td className="px-4 py-3 text-right font-mono tabular-nums font-semibold text-neutral-900">
                          {m.snackBValue}{m.unit}
                        </td>
                        <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-800">
                          {sign}{m.delta}{m.unit}
                          {m.percentChange !== null && (
                            <span className="text-xs text-neutral-500 ml-1">
                              ({m.percentChange > 0 ? '+' : ''}{m.percentChange}%)
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md border text-xs font-medium ${badgeTone}`}
                          >
                            <StatusIcon className="w-3.5 h-3.5 shrink-0" />
                            <span>{statusLabel}</span>
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Chart.js Bar Chart & Radar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-xl border border-neutral-200 bg-white p-5">
              <h3 className="text-base font-bold text-neutral-900 mb-1">Macronutrient Bar Chart</h3>
              <p className="text-xs text-neutral-500 mb-4">
                Side-by-side grams comparison ({basis === 'serving' ? 'per selected serving' : 'per 100g/ml'})
              </p>
              <NutritionBarChart comparison={comparison} />
            </div>

            <div className="rounded-xl border border-neutral-200 bg-white p-5">
              <h3 className="text-base font-bold text-neutral-900 mb-1">Nutritional Profile Radar</h3>
              <p className="text-xs text-neutral-500 mb-4">
                Normalized 7-axis profile comparing energy, risk nutrients, and positive nutrients
              </p>
              <NutritionRadarChart comparison={comparison} />
            </div>
          </div>

          {/* Sugar Cube Visualizer if either snack is a beverage or sweet */}
          {(comparison.snackA.nutrition?.isBeverage ||
            comparison.snackB.nutrition?.isBeverage ||
            comparison.snackA.scaledNutrition.sugar >= 4 ||
            comparison.snackB.scaledNutrition.sugar >= 4) && (
            <SugarCubeVisualizer
              snackName={comparison.snackA.name}
              sugarGrams={comparison.snackA.scaledNutrition.sugar}
              basisLabel={comparison.basisLabelA}
              compareToName={comparison.snackB.name}
              compareToSugarGrams={comparison.snackB.scaledNutrition.sugar}
            />
          )}
        </>
      ) : null}
    </div>
  );
}
