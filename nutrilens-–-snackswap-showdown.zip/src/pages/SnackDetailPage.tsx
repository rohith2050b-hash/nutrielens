import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowLeftRight,
  Check,
  CheckCircle2,
  Database,
  Sparkles,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { ComparisonBasis, RecommendationItem, SnackDetail } from '../types/index.ts';
import {
  formatBasisLabel,
  getBodyWeightKg,
  getUnitBasis,
  scaleSnackNutrient,
  setUnitBasis,
} from '../utils/nutrition.ts';
import { GradeBadge, NutriScoreScale, TrafficLightGrid } from '../components/GradeBadge.tsx';
import { ExerciseEquivalencyCard } from '../components/ExerciseEquivalencyCard.tsx';
import { SugarCubeVisualizer } from '../components/SugarCubeVisualizer.tsx';
import { ImageWithFallback } from '../components/ImageWithFallback.tsx';

export function SnackDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [snack, setSnack] = useState<SnackDetail | null>(null);
  const [recommendations, setRecommendations] = useState<RecommendationItem[]>([]);
  const [basis, setBasis] = useState<ComparisonBasis>(() => getUnitBasis());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [swapFeedback, setSwapFeedback] = useState<string | null>(null);
  const [submittingSwapId, setSubmittingSwapId] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    let active = true;
    setLoading(true);
    setError(null);

    Promise.all([
      api.getSnackDetail(id, getBodyWeightKg()),
      api.getRecommendations(id, 3),
    ])
      .then(([detail, recRes]) => {
        if (!active) return;
        setSnack(detail);
        setRecommendations(recRes.recommendations);
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Snack details unavailable.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [id]);

  const handleBasisChange = (next: ComparisonBasis) => {
    setBasis(next);
    setUnitBasis(next);
  };

  const handleQuickSwap = async (replacementId: string, replacementName: string) => {
    if (!snack) return;
    setSubmittingSwapId(replacementId);
    setSwapFeedback(null);
    try {
      await api.recordSwap({
        originalSnackId: snack.id,
        replacementSnackId: replacementId,
        basis,
      });
      setSwapFeedback(`Logged swap: ${snack.name} → ${replacementName}. Dashboard updated.`);
    } catch (err) {
      setSwapFeedback(err instanceof Error ? err.message : 'Could not log swap.');
    } finally {
      setSubmittingSwapId(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-44 rounded-xl border border-neutral-200 bg-white animate-pulse" />
        <div className="h-64 rounded-xl border border-neutral-200 bg-white animate-pulse" />
      </div>
    );
  }

  if (error || !snack || !snack.nutrition) {
    return (
      <div className="space-y-4">
        <Link to="/snacks" className="inline-flex items-center gap-1.5 text-sm font-medium text-neutral-700 hover:text-neutral-900">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Snack Explorer</span>
        </Link>
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-900">
          {error || 'Snack not found.'}
        </div>
      </div>
    );
  }

  const scaled = scaleSnackNutrient(snack.nutrition, snack.servingSizeGrams, basis);
  const basisLabel = formatBasisLabel(snack, basis);
  const showSugarCube = snack.nutrition.isBeverage || snack.nutrition.sugar >= 4;

  const nutrientRows = [
    { label: 'Energy (Calories)', value: `${scaled.calories}`, unit: 'kcal' },
    { label: 'Total Fat', value: `${scaled.totalFat}`, unit: 'g' },
    { label: 'Saturated Fat', value: `${scaled.saturatedFat}`, unit: 'g' },
    { label: 'Carbohydrates', value: `${scaled.carbohydrates}`, unit: 'g' },
    { label: 'Total Sugar', value: `${scaled.sugar}`, unit: 'g' },
    { label: 'Protein', value: `${scaled.protein}`, unit: 'g' },
    { label: 'Dietary Fiber', value: `${scaled.fiber}`, unit: 'g' },
    { label: 'Sodium', value: `${scaled.sodium}`, unit: 'mg' },
  ];

  const highFlags = snack.gradeAnalysis?.trafficLights.filter((t) => t.level === 'High') ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/snacks"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Explorer</span>
        </Link>

        <div
          className="inline-flex items-center p-1 bg-neutral-200/70 rounded-lg text-xs"
          role="group"
          aria-label="Display unit"
        >
          <button
            type="button"
            onClick={() => handleBasisChange('serving')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap ${
              basis === 'serving' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
            }`}
          >
            Per Serving ({snack.servingSizeGrams}{snack.servingUnit})
          </button>
          <button
            type="button"
            onClick={() => handleBasisChange('100g')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap ${
              basis === '100g' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
            }`}
          >
            Per 100{snack.servingUnit}
          </button>
        </div>
      </div>

      {/* Header Overview Card */}
      <div className="rounded-xl border border-neutral-200 bg-white overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-4 h-56 lg:h-auto bg-neutral-100">
            <ImageWithFallback
              src={snack.imageUrl}
              alt={snack.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="lg:col-span-8 p-6 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-neutral-500">
                  {snack.category} · {snack.texture} · {snack.tasteProfile} · ₹{snack.priceInrMin}–₹{snack.priceInrMax} · {snack.availability}
                </div>
                <GradeBadge grade={snack.nutrition.healthGrade} showLabel size="md" />
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 mt-2">
                {snack.name}
              </h1>
              <p className="text-sm text-neutral-600 mt-1.5 leading-relaxed">
                {snack.description}
              </p>

              {highFlags.length > 0 && (
                <div className="mt-4 rounded-lg border border-red-200 bg-red-50/70 px-3.5 py-2.5 flex items-start gap-2 text-xs text-red-900">
                  <AlertTriangle className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
                  <span>
                    <strong>High nutrient attention:</strong> High in{' '}
                    {highFlags.map((f) => `${f.nutrient.toLowerCase()} (${f.value}${f.unit}/100${snack.servingUnit})`).join(' and ')}.
                  </span>
                </div>
              )}
            </div>

            <div className="mt-5 pt-4 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-1.5 text-neutral-500">
                <Database className="w-3.5 h-3.5" />
                <span>
                  Source: <strong className="text-neutral-700">{snack.dataSource}</strong> ({snack.verificationStatus})
                </span>
              </div>
              <Link
                to={`/compare?a=${snack.slug}`}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-semibold text-white bg-[#14532D] hover:bg-[#166534] transition-colors"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>Compare This Snack</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Nutrition Table + Health Grade Engine Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <h2 className="text-base font-bold text-neutral-900">Nutrition Facts</h2>
            <span className="text-xs font-mono text-neutral-500">{basisLabel}</span>
          </div>
          <table className="w-full mt-2 text-sm">
            <tbody className="divide-y divide-neutral-100">
              {nutrientRows.map((row) => (
                <tr key={row.label} className="h-10">
                  <td className="text-neutral-700">{row.label}</td>
                  <td className="text-right font-mono font-semibold tabular-nums text-neutral-900">
                    {row.value} <span className="text-xs font-normal text-neutral-500">{row.unit}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:col-span-7 rounded-xl border border-neutral-200 bg-white p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-neutral-900">Health Grading Engine</h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                {snack.gradeAnalysis?.methodology}
              </p>
            </div>
            <NutriScoreScale activeGrade={snack.nutrition.healthGrade} />
          </div>

          {snack.gradeAnalysis && (
            <>
              <div>
                <div className="text-xs font-medium text-neutral-500 mb-2">
                  Traffic-Light Nutrient Indicators (per 100{snack.servingUnit})
                </div>
                <TrafficLightGrid metrics={snack.gradeAnalysis.trafficLights} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="rounded-lg border border-emerald-200/80 bg-emerald-50/40 p-3.5">
                  <div className="font-semibold text-[#14532D] mb-1.5">Nutritional Strengths</div>
                  <ul className="space-y-1 text-neutral-700">
                    {snack.gradeAnalysis.strengths.map((s, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#14532D] shrink-0 mt-0.5" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-lg border border-orange-200/80 bg-orange-50/40 p-3.5">
                  <div className="font-semibold text-[#C2410C] mb-1.5">Areas Requiring Attention</div>
                  <ul className="space-y-1 text-neutral-700">
                    {snack.gradeAnalysis.weaknesses.map((w, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-[#C2410C] shrink-0 mt-0.5" />
                        <span>{w}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="text-xs text-neutral-600 leading-relaxed bg-neutral-50 border border-neutral-200/70 rounded-lg p-3.5">
                <p>{snack.gradeAnalysis.explanation}</p>
                <p className="text-neutral-500 mt-1.5">{snack.gradeAnalysis.disclaimer}</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Sugar Cube Visualizer (for beverages & sugary snacks) */}
      {showSugarCube && (
        <SugarCubeVisualizer
          snackName={snack.name}
          sugarGrams={scaled.sugar}
          basisLabel={basisLabel}
        />
      )}

      {/* Exercise Equivalency */}
      <ExerciseEquivalencyCard calories={scaled.calories} basisLabel={basisLabel} />

      {/* Intelligent Healthy Swap Recommendations */}
      <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#14532D]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Normalized Euclidean Distance Recommender</span>
            </div>
            <h2 className="text-lg font-bold text-neutral-900 mt-0.5">
              Recommended Healthier Swaps
            </h2>
          </div>
          {swapFeedback && (
            <div className="text-xs font-medium text-[#14532D] bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 flex items-center gap-2">
              <Check className="w-3.5 h-3.5" />
              <span>{swapFeedback}</span>
              <Link to="/dashboard" className="underline font-semibold ml-1">
                View Dashboard
              </Link>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendations.map((rec) => (
            <div
              key={rec.snack.id}
              className="rounded-xl border border-neutral-200 bg-[#FAFAFA] p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-mono font-semibold text-[#14532D] tabular-nums">
                    {rec.matchScore}% Match · {rec.priceRange}
                  </span>
                  <GradeBadge grade={rec.snack.nutrition?.healthGrade ?? 'A'} size="sm" />
                </div>

                <Link
                  to={`/snacks/${rec.snack.slug}`}
                  className="text-base font-bold text-neutral-900 hover:text-[#14532D]"
                >
                  {rec.snack.name}
                </Link>

                <div className="text-xs font-mono text-neutral-600 mt-1 tabular-nums">
                  {rec.snack.nutrition?.calories} kcal / 100{rec.snack.servingUnit} ·{' '}
                  {rec.snack.nutrition?.protein}g protein
                </div>

                <p className="text-xs text-neutral-600 mt-2.5 leading-relaxed">
                  {rec.whySuitable}
                </p>

                <ul className="mt-3 space-y-1 text-xs text-neutral-700">
                  {rec.advantages.slice(0, 3).map((adv, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#14532D] shrink-0 mt-0.5" />
                      <span>{adv}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => navigate(`/compare?a=${snack.slug}&b=${rec.snack.slug}`)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-800 bg-white border border-neutral-300 hover:bg-neutral-50 rounded-lg transition-colors"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>Compare</span>
                </button>
                <button
                  type="button"
                  disabled={submittingSwapId === rec.snack.id}
                  onClick={() => handleQuickSwap(rec.snack.id, rec.snack.name)}
                  className="flex-1 px-3 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#166534] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
                >
                  {submittingSwapId === rec.snack.id ? 'Saving...' : 'I Swapped This!'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
