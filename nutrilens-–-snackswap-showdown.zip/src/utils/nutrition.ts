import { ComparisonBasis, NutritionalProfile, Snack } from '../types/index.ts';

const GUEST_ID_KEY = 'nutrilens_guest_id';
const UNIT_BASIS_KEY = 'nutrilens_unit_basis';
const SUGAR_CUBE_WEIGHT_KEY = 'nutrilens_sugar_cube_grams';
const BODY_WEIGHT_KEY = 'nutrilens_body_weight_kg';

export function getGuestId(): string {
  try {
    let existing = localStorage.getItem(GUEST_ID_KEY);
    if (!existing || existing.length < 4) {
      existing = `guest-${Math.random().toString(36).slice(2, 10)}`;
      localStorage.setItem(GUEST_ID_KEY, existing);
    }
    return existing;
  } catch {
    return 'campus-guest-default';
  }
}

export function getUnitBasis(): ComparisonBasis {
  try {
    const val = localStorage.getItem(UNIT_BASIS_KEY);
    return val === '100g' ? '100g' : 'serving';
  } catch {
    return 'serving';
  }
}

export function setUnitBasis(basis: ComparisonBasis): void {
  try {
    localStorage.setItem(UNIT_BASIS_KEY, basis);
  } catch {
    // ignore storage quota errors
  }
}

export function getSugarCubeGrams(): number {
  try {
    const raw = Number(localStorage.getItem(SUGAR_CUBE_WEIGHT_KEY));
    if (raw === 4 || raw === 5) return raw;
    return 4;
  } catch {
    return 4;
  }
}

export function setSugarCubeGrams(grams: number): void {
  try {
    localStorage.setItem(SUGAR_CUBE_WEIGHT_KEY, String(grams));
  } catch {
    // ignore
  }
}

export function getBodyWeightKg(): number {
  try {
    const raw = Number(localStorage.getItem(BODY_WEIGHT_KEY));
    if (Number.isFinite(raw) && raw >= 35 && raw <= 160) return raw;
    return 65;
  } catch {
    return 65;
  }
}

export function setBodyWeightKg(kg: number): void {
  try {
    localStorage.setItem(BODY_WEIGHT_KEY, String(kg));
  } catch {
    // ignore
  }
}

export function scaleSnackNutrient(
  nutrition: NutritionalProfile,
  servingSizeGrams: number,
  basis: ComparisonBasis
) {
  const factor = basis === 'serving' ? servingSizeGrams / 100 : 1;
  return {
    calories: Math.round(nutrition.calories * factor),
    totalFat: Number((nutrition.totalFat * factor).toFixed(1)),
    saturatedFat: Number((nutrition.saturatedFat * factor).toFixed(1)),
    carbohydrates: Number((nutrition.carbohydrates * factor).toFixed(1)),
    sugar: Number((nutrition.sugar * factor).toFixed(1)),
    protein: Number((nutrition.protein * factor).toFixed(1)),
    fiber: Number((nutrition.fiber * factor).toFixed(1)),
    sodium: Math.round(nutrition.sodium * factor),
  };
}

export function formatBasisLabel(snack: Pick<Snack, 'servingLabel' | 'servingUnit'>, basis: ComparisonBasis) {
  return basis === 'serving' ? snack.servingLabel : `Per 100${snack.servingUnit}`;
}

export function computeExerciseMinutes(calories: number, weightKg: number) {
  const safeWeight = Number.isFinite(weightKg) && weightKg >= 30 && weightKg <= 200 ? weightKg : 65;
  const safeCal = Math.max(0, calories);
  const calc = (met: number) => Math.round(safeCal / ((met * 3.5 * safeWeight) / 200));
  return {
    walking: calc(3.5),
    jogging: calc(7.0),
    cycling: calc(6.0),
  };
}
