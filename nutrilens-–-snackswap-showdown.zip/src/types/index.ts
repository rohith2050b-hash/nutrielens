export type HealthGrade = 'A' | 'B' | 'C' | 'D' | 'E';
export type ComparisonBasis = '100g' | 'serving';
export type TrafficLightLevel = 'Low' | 'Moderate' | 'High';

export interface NutritionalProfile {
  id?: string;
  snackId?: string;
  calories: number;
  totalFat: number;
  saturatedFat: number;
  carbohydrates: number;
  sugar: number;
  protein: number;
  fiber: number;
  sodium: number;
  healthGrade: HealthGrade;
  gradeScore: number;
  isBeverage: boolean;
}

export interface Snack {
  id: string;
  slug: string;
  name: string;
  category: string;
  description: string;
  servingSizeGrams: number;
  servingUnit: string;
  servingLabel: string;
  isHealthyAlternative: boolean;
  texture: string;
  tasteProfile: string;
  priceInrMin: number;
  priceInrMax: number;
  availability: string;
  imageUrl: string;
  barcode: string | null;
  dataSource: string;
  verificationStatus: string;
  nutrition: NutritionalProfile | null;
}

export interface TrafficLightMetric {
  nutrient: 'Total Fat' | 'Saturated Fat' | 'Sugar' | 'Sodium';
  value: number;
  unit: string;
  level: TrafficLightLevel;
  color: 'green' | 'amber' | 'red';
}

export interface GradeBreakdown {
  healthGrade: HealthGrade;
  gradeLabel: string;
  gradeScore: number;
  methodology: string;
  points: {
    energy: number;
    sugar: number;
    saturatedFat: number;
    sodium: number;
    negativeTotal: number;
    fiber: number;
    protein: number;
    proteinApplied: number;
    positiveTotal: number;
  };
  trafficLights: TrafficLightMetric[];
  strengths: string[];
  weaknesses: string[];
  explanation: string;
  disclaimer: string;
}

export interface ExerciseActivity {
  key: 'walking' | 'jogging' | 'cycling';
  label: string;
  description: string;
  met: number;
  minutes: number;
  kcalPerMinute: number;
}

export interface ExerciseEquivalencyResult {
  calories: number;
  bodyWeightKg: number;
  activities: ExerciseActivity[];
  formula: string;
  disclaimer: string;
}

export interface SnackDetail extends Snack {
  gradeAnalysis: GradeBreakdown | null;
  exerciseEquivalency: {
    perServing: ExerciseEquivalencyResult;
    per100g: ExerciseEquivalencyResult;
  };
}

export interface RecommendationItem {
  snack: Snack;
  matchScore: number;
  euclideanDistance: number;
  priceRange: string;
  advantages: string[];
  whySuitable: string;
  matchedDimensions: {
    textureMatch: boolean;
    tasteMatch: boolean;
    beverageMatch: boolean;
    curatedRule: boolean;
  };
}

export interface ScaledNutrition {
  calories: number;
  totalFat: number;
  saturatedFat: number;
  carbohydrates: number;
  sugar: number;
  protein: number;
  fiber: number;
  sodium: number;
}

export interface MetricDelta {
  key: keyof ScaledNutrition;
  label: string;
  unit: string;
  snackAValue: number;
  snackBValue: number;
  delta: number;
  percentChange: number | null;
  direction: 'lower_is_better' | 'higher_is_better' | 'neutral_macro';
  status: 'improvement' | 'attention' | 'neutral';
}

export interface ComparisonResult {
  basis: ComparisonBasis;
  basisLabelA: string;
  basisLabelB: string;
  snackA: Snack & { scaledNutrition: ScaledNutrition };
  snackB: Snack & { scaledNutrition: ScaledNutrition };
  metrics: MetricDelta[];
  savings: {
    caloriesSaved: number;
    sugarReduced: number;
    sodiumReduced: number;
    saturatedFatReduced: number;
    proteinGained: number;
    fiberGained: number;
  };
  headlineInsights: string[];
}

export interface SwapLogEntry {
  id: string;
  originalSnackId: string;
  replacementSnackId: string;
  originalSnack: Snack;
  replacementSnack: Snack;
  basis: ComparisonBasis;
  caloriesSaved: number;
  sugarReduced: number;
  sodiumReduced: number;
  saturatedFatReduced: number;
  proteinGained: number;
  fiberGained: number;
  swappedAt: string;
}

export interface SwapSummary {
  totalSwaps: number;
  caloriesSaved: number;
  sugarReduced: number;
  sodiumReduced: number;
  saturatedFatReduced: number;
  proteinGained: number;
  fiberGained: number;
}

export interface HistoryBucket {
  label: string;
  swaps: number;
  caloriesSaved: number;
  sugarReduced: number;
}

export interface ChallengeDay {
  dayNumber: number;
  completed: boolean;
  completedDate: string | null;
  notes: string | null;
  swapLogId: string | null;
}

export interface AchievementItem {
  id: string;
  code: string;
  title: string;
  description: string;
  criteria: string;
  unlocked: boolean;
  unlockedAt: string | null;
}

export interface ChallengeOverview {
  challenge: {
    id: string;
    title: string;
    description: string;
    targetDays: number;
  };
  days: ChallengeDay[];
  completedCount: number;
  targetDays: number;
  completionPercent: number;
  streak: number;
  achievements: AchievementItem[];
}

export interface DashboardData {
  catalogStats: {
    totalSnacks: number;
    healthyAlternatives: number;
    commonSnacks: number;
  };
  swapSummary: SwapSummary;
  recentSwaps: SwapLogEntry[];
  weeklyProgress: HistoryBucket[];
  challengeSummary: {
    id: string;
    title: string;
    completedCount: number;
    targetDays: number;
    completionPercent: number;
    streak: number;
    days: ChallengeDay[];
    unlockedBadgesCount: number;
    totalBadgesCount: number;
  };
  recommendedAlternatives: Snack[];
}

export interface BarcodeLookupResult {
  source: 'local_catalog' | 'open_food_facts';
  barcode: string;
  product: {
    id: string | null;
    name: string;
    brand: string;
    category: string;
    servingLabel: string;
    servingSizeGrams: number;
    servingUnit: string;
    imageUrl: string;
    nutritionPer100g: NutritionalProfile;
    missingFields: string[];
  };
  gradeAnalysis: GradeBreakdown;
  recommendations: RecommendationItem[];
}

export interface HostelHackItem {
  id: string;
  slug: string;
  name: string;
  category: string;
  approxCostInr: string;
  prepTimeMinutes: number;
  equipmentNeeded: string;
  ingredients: string[];
  instructions: string[];
  practicalWhy: string;
  caloriesPerServing: number;
  proteinPerServing: number;
  fiberPerServing: number;
  sugarPerServing: number;
  linkedSnackSlug: string | null;
  imageUrl: string;
}
