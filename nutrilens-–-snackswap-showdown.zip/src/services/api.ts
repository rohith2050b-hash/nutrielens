import {
  BarcodeLookupResult,
  ChallengeOverview,
  ComparisonBasis,
  ComparisonResult,
  DashboardData,
  HealthGrade,
  HostelHackItem,
  RecommendationItem,
  Snack,
  SnackDetail,
  SwapLogEntry,
  SwapSummary,
  HistoryBucket,
} from '../types/index.ts';
import { getGuestId } from '../utils/nutrition.ts';

interface ApiEnvelope<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export class ApiClientError extends Error {
  public readonly code: string;
  public readonly status: number;
  public readonly details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  headers.set('x-guest-id', getGuestId());
  if (init?.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(`/api${path}`, {
    ...init,
    headers,
  });

  const payload = (await res.json().catch(() => ({}))) as ApiEnvelope<T>;
  if (!res.ok || !payload.success || payload.data === undefined) {
    throw new ApiClientError(
      res.status,
      payload.error?.code ?? 'REQUEST_FAILED',
      payload.error?.message ?? `Request failed with status ${res.status}`,
      payload.error?.details
    );
  }

  return payload.data;
}

export interface SearchSnacksParams {
  q?: string;
  category?: string;
  grade?: HealthGrade | '';
  healthyOnly?: boolean;
  sortBy?: 'name' | 'calories' | 'protein' | 'sugar' | 'sodium' | 'gradeScore';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface SearchSnacksResponse {
  items: Snack[];
  categories: string[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export const api = {
  searchSnacks(params: SearchSnacksParams = {}, signal?: AbortSignal) {
    const sp = new URLSearchParams();
    if (params.q) sp.set('q', params.q);
    if (params.category && params.category !== 'All') sp.set('category', params.category);
    if (params.grade) sp.set('grade', params.grade);
    if (params.healthyOnly !== undefined) sp.set('healthyOnly', String(params.healthyOnly));
    if (params.sortBy) sp.set('sortBy', params.sortBy);
    if (params.sortOrder) sp.set('sortOrder', params.sortOrder);
    if (params.page) sp.set('page', String(params.page));
    if (params.limit) sp.set('limit', String(params.limit));
    return request<SearchSnacksResponse>(`/snacks/search?${sp.toString()}`, { signal });
  },

  getSnackDetail(idOrSlug: string, weightKg = 65) {
    return request<SnackDetail>(`/snacks/${encodeURIComponent(idOrSlug)}?weightKg=${weightKg}`);
  },

  getRecommendations(idOrSlug: string, limit = 3) {
    return request<{ sourceSnack: Snack; recommendations: RecommendationItem[] }>(
      `/snacks/${encodeURIComponent(idOrSlug)}/recommendations?limit=${limit}`
    );
  },

  compareSnacks(snackAId: string, snackBId: string, basis: ComparisonBasis = 'serving') {
    return request<ComparisonResult>('/compare', {
      method: 'POST',
      body: JSON.stringify({ snackAId, snackBId, basis }),
    });
  },

  getDashboard() {
    return request<DashboardData>('/dashboard');
  },

  getSwaps() {
    return request<{
      summary: SwapSummary;
      logs: SwapLogEntry[];
      history: {
        daily: HistoryBucket[];
        weekly: HistoryBucket[];
        monthly: HistoryBucket[];
      };
    }>('/swaps');
  },

  recordSwap(payload: {
    originalSnackId: string;
    replacementSnackId: string;
    basis: ComparisonBasis;
    challengeDayNumber?: number;
  }) {
    return request<{
      swapLog: SwapLogEntry;
      newlyUnlockedAchievements: Array<{ code: string; title: string; description: string }>;
    }>('/swaps', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  deleteSwap(swapId: string) {
    return request<{ deletedId: string }>(`/swaps/${encodeURIComponent(swapId)}`, {
      method: 'DELETE',
    });
  },

  getChallenges() {
    return request<ChallengeOverview>('/challenges');
  },

  recordChallengeProgress(
    challengeId: string,
    payload: { dayNumber: number; notes?: string; swapLogId?: string }
  ) {
    return request<{
      progress: unknown;
      newlyUnlockedAchievements: Array<{ code: string; title: string; description: string }>;
    }>(`/challenges/${encodeURIComponent(challengeId)}/progress`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  lookupBarcode(code: string) {
    return request<BarcodeLookupResult>(`/barcode/${encodeURIComponent(code)}`);
  },

  getHostelHacks(category?: string) {
    const qs = category && category !== 'All' ? `?category=${encodeURIComponent(category)}` : '';
    return request<{ items: HostelHackItem[]; categories: string[] }>(`/hostel-hacks${qs}`);
  },
};
