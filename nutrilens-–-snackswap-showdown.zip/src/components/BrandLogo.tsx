export function BrandLogo({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${className}`}>
      <svg
        width="28"
        height="28"
        viewBox="0 0 28 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        <rect width="28" height="28" rx="7" fill="#14532D" />
        <circle cx="13" cy="13" r="6.25" stroke="#ECFDF5" strokeWidth="1.8" />
        <path
          d="M17.6 17.6L21.5 21.5"
          stroke="#ECFDF5"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <path
          d="M10.5 14.2C10.5 11.8 12.6 10.3 15.2 10.5C15.4 13.1 13.9 15.1 11.4 15.1C11 15.1 10.7 14.7 10.5 14.2Z"
          fill="#86EFAC"
        />
      </svg>
      <span className="font-display text-lg font-bold tracking-tight text-neutral-900">
        NutriLens
      </span>
    </span>
  );
}
