import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Tooltip,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { HistoryBucket } from '../types/index.ts';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

export function SwapHistoryChart({ buckets }: { buckets: HistoryBucket[] }) {
  const data = {
    labels: buckets.map((b) => b.label),
    datasets: [
      {
        label: 'Calories Saved (kcal)',
        data: buckets.map((b) => b.caloriesSaved),
        backgroundColor: 'rgba(20, 83, 45, 0.85)',
        borderColor: '#14532D',
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#111827',
        bodyFont: { family: 'JetBrains Mono, monospace', size: 12 },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { family: 'DM Sans, sans-serif', size: 11 } },
      },
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(0,0,0,0.05)' },
        ticks: { font: { family: 'JetBrains Mono, monospace', size: 11 } },
      },
    },
  };

  return (
    <div className="h-[220px] w-full">
      <Bar data={data} options={options} />
    </div>
  );
}
