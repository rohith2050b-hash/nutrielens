import { useState } from 'react';
import { Bike, Footprints, Info, Timer } from 'lucide-react';
import {
  computeExerciseMinutes,
  getBodyWeightKg,
  setBodyWeightKg,
} from '../utils/nutrition.ts';

interface ExerciseEquivalencyCardProps {
  calories: number;
  basisLabel: string;
}

export function ExerciseEquivalencyCard({
  calories,
  basisLabel,
}: ExerciseEquivalencyCardProps) {
  const [weightKg, setWeightKg] = useState<number>(() => getBodyWeightKg());

  const handleWeightChange = (val: number) => {
    const clamped = Math.max(35, Math.min(150, val));
    setWeightKg(clamped);
    setBodyWeightKg(clamped);
  };

  const mins = computeExerciseMinutes(calories, weightKg);

  const items = [
    {
      key: 'walking',
      label: 'Brisk Walking',
      pace: '~4.8 km/h · 3.5 MET',
      minutes: mins.walking,
      Icon: Footprints,
    },
    {
      key: 'jogging',
      label: 'Moderate Jogging',
      pace: '~7.5 km/h · 7.0 MET',
      minutes: mins.jogging,
      Icon: Timer,
    },
    {
      key: 'cycling',
      label: 'Campus Cycling',
      pace: '~16 km/h · 6.0 MET',
      minutes: mins.cycling,
      Icon: Bike,
    },
  ];

  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-5">
      <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-neutral-100">
        <div>
          <h3 className="text-base font-semibold text-neutral-900">
            Calorie Burn Exercise Equivalency
          </h3>
          <p className="text-xs text-neutral-500 mt-0.5 tabular-nums">
            Energy context for {calories} kcal ({basisLabel})
          </p>
        </div>

        <label className="inline-flex items-center gap-2 text-xs text-neutral-600">
          <span className="whitespace-nowrap">Reference weight:</span>
          <input
            type="number"
            min={35}
            max={150}
            value={weightKg}
            onChange={(e) => handleWeightChange(Number(e.target.value) || 65)}
            className="w-16 px-2 py-1 rounded-md border border-neutral-300 text-neutral-900 font-mono tabular-nums text-xs focus:outline-none focus:ring-2 focus:ring-[#14532D]/30"
          />
          <span>kg</span>
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
        {items.map((item) => {
          const Icon = item.Icon;
          return (
            <div
              key={item.key}
              className="rounded-lg border border-neutral-200 bg-neutral-50/70 p-3.5"
            >
              <div className="flex items-center justify-between text-neutral-600 mb-1.5">
                <span className="text-xs font-medium">{item.label}</span>
                <Icon className="w-4 h-4 text-[#14532D]" />
              </div>
              <div className="text-xl font-bold font-mono tabular-nums text-neutral-900">
                {item.minutes} <span className="text-xs font-normal text-neutral-500">min</span>
              </div>
              <div className="text-[11px] text-neutral-500 mt-0.5">{item.pace}</div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex items-start gap-2 text-xs text-neutral-500 bg-neutral-50 rounded-lg p-3 border border-neutral-200/70">
        <Info className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          Calculated via standard MET expenditure (<span className="font-mono">MET × 3.5 × kg ÷ 200</span>).
          These figures are approximate energy comparisons to make calories tangible — not exercise prescriptions or advice to burn off snacks.
        </p>
      </div>
    </div>
  );
}
