import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { HealthGrade, TrafficLightMetric } from '../types/index.ts';

const GRADE_STYLE: Record<
  HealthGrade,
  { bg: string; text: string; border: string; label: string }
> = {
  A: {
    bg: 'bg-[#14532D]',
    text: 'text-white',
    border: 'border-[#14532D]',
    label: 'Healthier Choice',
  },
  B: {
    bg: 'bg-[#4D7C0F]',
    text: 'text-white',
    border: 'border-[#4D7C0F]',
    label: 'Good Choice',
  },
  C: {
    bg: 'bg-[#B45309]',
    text: 'text-white',
    border: 'border-[#B45309]',
    label: 'Moderate',
  },
  D: {
    bg: 'bg-[#C2410C]',
    text: 'text-white',
    border: 'border-[#C2410C]',
    label: 'Less Healthy',
  },
  E: {
    bg: 'bg-[#B91C1C]',
    text: 'text-white',
    border: 'border-[#B91C1C]',
    label: 'Least Healthy',
  },
};

export function GradeBadge({
  grade,
  showLabel = false,
  size = 'md',
}: {
  grade: HealthGrade | string;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}) {
  const safeGrade = (['A', 'B', 'C', 'D', 'E'].includes(grade) ? grade : 'C') as HealthGrade;
  const style = GRADE_STYLE[safeGrade];

  const sizeClass =
    size === 'sm'
      ? 'w-6 h-6 text-xs rounded'
      : size === 'lg'
        ? 'w-11 h-11 text-xl rounded-lg'
        : 'w-8 h-8 text-sm rounded-md';

  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap shrink-0">
      <span
        className={`inline-flex items-center justify-center font-display font-bold tabular-nums ${sizeClass} ${style.bg} ${style.text}`}
        aria-label={`Health Grade ${safeGrade}: ${style.label}`}
      >
        {safeGrade}
      </span>
      {showLabel && (
        <span className="text-sm font-medium text-neutral-700">{style.label}</span>
      )}
    </span>
  );
}

export function NutriScoreScale({ activeGrade }: { activeGrade: HealthGrade | string }) {
  const grades: HealthGrade[] = ['A', 'B', 'C', 'D', 'E'];
  return (
    <div className="inline-flex items-center gap-1" role="group" aria-label="Nutri-Score scale">
      {grades.map((g) => {
        const isActive = g === activeGrade;
        const style = GRADE_STYLE[g];
        return (
          <span
            key={g}
            className={`inline-flex items-center justify-center font-display font-bold transition-transform ${
              isActive
                ? `w-8 h-8 text-sm rounded-md ${style.bg} ${style.text} ring-2 ring-offset-1 ring-neutral-900/20`
                : 'w-6 h-6 text-xs rounded bg-neutral-100 text-neutral-500 border border-neutral-200'
            }`}
          >
            {g}
          </span>
        );
      })}
    </div>
  );
}

export function TrafficLightGrid({ metrics }: { metrics: TrafficLightMetric[] }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {metrics.map((m) => {
        const tone =
          m.color === 'green'
            ? {
                border: 'border-emerald-200 bg-emerald-50/60',
                text: 'text-emerald-900',
                levelText: 'text-emerald-800',
                Icon: CheckCircle2,
              }
            : m.color === 'amber'
              ? {
                  border: 'border-amber-200 bg-amber-50/60',
                  text: 'text-amber-950',
                  levelText: 'text-amber-800',
                  Icon: Info,
                }
              : {
                  border: 'border-red-200 bg-red-50/60',
                  text: 'text-red-950',
                  levelText: 'text-red-800',
                  Icon: AlertTriangle,
                };
        const Icon = tone.Icon;

        return (
          <div
            key={m.nutrient}
            className={`rounded-lg border p-3 ${tone.border}`}
          >
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="text-xs font-medium text-neutral-600">{m.nutrient}</span>
              <Icon className={`w-3.5 h-3.5 shrink-0 ${tone.levelText}`} />
            </div>
            <div className={`text-base font-semibold font-mono tabular-nums ${tone.text}`}>
              {m.value}
              <span className="text-xs font-normal ml-0.5">{m.unit}</span>
            </div>
            <div className={`text-xs font-semibold mt-0.5 ${tone.levelText}`}>
              {m.level}
            </div>
          </div>
        );
      })}
    </div>
  );
}
