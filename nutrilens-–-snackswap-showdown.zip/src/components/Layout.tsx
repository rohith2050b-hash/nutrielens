import { ReactNode, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import {
  ArrowLeftRight,
  Award,
  BookOpen,
  Compass,
  Flame,
  History,
  LayoutDashboard,
  Menu,
  QrCode,
  Sparkles,
  Utensils,
  X,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';

const WORKSPACE_NAV = [
  { to: '/dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { to: '/snacks', label: 'Snack Explorer', Icon: Compass },
  { to: '/compare', label: 'Compare Snacks', Icon: ArrowLeftRight },
  { to: '/recommendations', label: 'Smart Swaps', Icon: Sparkles },
  { to: '/swaps', label: 'My Snack Swaps', Icon: History },
  { to: '/challenge', label: '7-Day Challenge', Icon: Award },
  { to: '/scanner', label: 'Barcode Scanner', Icon: QrCode },
  { to: '/hostel-hacks', label: 'Hostel Snack Hacks', Icon: Utensils },
  { to: '/methodology', label: 'About & Methodology', Icon: BookOpen },
];

const ROUTE_TITLES: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/snacks': 'Snack Explorer',
  '/compare': 'Compare Snacks',
  '/recommendations': 'Healthy Swap Recommendations',
  '/swaps': 'My Snack Swaps',
  '/challenge': 'Weekly Challenge',
  '/scanner': 'Barcode Scanner',
  '/hostel-hacks': 'Hostel Snack Hacks',
  '/methodology': 'About & Methodology',
};

export function LandingLayout({ children }: { children: ReactNode }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-neutral-900">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          <Link to="/" className="whitespace-nowrap shrink-0">
            <BrandLogo />
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600">
            <Link to="/snacks" className="hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0">
              Snacks
            </Link>
            <Link to="/compare" className="hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0">
              Compare
            </Link>
            <Link to="/hostel-hacks" className="hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0">
              Hostel Hacks
            </Link>
            <Link to="/challenge" className="hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0">
              Challenge
            </Link>
            <Link to="/methodology" className="hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0">
              Methodology
            </Link>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <Link
              to="/dashboard"
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Open Dashboard
            </Link>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label="Toggle navigation menu"
              className="md:hidden p-2 rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden border-t border-neutral-200 bg-white px-4 py-3 space-y-1">
            {WORKSPACE_NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-100"
              >
                {item.label}
              </Link>
            ))}
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-neutral-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <BrandLogo />
              <p className="text-sm text-neutral-600 mt-3 max-w-md leading-relaxed">
                NutriLens helps college students inspect snack nutrition on a standardized 100g/100ml baseline,
                compare everyday canteen foods with affordable Indian alternatives, and track measurable nutritional savings.
              </p>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-neutral-900 mb-3">Platform</h4>
              <ul className="space-y-2 text-sm text-neutral-600">
                <li><Link to="/dashboard" className="hover:text-neutral-900">Dashboard</Link></li>
                <li><Link to="/snacks" className="hover:text-neutral-900">Snack Explorer</Link></li>
                <li><Link to="/compare" className="hover:text-neutral-900">Compare Snacks</Link></li>
                <li><Link to="/recommendations" className="hover:text-neutral-900">Swap Recommender</Link></li>
                <li><Link to="/scanner" className="hover:text-neutral-900">Barcode Scanner</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-neutral-900 mb-3">Student Tools</h4>
              <ul className="space-y-2 text-sm text-neutral-600">
                <li><Link to="/swaps" className="hover:text-neutral-900">My Snack Swaps</Link></li>
                <li><Link to="/challenge" className="hover:text-neutral-900">7-Day Challenge</Link></li>
                <li><Link to="/hostel-hacks" className="hover:text-neutral-900">Hostel Snack Hacks</Link></li>
                <li><Link to="/methodology" className="hover:text-neutral-900">Grading Methodology</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-500">
            <span>NutriLens – SnackSwap Showdown · Academic Nutrition Engineering Project</span>
            <span>Educational nutritional profiling only — not medical or clinical dietary advice.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function WorkspaceLayout({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const currentTitle =
    ROUTE_TITLES[location.pathname] ??
    (location.pathname.startsWith('/snacks/') ? 'Snack Details' : 'Workspace');

  return (
    <div className="min-h-screen flex bg-[#FAFAFA] text-neutral-900">
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-60 lg:shrink-0 border-r border-neutral-200 bg-white sticky top-0 h-screen">
        <div className="h-16 px-5 flex items-center border-b border-neutral-200">
          <Link to="/" className="whitespace-nowrap shrink-0">
            <BrandLogo />
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="Workspace navigation">
          {WORKSPACE_NAV.map(({ to, label, Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-[#14532D]/10 text-[#14532D]'
                    : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate">{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-neutral-200 text-xs text-neutral-500">
          <div className="flex items-center gap-1.5 font-medium text-neutral-700">
            <Flame className="w-3.5 h-3.5 text-[#14532D]" />
            <span>Guest Mode Active</span>
          </div>
          <p className="mt-1 leading-relaxed">
            Swaps and challenge progress persist to SQLite via your browser guest key.
          </p>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/30"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="relative z-50 w-64 max-w-[80vw] bg-white h-full border-r border-neutral-200 flex flex-col">
            <div className="h-16 px-5 flex items-center justify-between border-b border-neutral-200">
              <Link to="/" onClick={() => setSidebarOpen(false)}>
                <BrandLogo />
              </Link>
              <button
                type="button"
                onClick={() => setSidebarOpen(false)}
                aria-label="Close navigation"
                className="p-1.5 rounded-md text-neutral-500 hover:bg-neutral-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
              {WORKSPACE_NAV.map(({ to, label, Icon }) => (
                <NavLink
                  key={to}
                  to={to}
                  onClick={() => setSidebarOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-[#14532D]/10 text-[#14532D]'
                        : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
                    }`
                  }
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{label}</span>
                </NavLink>
              ))}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 h-16 bg-white/95 backdrop-blur border-b border-neutral-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-100"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <Link to="/" className="text-neutral-500 hover:text-neutral-900 hidden sm:inline whitespace-nowrap">
                NutriLens
              </Link>
              <span className="text-neutral-300 hidden sm:inline">/</span>
              <span className="font-semibold text-neutral-900 truncate">{currentTitle}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <Link
              to="/compare?a=potato-chips&b=roasted-salted-makhana"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-[#14532D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Quick Compare</span>
            </Link>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1200px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
