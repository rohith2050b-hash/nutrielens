import { useState } from 'react';
import { getSugarCubeGrams, setSugarCubeGrams } from '../utils/nutrition.ts';

interface SugarCubeVisualizerProps {
  snackName: string;
  sugarGrams: number;
  basisLabel: string;
  compareToName?: string;
  compareToSugarGrams?: number;
}

export function SugarCubeVisualizer({
  snackName,
  sugarGrams,
  basisLabel,
  compareToName,
  compareToSugarGrams,
}: SugarCubeVisualizerProps) {
  const [cubeWeight, setCubeWeight] = useState<number>(() => getSugarCubeGrams());

  const handleCubeChange = (grams: number) => {
    setCubeWeight(grams);
    setSugarCubeGrams(grams);
  };

  const exactCubes = sugarGrams / cubeWeight;
  const fullCubes = Math.floor(exactCubes);
  const partialFraction = exactCubes - fullCubes;
  const displayMax = 24;
  const cubesToRender = Math.min(fullCubes, displayMax);
  const overflowCount = Math.max(0, fullCubes - displayMax);

  const compareCubes =
    compareToSugarGrams !== undefined ? compareToSugarGrams / cubeWeight : null;

  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-5">
      <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-neutral-100">
        <div>
          <h3 className="text-base font-semibold text-neutral-900">
            Sugar Cube Visualizer
          </h3>
          <p className="text-xs text-neutral-500 mt-0.5">
            Visualizing <span className="font-medium text-neutral-700">{snackName}</span> ({basisLabel})
          </p>
        </div>
        <div
          className="inline-flex items-center p-1 bg-neutral-100 rounded-lg text-xs"
          role="group"
          aria-label="Sugar cube weight assumption"
        >
          {[4, 5].map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => handleCubeChange(g)}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap shrink-0 transition-colors ${
                cubeWeight === g
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {g}g / cube
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        <div>
          <div className="text-xs text-neutral-500">Total Sugar ({basisLabel})</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 mt-0.5">
            {sugarGrams.toFixed(1)}g
          </div>
          <div className="text-sm font-medium text-neutral-700 mt-1 tabular-nums">
            ≈ <span className="font-semibold text-[#C2410C]">{exactCubes.toFixed(1)}</span> sugar cubes
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Assumption: 1 standard sugar cube = {cubeWeight}g ({cubeWeight === 4 ? '~1 level tsp' : 'metric cube'}).
          </p>
        </div>

        <div className="md:col-span-2 bg-neutral-50 border border-neutral-200/80 rounded-lg p-4">
          {exactCubes < 0.15 ? (
            <div className="text-sm font-medium text-[#14532D]">
              Less than 0.2 sugar cubes ({sugarGrams.toFixed(1)}g sugar) — minimal glycemic sugar load.
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-2" aria-label={`${exactCubes.toFixed(1)} sugar cubes`}>
              {Array.from({ length: cubesToRender }).map((_, idx) => (
                <span
                  key={idx}
                  title={`Sugar cube ${idx + 1} (${cubeWeight}g)`}
                  className="inline-block w-6 h-6 rounded-[4px] bg-white border border-neutral-300 shadow-[inset_-2px_-2px_0_rgba(0,0,0,0.06),0_1px_2px_rgba(0,0,0,0.05)]"
                />
              ))}
              {partialFraction >= 0.15 && (
                <span
                  title={`Partial sugar cube (${(partialFraction * cubeWeight).toFixed(1)}g)`}
                  className="relative inline-block w-6 h-6 rounded-[4px] bg-neutral-200/60 border border-dashed border-neutral-300 overflow-hidden"
                >
                  <span
                    className="absolute bottom-0 left-0 right-0 bg-white border-t border-neutral-300"
                    style={{ height: `${Math.round(partialFraction * 100)}%` }}
                  />
                </span>
              )}
              {overflowCount > 0 && (
                <span className="text-xs font-mono font-semibold text-neutral-600 ml-1">
                  +{overflowCount} more cubes
                </span>
              )}
            </div>
          )}

          {compareToName !== undefined && compareCubes !== null && (
            <div className="mt-3 pt-3 border-t border-neutral-200 text-xs text-neutral-700 flex flex-wrap items-center justify-between gap-2">
              <span>
                Compared to <span className="font-semibold">{compareToName}</span>:{' '}
                <span className="font-mono tabular-nums">{compareToSugarGrams?.toFixed(1)}g</span> ({compareCubes.toFixed(1)} cubes)
              </span>
              {exactCubes > compareCubes && (
                <span className="font-semibold text-[#14532D] tabular-nums">
                  Saves {(exactCubes - compareCubes).toFixed(1)} cubes
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
