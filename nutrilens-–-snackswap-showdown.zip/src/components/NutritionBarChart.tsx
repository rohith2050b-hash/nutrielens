import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Title,
  Tooltip,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { ComparisonResult } from '../types/index.ts';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export function NutritionBarChart({ comparison }: { comparison: ComparisonResult }) {
  const macroKeys = ['totalFat', 'saturatedFat', 'carbohydrates', 'sugar', 'protein', 'fiber'] as const;
  const macroMetrics = macroKeys.map((k) => comparison.metrics.find((m) => m.key === k)!);

  const data = {
    labels: macroMetrics.map((m) => `${m.label} (${m.unit})`),
    datasets: [
      {
        label: comparison.snackA.name,
        data: macroMetrics.map((m) => m.snackAValue),
        backgroundColor: 'rgba(194, 65, 12, 0.78)',
        borderColor: '#C2410C',
        borderWidth: 1,
        borderRadius: 4,
      },
      {
        label: comparison.snackB.name,
        data: macroMetrics.map((m) => m.snackBValue),
        backgroundColor: 'rgba(20, 83, 45, 0.85)',
        borderColor: '#14532D',
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          boxWidth: 8,
          font: { family: 'DM Sans, sans-serif', size: 12 },
        },
      },
      tooltip: {
        backgroundColor: '#111827',
        titleFont: { family: 'Plus Jakarta Sans, sans-serif', size: 12 },
        bodyFont: { family: 'JetBrains Mono, monospace', size: 12 },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { family: 'DM Sans, sans-serif', size: 11 } },
      },
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(0,0,0,0.05)' },
        ticks: { font: { family: 'JetBrains Mono, monospace', size: 11 } },
      },
    },
  };

  return (
    <div className="h-[300px] w-full">
      <Bar data={data} options={options} />
    </div>
  );
}
