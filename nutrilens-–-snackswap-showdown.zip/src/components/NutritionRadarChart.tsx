import {
  Chart as ChartJS,
  Filler,
  Legend,
  LineElement,
  PointElement,
  RadialLinearScale,
  Tooltip,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { ComparisonResult } from '../types/index.ts';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

export function NutritionRadarChart({ comparison }: { comparison: ComparisonResult }) {
  // Normalize each metric to 0-100 relative to a daily snack reference ceiling so radar axes are readable
  const referenceMax: Record<string, number> = {
    calories: 550,
    totalFat: 35,
    saturatedFat: 15,
    sugar: 40,
    sodium: 900,
    protein: 25,
    fiber: 15,
  };

  const keys = ['calories', 'totalFat', 'saturatedFat', 'sugar', 'sodium', 'protein', 'fiber'] as const;
  const selected = keys.map((k) => comparison.metrics.find((m) => m.key === k)!);

  const normalizeVal = (val: number, key: string) =>
    Math.min(100, Math.round((val / (referenceMax[key] || 100)) * 100));

  const data = {
    labels: selected.map((m) => m.label),
    datasets: [
      {
        label: comparison.snackA.name,
        data: selected.map((m) => normalizeVal(m.snackAValue, m.key)),
        backgroundColor: 'rgba(194, 65, 12, 0.16)',
        borderColor: '#C2410C',
        pointBackgroundColor: '#C2410C',
        borderWidth: 2,
      },
      {
        label: comparison.snackB.name,
        data: selected.map((m) => normalizeVal(m.snackBValue, m.key)),
        backgroundColor: 'rgba(20, 83, 45, 0.18)',
        borderColor: '#14532D',
        pointBackgroundColor: '#14532D',
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          boxWidth: 8,
          font: { family: 'DM Sans, sans-serif', size: 12 },
        },
      },
      tooltip: {
        callbacks: {
          label: (ctx: { dataset: { label?: string }; dataIndex: number; raw: unknown }) => {
            const metric = selected[ctx.dataIndex];
            const actualVal =
              ctx.dataset.label === comparison.snackA.name
                ? metric.snackAValue
                : metric.snackBValue;
            return `${ctx.dataset.label}: ${actualVal}${metric.unit} (${ctx.raw}% of ref index)`;
          },
        },
      },
    },
    scales: {
      r: {
        min: 0,
        max: 100,
        ticks: { stepSize: 25, display: false },
        pointLabels: { font: { family: 'DM Sans, sans-serif', size: 11 } },
        grid: { color: 'rgba(0,0,0,0.06)' },
      },
    },
  };

  return (
    <div className="h-[300px] w-full">
      <Radar data={data} options={options} />
    </div>
  );
}
