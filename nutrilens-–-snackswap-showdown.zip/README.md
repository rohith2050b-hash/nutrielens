# NutriLens – SnackSwap Showdown

**NutriLens – SnackSwap Showdown** is a full-stack nutrition literacy, snack comparison, and healthy swap tracking platform designed for Indian college students and young professionals. It translates confusing packaged and canteen food labels onto standardized baselines, grades nutritional quality transparently, recommends affordable Indian snack alternatives, and tracks measurable cumulative nutritional savings.

---

## 1. Problem Statement

College students regularly rely on quick, inexpensive snacks such as potato chips, samosas, cream biscuits, instant noodles, and carbonated beverages between lectures or during late-night study sessions. However:
- Serving sizes vary widely across packages (e.g., 28g vs 70g vs 330ml), making direct label comparison misleading.
- Students rarely see the cumulative impact of sodium, saturated fat, and added sugars.
- Generic Western diet apps ignore accessible ₹10–₹35 Indian hostel and canteen alternatives like roasted chana, dry-roasted makhana, sprouted moong, boiled sweet corn, and buttermilk.

## 2. Objectives

1. Standardize snack nutrition lookups across both **Per 100g / 100ml** and **Per Serving** baselines.
2. Implement a coherent, reproducible **FSA / Nutri-Score Adapted Health Grading Engine** (Grades A–E + Traffic-Light flags).
3. Recommend healthier alternatives via **Normalized Euclidean Distance** matching nutrition, texture, taste, and affordability.
4. Provide side-by-side comparison cards, interactive tables, Chart.js Bar & Radar visualizations, Sugar Cube visualization, and MET-based Exercise Equivalency context.
5. Persist real user snack swaps, daily/weekly/monthly savings, a 7-day campus challenge, and achievement badges in SQLite via Prisma ORM.

## 3. Core Features

- **11 Complete Pages**: Landing Page, Dashboard, Snack Explorer, Snack Details, Compare Snacks, Healthy Swap Recommendations, My Snack Swaps, Weekly Challenge, Barcode Scanner, Hostel Room Snack Hacks, and About / Methodology.
- **44-Snack Indian & International Database**: 22 common/unhealthy snacks and 22 healthier alternatives grounded in IFCT 2017 (ICMR-NIN), USDA FoodData Central, and product labels with explicit verification statuses.
- **Live Barcode Scanner**: Device camera integration (`html5-qrcode`) + manual EAN/UPC fallback + real Open Food Facts API v2 lookup with graceful error handling.
- **Sugar Cube Visualizer**: Interactive 4g/5g sugar-cube breakdown for beverages and sweet snacks.
- **Exercise Equivalency Calculator**: Transparent MET-based minutes for brisk walking, moderate jogging, and campus cycling with non-prescriptive disclaimer.
- **Hostel Room Snack Hacks**: 8 zero-stove / electric-kettle recipes under ₹30.

## 4. Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, React Router, Chart.js (`react-chartjs-2`), Lucide React, `html5-qrcode`.
- **Backend**: Node.js, Express.js, TypeScript, Zod validation, CORS, `express-rate-limit`.
- **Database**: SQLite with Prisma ORM (`prisma@6.6.0`).
- **Testing**: Vitest & Supertest.

## 5. System Architecture

```
React SPA (src/pages, src/components)
   │  REST API (/api/*) + x-guest-id persistence
   ▼
Express Server (server.ts -> server/app.ts)
   ├── Middleware: CORS, Rate Limiter, Zod Validation, Centralized Error Handler
   ├── Controllers: snackController, trackerController
   └── Services:
        ├── gradingService.ts (Nutri-Score / FSA 100g/ml Profiling)
        ├── recommendationService.ts (Normalized Euclidean Distance Matching)
        ├── comparisonService.ts (100g vs Serving Scaling & Delta Engine)
        ├── exerciseService.ts (Compendium MET Calculator)
        ├── barcodeService.ts (Local Catalog + Open Food Facts v2)
        └── swapService.ts / challengeService.ts / dashboardService.ts
   │
   ▼
Prisma ORM -> SQLite (prisma/dev.db)
```

## 6. Database Schema (`prisma/schema.prisma`)

- `User` — Guest-mode student profile & reference weight
- `Snack` — Catalog metadata, serving size/unit, INR price range, texture, taste, data source, verification status
- `NutritionalProfile` — Standardized per-100g/100ml nutrients + computed `healthGrade` (`A`–`E`) & `gradeScore`
- `SwapRule` — Domain-curated snack swap rationales & priority boosts
- `UserSwapLog` — Persisted swap records with calculated calorie, sugar, sodium, saturated fat, protein, and fiber deltas
- `WeeklyChallenge` & `ChallengeProgress` — 7-day challenge tracking with unique `(userId, challengeId, dayNumber)` constraint
- `Achievement` & `UserAchievement` — Criteria-verified achievement badges
- `HostelHack` — Affordable hostel recipes linked to base snacks

## 7. Health Grading & Recommendation Methodology

### Health Grading Engine (`server/services/gradingService.ts`)
Implements the **Santé Publique France Nutri-Score / UK FSA Nutrient Profiling Model** adapted for Indian snack datasets:
- **Negative Points (N, 0–40)**: Energy (kJ), Total Sugars (g), Saturated Fat (g), Sodium (mg) with distinct solid-food vs beverage thresholds.
- **Positive Points (P, 0–10)**: Dietary Fiber (g) and Protein (g). When `N >= 11`, protein credit is capped at 0 (standard FSA rule preventing high-fat/sodium snacks from masking risk nutrients).
- **Grades**: `A` (Healthier Choice), `B` (Good Choice), `C` (Moderate), `D` (Less Healthy), `E` (Least Healthy).

### Swap Recommendation Engine (`server/services/recommendationService.ts`)
Computes a min-max normalized weighted **Euclidean distance** across 6 nutritional dimensions (`calories`, `protein`, `fiber`, `sugar`, `sodium`, `saturatedFat`) toward an ideal healthier target vector, combined with texture/taste compatibility, beverage/solid modality enforcement, and affordability penalties.

## 8. Setup & Installation

### Environment Variables (`.env`)
```env
DATABASE_URL="file:./dev.db"
PORT="3000"
APP_URL="http://localhost:3000"
```

### Install, Migrate, Seed & Run
```bash
npm install
npx prisma migrate dev --name init
npx prisma db seed
npm run dev
```
The full-stack server runs on `http://localhost:3000` (serving both `/api/*` and the Vite React frontend).

### Production Build
```bash
npm run build
npm run start
```

## 9. REST API Documentation

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | API liveness check |
| `GET` | `/api/snacks` / `/api/snacks/search` | Search, filter (`category`, `grade`, `healthyOnly`), sort, paginate snacks |
| `GET` | `/api/snacks/:id` | Snack detail, grading breakdown, and MET exercise equivalency |
| `GET` | `/api/snacks/:id/recommendations` | Top healthier swaps via Normalized Euclidean Distance |
| `POST` | `/api/compare` | Side-by-side comparison (`snackAId`, `snackBId`, `basis`: `"serving"` \| `"100g"`) |
| `GET` | `/api/swaps` | Cumulative savings, swap logs, and daily/weekly/monthly history |
| `POST` | `/api/swaps` | Log a snack swap (with 10s duplicate-click protection) |
| `DELETE` | `/api/swaps/:id` | Undo / delete a logged swap |
| `GET` | `/api/dashboard` | Database-computed dashboard aggregates |
| `GET` | `/api/challenges` | Active 7-day challenge progress, streak, and badges |
| `POST` | `/api/challenges/:id/progress` | Mark challenge day complete & evaluate achievements |
| `GET` | `/api/barcode/:code` | Lookup barcode in local catalog or Open Food Facts v2 |
| `GET` | `/api/hostel-hacks` | List affordable hostel snack recipes with category filter |

## 10. Testing

Run the automated Vitest + Supertest suite:
```bash
npm test
```
Covers snack search, empty queries, health grading thresholds, invalid nutrient rejection, Euclidean swap recommendations, comparison math, exercise equivalency, swap persistence/duplicate rejection/undo, dashboard calculations, and Open Food Facts error handling.

## 11. Faculty Demonstration Workflow

1. Open NutriLens at `/` and click **Explore Snacks**.
2. Search for **Potato Chips** and inspect its nutrition facts, **Grade D/E** badge, and high sodium/saturated fat traffic-light flags.
3. View recommended swap **Roasted Salted Makhana** and click **Compare**.
4. Inspect the calculated calorie savings, saturated fat reduction, protein increase, Bar Chart, and Radar Chart.
5. Click **"I Swapped This!"** to persist the swap to SQLite.
6. Open **Dashboard** to confirm updated swap counts, calories/sodium saved, and Day 1 challenge progress.

## 12. Limitations & Future Enhancements

- Unpackaged street foods (e.g., Samosa, Kachori, Vada Pav) vary by vendor oil absorption and are explicitly labeled *Illustrative Estimate*.
- Future enhancements include university-canteen crowdsourced menu submissions, optional student authentication, and multi-item daily meal-plan balancing.
