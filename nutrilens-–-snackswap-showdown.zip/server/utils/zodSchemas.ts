import { z } from 'zod';

export const basisEnum = z.enum(['100g', 'serving']);

export const snackQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  category: z.string().trim().max(60).optional(),
  grade: z.enum(['A', 'B', 'C', 'D', 'E']).optional(),
  healthyOnly: z
    .enum(['true', 'false'])
    .transform((v) => v === 'true')
    .optional(),
  sortBy: z
    .enum(['name', 'calories', 'protein', 'sugar', 'sodium', 'gradeScore'])
    .optional()
    .default('name'),
  sortOrder: z.enum(['asc', 'desc']).optional().default('asc'),
  page: z.coerce.number().int().min(1).optional().default(1),
  limit: z.coerce.number().int().min(1).max(100).optional().default(12),
});

export const compareRequestSchema = z.object({
  snackAId: z.string().min(1, 'First snack ID is required'),
  snackBId: z.string().min(1, 'Second snack ID is required'),
  basis: basisEnum.optional().default('serving'),
});

export const createSwapSchema = z.object({
  originalSnackId: z.string().min(1, 'Original snack ID is required'),
  replacementSnackId: z.string().min(1, 'Replacement snack ID is required'),
  basis: basisEnum.optional().default('serving'),
  challengeDayNumber: z.coerce.number().int().min(1).max(7).optional(),
});

export const challengeProgressSchema = z.object({
  dayNumber: z.coerce.number().int().min(1).max(7),
  swapLogId: z.string().optional(),
  notes: z.string().trim().max(240).optional(),
});

export const barcodeParamSchema = z.object({
  code: z
    .string()
    .trim()
    .regex(/^\d{8,14}$/, 'Barcode must be 8 to 14 digits'),
});
