import { NextFunction, Request, Response } from 'express';
import { sendSuccess } from '../utils/apiResponse.ts';
import {
  getSnackByIdOrSlug,
  getSnackRecommendations,
  searchSnacks,
  SnackSearchParams,
} from '../services/snackService.ts';
import { prisma } from '../db.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { compareSnacks } from '../services/comparisonService.ts';
import { calculateExerciseEquivalency } from '../services/exerciseService.ts';

export async function listSnacksController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const query = (req as Request & { validatedQuery?: SnackSearchParams }).validatedQuery ?? {};
    const result = await searchSnacks(query);
    return sendSuccess(res, result);
  } catch (err) {
    next(err);
  }
}

export async function getSnackDetailController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const snack = await getSnackByIdOrSlug(String(req.params.id));
    const weightKg = Number(req.query.weightKg) || 65;
    const servingCalories = snack.nutrition
      ? Math.round((snack.nutrition.calories * snack.servingSizeGrams) / 100)
      : 0;
    const exercisePerServing = calculateExerciseEquivalency(servingCalories, weightKg);
    const exercisePer100g = calculateExerciseEquivalency(
      snack.nutrition?.calories ?? 0,
      weightKg
    );

    return sendSuccess(res, {
      ...snack,
      exerciseEquivalency: {
        perServing: exercisePerServing,
        per100g: exercisePer100g,
      },
    });
  } catch (err) {
    next(err);
  }
}

export async function getRecommendationsController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const limit = Math.min(6, Math.max(1, Number(req.query.limit) || 3));
    const result = await getSnackRecommendations(String(req.params.id), limit);
    return sendSuccess(res, result);
  } catch (err) {
    next(err);
  }
}

export async function compareSnacksController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const { snackAId, snackBId, basis } = req.body as {
      snackAId: string;
      snackBId: string;
      basis: '100g' | 'serving';
    };

    const [snackA, snackB] = await Promise.all([
      prisma.snack.findFirst({
        where: { OR: [{ id: snackAId }, { slug: snackAId }] },
        include: { nutrition: true },
      }),
      prisma.snack.findFirst({
        where: { OR: [{ id: snackBId }, { slug: snackBId }] },
        include: { nutrition: true },
      }),
    ]);

    if (!snackA) {
      throw new AppError(404, 'SNACK_NOT_FOUND', `First snack "${snackAId}" not found.`);
    }
    if (!snackB) {
      throw new AppError(404, 'SNACK_NOT_FOUND', `Second snack "${snackBId}" not found.`);
    }

    const result = compareSnacks(snackA, snackB, basis);
    return sendSuccess(res, result);
  } catch (err) {
    next(err);
  }
}
