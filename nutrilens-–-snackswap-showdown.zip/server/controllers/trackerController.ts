import { NextFunction, Request, Response } from 'express';
import { sendSuccess } from '../utils/apiResponse.ts';
import { resolveGuestUser } from '../services/userService.ts';
import {
  deleteUserSwap,
  getUserSwapsAndSummary,
  recordUserSwap,
} from '../services/swapService.ts';
import { getDashboardData } from '../services/dashboardService.ts';
import {
  getChallengeOverview,
  recordChallengeDayProgress,
} from '../services/challengeService.ts';
import { lookupBarcode } from '../services/barcodeService.ts';
import { prisma } from '../db.ts';

function getGuestKey(req: Request): string | undefined {
  const headerVal = req.headers['x-guest-id'];
  if (typeof headerVal === 'string') return headerVal;
  return undefined;
}

export async function createSwapController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const { originalSnackId, replacementSnackId, basis, challengeDayNumber } = req.body;
    const result = await recordUserSwap({
      userId: user.id,
      originalSnackId,
      replacementSnackId,
      basis,
      challengeDayNumber,
    });
    return sendSuccess(res, result, 201);
  } catch (err) {
    next(err);
  }
}

export async function listSwapsController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const data = await getUserSwapsAndSummary(user.id);
    return sendSuccess(res, data);
  } catch (err) {
    next(err);
  }
}

export async function deleteSwapController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const result = await deleteUserSwap(user.id, String(req.params.id));
    return sendSuccess(res, result);
  } catch (err) {
    next(err);
  }
}

export async function getDashboardController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const data = await getDashboardData(user.id);
    return sendSuccess(res, data);
  } catch (err) {
    next(err);
  }
}

export async function getChallengesController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const data = await getChallengeOverview(user.id);
    return sendSuccess(res, data);
  } catch (err) {
    next(err);
  }
}

export async function postChallengeProgressController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const user = await resolveGuestUser(getGuestKey(req));
    const data = await recordChallengeDayProgress(
      user.id,
      String(req.params.id),
      req.body
    );
    return sendSuccess(res, data, 201);
  } catch (err) {
    next(err);
  }
}

export async function getBarcodeController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const data = await lookupBarcode(String(req.params.code));
    return sendSuccess(res, data);
  } catch (err) {
    next(err);
  }
}

export async function getHostelHacksController(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const where = category && category !== 'All' ? { category } : {};
    const hacks = await prisma.hostelHack.findMany({
      where,
      orderBy: { prepTimeMinutes: 'asc' },
    });
    const categories = await prisma.hostelHack.findMany({
      select: { category: true },
      distinct: ['category'],
      orderBy: { category: 'asc' },
    });

    return sendSuccess(res, {
      items: hacks.map((h) => ({
        ...h,
        ingredients: JSON.parse(h.ingredients) as string[],
        instructions: JSON.parse(h.instructions) as string[],
      })),
      categories: categories.map((c) => c.category),
    });
  } catch (err) {
    next(err);
  }
}
