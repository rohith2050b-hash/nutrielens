import { Prisma } from '@prisma/client';
import { prisma } from '../db.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { evaluateNutritionGrade } from './gradingService.ts';
import { recommendHealthySwaps } from './recommendationService.ts';

export interface SnackSearchParams {
  q?: string;
  category?: string;
  grade?: 'A' | 'B' | 'C' | 'D' | 'E';
  healthyOnly?: boolean;
  sortBy?: 'name' | 'calories' | 'protein' | 'sugar' | 'sodium' | 'gradeScore';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export async function searchSnacks(params: SnackSearchParams) {
  const {
    q,
    category,
    grade,
    healthyOnly,
    sortBy = 'name',
    sortOrder = 'asc',
    page = 1,
    limit = 12,
  } = params;

  const where: Prisma.SnackWhereInput = {};

  if (q && q.trim().length > 0) {
    const term = q.trim();
    where.OR = [
      { name: { contains: term } },
      { category: { contains: term } },
      { description: { contains: term } },
    ];
  }

  if (category && category !== 'All') {
    where.category = category;
  }

  if (healthyOnly !== undefined) {
    where.isHealthyAlternative = healthyOnly;
  }

  if (grade) {
    where.nutrition = { healthGrade: grade };
  }

  const orderBy: Prisma.SnackOrderByWithRelationInput =
    sortBy === 'name'
      ? { name: sortOrder }
      : { nutrition: { [sortBy]: sortOrder } };

  const skip = (page - 1) * limit;

  const [total, items, categoriesRaw] = await Promise.all([
    prisma.snack.count({ where }),
    prisma.snack.findMany({
      where,
      include: { nutrition: true },
      orderBy,
      skip,
      take: limit,
    }),
    prisma.snack.findMany({
      select: { category: true },
      distinct: ['category'],
      orderBy: { category: 'asc' },
    }),
  ]);

  return {
    items,
    categories: categoriesRaw.map((c) => c.category),
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.max(1, Math.ceil(total / limit)),
    },
  };
}

export async function getSnackByIdOrSlug(idOrSlug: string) {
  const snack = await prisma.snack.findFirst({
    where: {
      OR: [{ id: idOrSlug }, { slug: idOrSlug }],
    },
    include: {
      nutrition: true,
    },
  });

  if (!snack) {
    throw new AppError(404, 'SNACK_NOT_FOUND', `Snack "${idOrSlug}" was not found.`);
  }

  const gradeAnalysis = snack.nutrition
    ? evaluateNutritionGrade({
        calories: snack.nutrition.calories,
        totalFat: snack.nutrition.totalFat,
        saturatedFat: snack.nutrition.saturatedFat,
        carbohydrates: snack.nutrition.carbohydrates,
        sugar: snack.nutrition.sugar,
        protein: snack.nutrition.protein,
        fiber: snack.nutrition.fiber,
        sodium: snack.nutrition.sodium,
        isBeverage: snack.nutrition.isBeverage,
      })
    : null;

  return {
    ...snack,
    gradeAnalysis,
  };
}

export async function getSnackRecommendations(idOrSlug: string, limit = 3) {
  const source = await prisma.snack.findFirst({
    where: { OR: [{ id: idOrSlug }, { slug: idOrSlug }] },
    include: {
      nutrition: true,
      swapRulesFrom: true,
    },
  });

  if (!source) {
    throw new AppError(404, 'SNACK_NOT_FOUND', `Snack "${idOrSlug}" was not found.`);
  }

  const allSnacks = await prisma.snack.findMany({
    include: { nutrition: true },
  });

  const recommendations = recommendHealthySwaps(
    source,
    allSnacks,
    source.swapRulesFrom.map((r) => ({
      toSnackId: r.toSnackId,
      rationale: r.rationale,
      priorityBoost: r.priorityBoost,
    })),
    limit
  );

  return {
    sourceSnack: source,
    recommendations,
  };
}
