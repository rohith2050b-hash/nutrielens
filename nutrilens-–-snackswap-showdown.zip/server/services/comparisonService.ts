import { AppError } from '../middleware/errorHandler.ts';

export type ComparisonBasis = '100g' | 'serving';

export interface SnackWithProfile {
  id: string;
  slug: string;
  name: string;
  category: string;
  description: string;
  servingSizeGrams: number;
  servingUnit: string;
  servingLabel: string;
  isHealthyAlternative: boolean;
  texture: string;
  tasteProfile: string;
  priceInrMin: number;
  priceInrMax: number;
  availability: string;
  imageUrl: string;
  barcode: string | null;
  dataSource: string;
  verificationStatus: string;
  nutrition: {
    calories: number;
    totalFat: number;
    saturatedFat: number;
    carbohydrates: number;
    sugar: number;
    protein: number;
    fiber: number;
    sodium: number;
    healthGrade: string;
    gradeScore: number;
    isBeverage: boolean;
  } | null;
}

export interface ScaledNutrition {
  calories: number;
  totalFat: number;
  saturatedFat: number;
  carbohydrates: number;
  sugar: number;
  protein: number;
  fiber: number;
  sodium: number;
}

export interface MetricDelta {
  key: keyof ScaledNutrition;
  label: string;
  unit: string;
  snackAValue: number;
  snackBValue: number;
  delta: number; // snackB - snackA
  percentChange: number | null;
  direction: 'lower_is_better' | 'higher_is_better' | 'neutral_macro';
  status: 'improvement' | 'attention' | 'neutral';
}

export interface ComparisonResult {
  basis: ComparisonBasis;
  basisLabelA: string;
  basisLabelB: string;
  snackA: SnackWithProfile & { scaledNutrition: ScaledNutrition };
  snackB: SnackWithProfile & { scaledNutrition: ScaledNutrition };
  metrics: MetricDelta[];
  savings: {
    caloriesSaved: number;
    sugarReduced: number;
    sodiumReduced: number;
    saturatedFatReduced: number;
    proteinGained: number;
    fiberGained: number;
  };
  headlineInsights: string[];
}

export function scaleNutrition(
  snack: SnackWithProfile,
  basis: ComparisonBasis
): ScaledNutrition {
  if (!snack.nutrition) {
    throw new AppError(422, 'MISSING_NUTRITION', `Nutritional profile missing for ${snack.name}`);
  }
  const factor = basis === 'serving' ? snack.servingSizeGrams / 100 : 1;
  const r = (v: number, digits = 1) => Number((v * factor).toFixed(digits));

  return {
    calories: Math.round(snack.nutrition.calories * factor),
    totalFat: r(snack.nutrition.totalFat),
    saturatedFat: r(snack.nutrition.saturatedFat),
    carbohydrates: r(snack.nutrition.carbohydrates),
    sugar: r(snack.nutrition.sugar),
    protein: r(snack.nutrition.protein),
    fiber: r(snack.nutrition.fiber),
    sodium: Math.round(snack.nutrition.sodium * factor),
  };
}

const METRIC_SPECS: Array<{
  key: keyof ScaledNutrition;
  label: string;
  unit: string;
  direction: 'lower_is_better' | 'higher_is_better' | 'neutral_macro';
  minMeaningfulDelta: number;
}> = [
  { key: 'calories', label: 'Calories', unit: 'kcal', direction: 'lower_is_better', minMeaningfulDelta: 10 },
  { key: 'totalFat', label: 'Total Fat', unit: 'g', direction: 'lower_is_better', minMeaningfulDelta: 0.5 },
  { key: 'saturatedFat', label: 'Saturated Fat', unit: 'g', direction: 'lower_is_better', minMeaningfulDelta: 0.3 },
  { key: 'carbohydrates', label: 'Carbohydrates', unit: 'g', direction: 'neutral_macro', minMeaningfulDelta: 1.0 },
  { key: 'sugar', label: 'Total Sugar', unit: 'g', direction: 'lower_is_better', minMeaningfulDelta: 0.5 },
  { key: 'protein', label: 'Protein', unit: 'g', direction: 'higher_is_better', minMeaningfulDelta: 0.5 },
  { key: 'fiber', label: 'Dietary Fiber', unit: 'g', direction: 'higher_is_better', minMeaningfulDelta: 0.4 },
  { key: 'sodium', label: 'Sodium', unit: 'mg', direction: 'lower_is_better', minMeaningfulDelta: 15 },
];

export function compareSnacks(
  snackA: SnackWithProfile,
  snackB: SnackWithProfile,
  basis: ComparisonBasis = 'serving'
): ComparisonResult {
  const scaledA = scaleNutrition(snackA, basis);
  const scaledB = scaleNutrition(snackB, basis);

  const metrics: MetricDelta[] = METRIC_SPECS.map((spec) => {
    const valA = scaledA[spec.key];
    const valB = scaledB[spec.key];
    const delta = Number((valB - valA).toFixed(1));
    const percentChange =
      valA > 0 ? Number((((valB - valA) / valA) * 100).toFixed(1)) : null;

    let status: 'improvement' | 'attention' | 'neutral' = 'neutral';
    const isMeaningful =
      Math.abs(delta) >= spec.minMeaningfulDelta &&
      (percentChange === null || Math.abs(percentChange) >= 5);

    if (isMeaningful && spec.direction !== 'neutral_macro') {
      if (spec.direction === 'lower_is_better') {
        status = delta < 0 ? 'improvement' : 'attention';
      } else if (spec.direction === 'higher_is_better') {
        status = delta > 0 ? 'improvement' : 'attention';
      }
    }

    return {
      key: spec.key,
      label: spec.label,
      unit: spec.unit,
      snackAValue: valA,
      snackBValue: valB,
      delta,
      percentChange,
      direction: spec.direction,
      status,
    };
  });

  const caloriesSaved = Math.round(scaledA.calories - scaledB.calories);
  const sugarReduced = Number((scaledA.sugar - scaledB.sugar).toFixed(1));
  const sodiumReduced = Math.round(scaledA.sodium - scaledB.sodium);
  const saturatedFatReduced = Number((scaledA.saturatedFat - scaledB.saturatedFat).toFixed(1));
  const proteinGained = Number((scaledB.protein - scaledA.protein).toFixed(1));
  const fiberGained = Number((scaledB.fiber - scaledA.fiber).toFixed(1));

  const headlineInsights: string[] = [];
  const basisWord = basis === 'serving' ? 'per selected serving' : `per 100${snackA.servingUnit}`;

  if (caloriesSaved > 0) {
    headlineInsights.push(`${caloriesSaved} calories saved ${basisWord}.`);
  } else if (caloriesSaved < -10) {
    headlineInsights.push(`${Math.abs(caloriesSaved)} more calories ${basisWord} (higher energy density).`);
  }

  const satMetric = metrics.find((m) => m.key === 'saturatedFat');
  if (satMetric && satMetric.percentChange !== null && satMetric.percentChange <= -10) {
    headlineInsights.push(`${Math.abs(Math.round(satMetric.percentChange))}% less saturated fat.`);
  }

  const sugMetric = metrics.find((m) => m.key === 'sugar');
  if (sugarReduced >= 1 && sugMetric && sugMetric.percentChange !== null) {
    headlineInsights.push(`${sugarReduced}g less sugar (${Math.abs(Math.round(sugMetric.percentChange))}% reduction).`);
  }

  const sodMetric = metrics.find((m) => m.key === 'sodium');
  if (sodiumReduced >= 20 && sodMetric && sodMetric.percentChange !== null) {
    headlineInsights.push(`${sodiumReduced}mg less sodium (${Math.abs(Math.round(sodMetric.percentChange))}% reduction).`);
  }

  if (proteinGained >= 0.5) {
    headlineInsights.push(`+${proteinGained}g protein.`);
  }

  if (fiberGained >= 0.5) {
    headlineInsights.push(`+${fiberGained}g dietary fiber.`);
  }

  if (headlineInsights.length === 0) {
    headlineInsights.push('Both snacks have closely matched nutritional profiles on this baseline.');
  }

  return {
    basis,
    basisLabelA: basis === 'serving' ? snackA.servingLabel : `Per 100${snackA.servingUnit}`,
    basisLabelB: basis === 'serving' ? snackB.servingLabel : `Per 100${snackB.servingUnit}`,
    snackA: { ...snackA, scaledNutrition: scaledA },
    snackB: { ...snackB, scaledNutrition: scaledB },
    metrics,
    savings: {
      caloriesSaved,
      sugarReduced,
      sodiumReduced,
      saturatedFatReduced,
      proteinGained,
      fiberGained,
    },
    headlineInsights,
  };
}
