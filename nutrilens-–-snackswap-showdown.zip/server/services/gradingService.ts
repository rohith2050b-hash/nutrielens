import { z } from 'zod';

export type HealthGrade = 'A' | 'B' | 'C' | 'D' | 'E';
export type TrafficLightLevel = 'Low' | 'Moderate' | 'High';

export interface NutrientInput {
  calories: number; // kcal per 100g/100ml
  totalFat: number; // g per 100g/100ml
  saturatedFat: number; // g per 100g/100ml
  carbohydrates: number; // g per 100g/100ml
  sugar: number; // g per 100g/100ml
  protein: number; // g per 100g/100ml
  fiber: number; // g per 100g/100ml
  sodium: number; // mg per 100g/100ml
  isBeverage?: boolean;
}

export interface TrafficLightMetric {
  nutrient: 'Total Fat' | 'Saturated Fat' | 'Sugar' | 'Sodium';
  value: number;
  unit: string;
  level: TrafficLightLevel;
  color: 'green' | 'amber' | 'red';
}

export interface GradeBreakdown {
  healthGrade: HealthGrade;
  gradeLabel: string;
  gradeScore: number;
  methodology: string;
  points: {
    energy: number;
    sugar: number;
    saturatedFat: number;
    sodium: number;
    negativeTotal: number;
    fiber: number;
    protein: number;
    proteinApplied: number;
    positiveTotal: number;
  };
  trafficLights: TrafficLightMetric[];
  strengths: string[];
  weaknesses: string[];
  explanation: string;
  disclaimer: string;
}

const nutrientInputSchema = z.object({
  calories: z.number().finite().min(0).max(950),
  totalFat: z.number().finite().min(0).max(100),
  saturatedFat: z.number().finite().min(0).max(100),
  carbohydrates: z.number().finite().min(0).max(100),
  sugar: z.number().finite().min(0).max(100),
  protein: z.number().finite().min(0).max(100),
  fiber: z.number().finite().min(0).max(100),
  sodium: z.number().finite().min(0).max(10000),
  isBeverage: z.boolean().optional().default(false),
});

function scoreByThresholds(value: number, thresholds: number[]): number {
  let pts = 0;
  for (const t of thresholds) {
    if (value > t) {
      pts += 1;
    } else {
      break;
    }
  }
  return pts;
}

const SOLID_ENERGY_KJ_THRESHOLDS = [335, 670, 1005, 1340, 1675, 2010, 2345, 2680, 3015, 3350];
const SOLID_SUGAR_THRESHOLDS = [4.5, 9, 13.5, 18, 22.5, 27, 31, 36, 40, 45];
const SOLID_SATFAT_THRESHOLDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const SOLID_SODIUM_THRESHOLDS = [90, 180, 270, 360, 450, 540, 630, 720, 810, 900];

const BEV_ENERGY_KJ_THRESHOLDS = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270];
const BEV_SUGAR_THRESHOLDS = [0, 1.5, 3, 4.5, 6, 7.5, 9, 10.5, 12, 13.5];

const FIBER_THRESHOLDS = [0.9, 1.9, 2.8, 3.7, 4.7];
const PROTEIN_THRESHOLDS = [1.6, 3.2, 4.8, 6.4, 8.0];

const GRADE_LABELS: Record<HealthGrade, string> = {
  A: 'Healthier Choice',
  B: 'Good Choice',
  C: 'Moderate',
  D: 'Less Healthy',
  E: 'Least Healthy',
};

export function evaluateNutritionGrade(rawInput: NutrientInput): GradeBreakdown {
  const input = nutrientInputSchema.parse(rawInput);
  const isBeverage = Boolean(input.isBeverage);
  const energyKj = input.calories * 4.184;

  const energyPts = isBeverage
    ? scoreByThresholds(energyKj, BEV_ENERGY_KJ_THRESHOLDS)
    : scoreByThresholds(energyKj, SOLID_ENERGY_KJ_THRESHOLDS);

  const sugarPts = isBeverage
    ? scoreByThresholds(input.sugar, BEV_SUGAR_THRESHOLDS)
    : scoreByThresholds(input.sugar, SOLID_SUGAR_THRESHOLDS);

  const satFatPts = scoreByThresholds(input.saturatedFat, SOLID_SATFAT_THRESHOLDS);
  const sodiumPts = scoreByThresholds(input.sodium, SOLID_SODIUM_THRESHOLDS);

  const negativeTotal = energyPts + sugarPts + satFatPts + sodiumPts;

  const fiberPts = scoreByThresholds(input.fiber, FIBER_THRESHOLDS);
  const proteinPts = scoreByThresholds(input.protein, PROTEIN_THRESHOLDS);

  // Standard Nutri-Score rule when fruit/vegetable % is < 80%:
  // if N >= 11, protein points are capped (not deducted) so high-fat/salt items cannot game the score.
  const proteinApplied = negativeTotal >= 11 ? 0 : proteinPts;
  const positiveTotal = fiberPts + proteinApplied;
  const gradeScore = negativeTotal - positiveTotal;

  let healthGrade: HealthGrade;
  if (isBeverage) {
    if (input.calories <= 5 && input.sugar <= 0.5 && input.sodium <= 45) {
      healthGrade = 'A';
    } else if (gradeScore <= 0) {
      healthGrade = 'A';
    } else if (gradeScore <= 2) {
      healthGrade = 'B';
    } else if (gradeScore <= 5) {
      healthGrade = 'C';
    } else if (gradeScore <= 9) {
      healthGrade = 'D';
    } else {
      healthGrade = 'E';
    }
  } else {
    if (gradeScore <= -1) {
      healthGrade = 'A';
    } else if (gradeScore <= 2) {
      healthGrade = 'B';
    } else if (gradeScore <= 10) {
      healthGrade = 'C';
    } else if (gradeScore <= 18) {
      healthGrade = 'D';
    } else {
      healthGrade = 'E';
    }
  }

  // Traffic Light Thresholds (UK FSA style per 100g / 100ml)
  const fatThresholds = isBeverage ? { low: 1.5, high: 8.75 } : { low: 3.0, high: 17.5 };
  const satThresholds = isBeverage ? { low: 0.75, high: 2.5 } : { low: 1.5, high: 5.0 };
  const sugThresholds = isBeverage ? { low: 2.5, high: 11.25 } : { low: 5.0, high: 22.5 };
  const sodThresholds = isBeverage ? { low: 120, high: 300 } : { low: 120, high: 600 };

  const classify = (val: number, t: { low: number; high: number }): { level: TrafficLightLevel; color: 'green' | 'amber' | 'red' } => {
    if (val <= t.low) return { level: 'Low', color: 'green' };
    if (val <= t.high) return { level: 'Moderate', color: 'amber' };
    return { level: 'High', color: 'red' };
  };

  const trafficLights: TrafficLightMetric[] = [
    {
      nutrient: 'Total Fat',
      value: Number(input.totalFat.toFixed(1)),
      unit: 'g',
      ...classify(input.totalFat, fatThresholds),
    },
    {
      nutrient: 'Saturated Fat',
      value: Number(input.saturatedFat.toFixed(1)),
      unit: 'g',
      ...classify(input.saturatedFat, satThresholds),
    },
    {
      nutrient: 'Sugar',
      value: Number(input.sugar.toFixed(1)),
      unit: 'g',
      ...classify(input.sugar, sugThresholds),
    },
    {
      nutrient: 'Sodium',
      value: Math.round(input.sodium),
      unit: 'mg',
      ...classify(input.sodium, sodThresholds),
    },
  ];

  // Strengths & Weaknesses
  const strengths: string[] = [];
  const weaknesses: string[] = [];

  if (input.fiber >= 3.5) {
    strengths.push(`Good dietary fiber (${input.fiber.toFixed(1)}g per 100${isBeverage ? 'ml' : 'g'})`);
  }
  if (input.protein >= 8.0) {
    strengths.push(`High protein density (${input.protein.toFixed(1)}g per 100${isBeverage ? 'ml' : 'g'})`);
  } else if (input.protein >= 4.5 && !isBeverage) {
    strengths.push(`Moderate protein contribution (${input.protein.toFixed(1)}g)`);
  }
  if (trafficLights[1].level === 'Low') {
    strengths.push('Low saturated fat');
  }
  if (trafficLights[2].level === 'Low' && input.sugar <= 3) {
    strengths.push('Low sugar content');
  }
  if (trafficLights[3].level === 'Low') {
    strengths.push('Low sodium');
  }
  if (!isBeverage && input.calories <= 150) {
    strengths.push('Low calorie density');
  }

  if (trafficLights[0].level === 'High') {
    weaknesses.push(`High total fat (${input.totalFat.toFixed(1)}g per 100${isBeverage ? 'ml' : 'g'})`);
  }
  if (trafficLights[1].level === 'High') {
    weaknesses.push(`High saturated fat (${input.saturatedFat.toFixed(1)}g per 100${isBeverage ? 'ml' : 'g'})`);
  }
  if (trafficLights[2].level === 'High') {
    weaknesses.push(`High sugar (${input.sugar.toFixed(1)}g per 100${isBeverage ? 'ml' : 'g'})`);
  }
  if (trafficLights[3].level === 'High') {
    weaknesses.push(`High sodium (${Math.round(input.sodium)}mg per 100${isBeverage ? 'ml' : 'g'})`);
  }
  if (!isBeverage && input.calories >= 450) {
    weaknesses.push(`Calorie-dense (${Math.round(input.calories)} kcal per 100g)`);
  }
  if (!isBeverage && input.fiber < 1.5 && input.protein < 4) {
    weaknesses.push('Low fiber and protein satiety');
  }

  if (strengths.length === 0) {
    strengths.push('Provides quick energy from carbohydrates or fats');
  }
  if (weaknesses.length === 0) {
    weaknesses.push('No major negative nutrient flags per 100g/ml baseline');
  }

  const explanation =
    `Assigned Grade ${healthGrade} (${GRADE_LABELS[healthGrade]}) with a Nutri-Score profile index of ${gradeScore} ` +
    `(${negativeTotal} negative points from energy, saturated fat, sugar, and sodium minus ${positiveTotal} positive points from fiber${proteinApplied > 0 ? ' and protein' : ''}).` +
    (negativeTotal >= 11 && proteinPts > 0
      ? ' Protein credit was capped because negative nutrient points reached 11 or higher.'
      : '');

  return {
    healthGrade,
    gradeLabel: GRADE_LABELS[healthGrade],
    gradeScore,
    methodology: 'FSA / Nutri-Score Adapted Profiling (100g/100ml baseline)',
    points: {
      energy: energyPts,
      sugar: sugarPts,
      saturatedFat: satFatPts,
      sodium: sodiumPts,
      negativeTotal,
      fiber: fiberPts,
      protein: proteinPts,
      proteinApplied,
      positiveTotal,
    },
    trafficLights,
    strengths,
    weaknesses,
    explanation,
    disclaimer:
      'Educational nutrition profiling based on standardized 100g/100ml values. Not medical advice or a personalized dietary diagnosis.',
  };
}
