import { prisma } from '../db.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { ComparisonBasis, compareSnacks } from './comparisonService.ts';
import { evaluateAndUnlockAchievements, syncSwapToChallenge } from './challengeService.ts';

export async function recordUserSwap(params: {
  userId: string;
  originalSnackId: string;
  replacementSnackId: string;
  basis: ComparisonBasis;
  challengeDayNumber?: number;
}) {
  const { userId, originalSnackId, replacementSnackId, basis, challengeDayNumber } = params;

  if (originalSnackId === replacementSnackId) {
    throw new AppError(
      400,
      'SAME_SNACK_SWAP',
      'Original snack and replacement snack must be different items.'
    );
  }

  const [originalSnack, replacementSnack] = await Promise.all([
    prisma.snack.findFirst({
      where: { OR: [{ id: originalSnackId }, { slug: originalSnackId }] },
      include: { nutrition: true },
    }),
    prisma.snack.findFirst({
      where: { OR: [{ id: replacementSnackId }, { slug: replacementSnackId }] },
      include: { nutrition: true },
    }),
  ]);

  if (!originalSnack) {
    throw new AppError(404, 'SNACK_NOT_FOUND', 'Original snack not found.');
  }
  if (!replacementSnack) {
    throw new AppError(404, 'SNACK_NOT_FOUND', 'Replacement snack not found.');
  }

  // Prevent accidental duplicate double-click submissions within 10 seconds
  const tenSecondsAgo = new Date(Date.now() - 10_000);
  const recentDuplicate = await prisma.userSwapLog.findFirst({
    where: {
      userId,
      originalSnackId: originalSnack.id,
      replacementSnackId: replacementSnack.id,
      swappedAt: { gte: tenSecondsAgo },
    },
  });

  if (recentDuplicate) {
    throw new AppError(
      409,
      'DUPLICATE_SWAP',
      'This exact snack swap was just logged. Please wait a few seconds before logging again.'
    );
  }

  const comparison = compareSnacks(originalSnack, replacementSnack, basis);

  const swapLog = await prisma.userSwapLog.create({
    data: {
      userId,
      originalSnackId: originalSnack.id,
      replacementSnackId: replacementSnack.id,
      basis,
      caloriesSaved: comparison.savings.caloriesSaved,
      sugarReduced: comparison.savings.sugarReduced,
      sodiumReduced: comparison.savings.sodiumReduced,
      saturatedFatReduced: comparison.savings.saturatedFatReduced,
      proteinGained: comparison.savings.proteinGained,
      fiberGained: comparison.savings.fiberGained,
    },
    include: {
      originalSnack: { include: { nutrition: true } },
      replacementSnack: { include: { nutrition: true } },
    },
  });

  // Auto-sync active 7-day challenge progress and achievement badges
  await syncSwapToChallenge(userId, swapLog.id, challengeDayNumber);
  const newlyUnlocked = await evaluateAndUnlockAchievements(userId);

  return {
    swapLog,
    newlyUnlockedAchievements: newlyUnlocked,
  };
}

export async function getUserSwapsAndSummary(userId: string) {
  const logs = await prisma.userSwapLog.findMany({
    where: { userId },
    include: {
      originalSnack: { include: { nutrition: true } },
      replacementSnack: { include: { nutrition: true } },
    },
    orderBy: { swappedAt: 'desc' },
  });

  const summary = logs.reduce(
    (acc, log) => {
      acc.totalSwaps += 1;
      acc.caloriesSaved += log.caloriesSaved;
      acc.sugarReduced += log.sugarReduced;
      acc.sodiumReduced += log.sodiumReduced;
      acc.saturatedFatReduced += log.saturatedFatReduced;
      acc.proteinGained += log.proteinGained;
      acc.fiberGained += log.fiberGained;
      return acc;
    },
    {
      totalSwaps: 0,
      caloriesSaved: 0,
      sugarReduced: 0,
      sodiumReduced: 0,
      saturatedFatReduced: 0,
      proteinGained: 0,
      fiberGained: 0,
    }
  );

  summary.caloriesSaved = Math.round(summary.caloriesSaved);
  summary.sugarReduced = Number(summary.sugarReduced.toFixed(1));
  summary.sodiumReduced = Math.round(summary.sodiumReduced);
  summary.saturatedFatReduced = Number(summary.saturatedFatReduced.toFixed(1));
  summary.proteinGained = Number(summary.proteinGained.toFixed(1));
  summary.fiberGained = Number(summary.fiberGained.toFixed(1));

  // Build daily, weekly, monthly breakdowns from actual timestamps
  const dailyMap = new Map<string, { label: string; swaps: number; caloriesSaved: number; sugarReduced: number }>();
  const weeklyMap = new Map<string, { label: string; swaps: number; caloriesSaved: number; sugarReduced: number }>();
  const monthlyMap = new Map<string, { label: string; swaps: number; caloriesSaved: number; sugarReduced: number }>();

  for (const log of logs) {
    const d = new Date(log.swappedAt);
    const dayKey = d.toISOString().slice(0, 10);
    const dayEntry = dailyMap.get(dayKey) ?? { label: dayKey, swaps: 0, caloriesSaved: 0, sugarReduced: 0 };
    dayEntry.swaps += 1;
    dayEntry.caloriesSaved += Math.round(log.caloriesSaved);
    dayEntry.sugarReduced = Number((dayEntry.sugarReduced + log.sugarReduced).toFixed(1));
    dailyMap.set(dayKey, dayEntry);

    // Week bucket (ISO week start Monday)
    const weekDate = new Date(d);
    const dayOfWeek = weekDate.getUTCDay();
    const diffToMon = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
    weekDate.setUTCDate(weekDate.getUTCDate() + diffToMon);
    const weekKey = `Week of ${weekDate.toISOString().slice(0, 10)}`;
    const weekEntry = weeklyMap.get(weekKey) ?? { label: weekKey, swaps: 0, caloriesSaved: 0, sugarReduced: 0 };
    weekEntry.swaps += 1;
    weekEntry.caloriesSaved += Math.round(log.caloriesSaved);
    weekEntry.sugarReduced = Number((weekEntry.sugarReduced + log.sugarReduced).toFixed(1));
    weeklyMap.set(weekKey, weekEntry);

    const monthKey = d.toISOString().slice(0, 7);
    const monthEntry = monthlyMap.get(monthKey) ?? { label: monthKey, swaps: 0, caloriesSaved: 0, sugarReduced: 0 };
    monthEntry.swaps += 1;
    monthEntry.caloriesSaved += Math.round(log.caloriesSaved);
    monthEntry.sugarReduced = Number((monthEntry.sugarReduced + log.sugarReduced).toFixed(1));
    monthlyMap.set(monthKey, monthEntry);
  }

  return {
    summary,
    logs,
    history: {
      daily: Array.from(dailyMap.values()).slice(0, 14).reverse(),
      weekly: Array.from(weeklyMap.values()).slice(0, 8).reverse(),
      monthly: Array.from(monthlyMap.values()).slice(0, 6).reverse(),
    },
  };
}

export async function deleteUserSwap(userId: string, swapId: string) {
  const existing = await prisma.userSwapLog.findFirst({
    where: { id: swapId, userId },
  });

  if (!existing) {
    throw new AppError(404, 'SWAP_NOT_FOUND', 'Swap record not found.');
  }

  await prisma.$transaction([
    prisma.challengeProgress.deleteMany({
      where: { userId, swapLogId: swapId },
    }),
    prisma.userSwapLog.delete({
      where: { id: swapId },
    }),
  ]);

  return { deletedId: swapId };
}
