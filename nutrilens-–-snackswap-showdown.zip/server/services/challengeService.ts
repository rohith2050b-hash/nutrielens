import { prisma } from '../db.ts';
import { AppError } from '../middleware/errorHandler.ts';

export async function getActiveChallenge() {
  let challenge = await prisma.weeklyChallenge.findFirst({
    where: { isActive: true },
    orderBy: { createdAt: 'desc' },
  });

  if (!challenge) {
    challenge = await prisma.weeklyChallenge.create({
      data: {
        title: '7-Day Campus Smart Swap Challenge',
        description: 'Replace at least one deep-fried, sugary, or ultra-processed snack with a healthier alternative every day for 7 days.',
        targetDays: 7,
        isActive: true,
      },
    });
  }

  return challenge;
}

export function computeStreak(completedDays: number[]): number {
  if (completedDays.length === 0) return 0;
  const sorted = [...new Set(completedDays)].sort((a, b) => a - b);
  let maxStreak = 1;
  let currentStreak = 1;
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i] === sorted[i - 1] + 1) {
      currentStreak += 1;
      if (currentStreak > maxStreak) maxStreak = currentStreak;
    } else {
      currentStreak = 1;
    }
  }
  return maxStreak;
}

export async function evaluateAndUnlockAchievements(userId: string) {
  const [swaps, challenge, achievements, existingUnlocks] = await Promise.all([
    prisma.userSwapLog.findMany({ where: { userId } }),
    getActiveChallenge(),
    prisma.achievement.findMany(),
    prisma.userAchievement.findMany({ where: { userId } }),
  ]);

  const progress = await prisma.challengeProgress.findMany({
    where: { userId, challengeId: challenge.id },
  });

  const unlockedSet = new Set(existingUnlocks.map((u) => u.achievementId));
  const totalSwaps = swaps.length;
  const totalCaloriesSaved = swaps.reduce((sum, s) => sum + s.caloriesSaved, 0);
  const totalSugarReduced = swaps.reduce((sum, s) => sum + s.sugarReduced, 0);
  const completedDays = progress.map((p) => p.dayNumber);
  const streak = computeStreak(completedDays);

  const newlyUnlocked: Array<{ code: string; title: string; description: string }> = [];

  for (const ach of achievements) {
    if (unlockedSet.has(ach.id)) continue;

    let satisfied = false;
    if (ach.code === 'FIRST_SWAP' && totalSwaps >= 1) satisfied = true;
    if (ach.code === 'STREAK_3' && streak >= 3) satisfied = true;
    if (ach.code === 'CHAMPION_7' && completedDays.length >= 7) satisfied = true;
    if (ach.code === 'SMART_SWAPPER' && totalSwaps >= 5 && totalCaloriesSaved >= 300) satisfied = true;
    if (ach.code === 'SUGAR_SAVER' && totalSugarReduced >= 30) satisfied = true;

    if (satisfied) {
      await prisma.userAchievement.create({
        data: {
          userId,
          achievementId: ach.id,
        },
      });
      newlyUnlocked.push({
        code: ach.code,
        title: ach.title,
        description: ach.description,
      });
    }
  }

  return newlyUnlocked;
}

export async function syncSwapToChallenge(
  userId: string,
  swapLogId: string,
  explicitDayNumber?: number
) {
  const challenge = await getActiveChallenge();
  const existing = await prisma.challengeProgress.findMany({
    where: { userId, challengeId: challenge.id },
    orderBy: { dayNumber: 'asc' },
  });

  const completedSet = new Set(existing.map((e) => e.dayNumber));
  let targetDay = explicitDayNumber;

  if (!targetDay) {
    for (let d = 1; d <= 7; d++) {
      if (!completedSet.has(d)) {
        targetDay = d;
        break;
      }
    }
  }

  if (!targetDay || targetDay < 1 || targetDay > 7 || completedSet.has(targetDay)) {
    return null;
  }

  const todayStr = new Date().toISOString().slice(0, 10);
  return prisma.challengeProgress.create({
    data: {
      userId,
      challengeId: challenge.id,
      dayNumber: targetDay,
      completedDate: todayStr,
      swapLogId,
      notes: 'Completed automatically via snack swap tracker.',
    },
  });
}

export async function recordChallengeDayProgress(
  userId: string,
  challengeId: string,
  input: { dayNumber: number; swapLogId?: string; notes?: string }
) {
  const challenge = await prisma.weeklyChallenge.findUnique({
    where: { id: challengeId },
  });

  if (!challenge) {
    throw new AppError(404, 'CHALLENGE_NOT_FOUND', 'Weekly challenge not found.');
  }

  const todayStr = new Date().toISOString().slice(0, 10);
  const progress = await prisma.challengeProgress.upsert({
    where: {
      userId_challengeId_dayNumber: {
        userId,
        challengeId,
        dayNumber: input.dayNumber,
      },
    },
    update: {
      completedDate: todayStr,
      swapLogId: input.swapLogId ?? null,
      notes: input.notes ?? 'Marked complete.',
    },
    create: {
      userId,
      challengeId,
      dayNumber: input.dayNumber,
      completedDate: todayStr,
      swapLogId: input.swapLogId ?? null,
      notes: input.notes ?? 'Marked complete.',
    },
  });

  const newlyUnlocked = await evaluateAndUnlockAchievements(userId);
  return { progress, newlyUnlocked };
}

export async function getChallengeOverview(userId: string) {
  const [challenge, allAchievements, userAchievements] = await Promise.all([
    getActiveChallenge(),
    prisma.achievement.findMany({ orderBy: { code: 'asc' } }),
    prisma.userAchievement.findMany({
      where: { userId },
      include: { achievement: true },
    }),
  ]);

  const progress = await prisma.challengeProgress.findMany({
    where: { userId, challengeId: challenge.id },
    orderBy: { dayNumber: 'asc' },
  });

  const completedDays = progress.map((p) => p.dayNumber);
  const currentStreak = computeStreak(completedDays);
  const unlockedMap = new Map(userAchievements.map((ua) => [ua.achievementId, ua.unlockedAt]));

  const days = Array.from({ length: 7 }, (_, idx) => {
    const dayNumber = idx + 1;
    const entry = progress.find((p) => p.dayNumber === dayNumber);
    return {
      dayNumber,
      completed: Boolean(entry),
      completedDate: entry?.completedDate ?? null,
      notes: entry?.notes ?? null,
      swapLogId: entry?.swapLogId ?? null,
    };
  });

  return {
    challenge,
    days,
    completedCount: completedDays.length,
    targetDays: challenge.targetDays,
    completionPercent: Math.round((completedDays.length / challenge.targetDays) * 100),
    streak: currentStreak,
    achievements: allAchievements.map((a) => ({
      ...a,
      unlocked: unlockedMap.has(a.id),
      unlockedAt: unlockedMap.get(a.id) ?? null,
    })),
  };
}
