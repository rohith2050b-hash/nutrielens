import { prisma } from '../db.ts';

export const DEFAULT_GUEST_KEY = 'campus-guest-default';

export async function resolveGuestUser(guestKey?: string | null) {
  const normalizedKey =
    guestKey && guestKey.trim().length >= 4 && guestKey.trim().length <= 64
      ? guestKey.trim()
      : DEFAULT_GUEST_KEY;

  let user = await prisma.user.findUnique({
    where: { guestKey: normalizedKey },
  });

  if (!user) {
    user = await prisma.user.create({
      data: {
        guestKey: normalizedKey,
        displayName: normalizedKey === DEFAULT_GUEST_KEY ? 'Campus Guest' : 'Student Guest',
      },
    });
  }

  return user;
}
