import { prisma } from '../db.ts';
import { getChallengeOverview } from './challengeService.ts';
import { getUserSwapsAndSummary } from './swapService.ts';

export async function getDashboardData(userId: string) {
  const [totalSnacks, healthySnacksCount, swapData, challengeData, featuredHealthy] =
    await Promise.all([
      prisma.snack.count(),
      prisma.snack.count({ where: { isHealthyAlternative: true } }),
      getUserSwapsAndSummary(userId),
      getChallengeOverview(userId),
      prisma.snack.findMany({
        where: { isHealthyAlternative: true },
        include: { nutrition: true },
        orderBy: { nutrition: { gradeScore: 'asc' } },
        take: 4,
      }),
    ]);

  return {
    catalogStats: {
      totalSnacks,
      healthyAlternatives: healthySnacksCount,
      commonSnacks: totalSnacks - healthySnacksCount,
    },
    swapSummary: swapData.summary,
    recentSwaps: swapData.logs.slice(0, 5),
    weeklyProgress: swapData.history.daily.slice(-7),
    challengeSummary: {
      id: challengeData.challenge.id,
      title: challengeData.challenge.title,
      completedCount: challengeData.completedCount,
      targetDays: challengeData.targetDays,
      completionPercent: challengeData.completionPercent,
      streak: challengeData.streak,
      days: challengeData.days,
      unlockedBadgesCount: challengeData.achievements.filter((a) => a.unlocked).length,
      totalBadgesCount: challengeData.achievements.length,
    },
    recommendedAlternatives: featuredHealthy,
  };
}
