import { prisma } from '../db.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { evaluateNutritionGrade } from './gradingService.ts';
import { recommendHealthySwaps } from './recommendationService.ts';

interface OpenFoodFactsNutriments {
  'energy-kcal_100g'?: number;
  'energy-kcal_value'?: number;
  fat_100g?: number;
  'saturated-fat_100g'?: number;
  carbohydrates_100g?: number;
  sugars_100g?: number;
  proteins_100g?: number;
  fiber_100g?: number;
  sodium_100g?: number; // in g on OFF
  salt_100g?: number;
}

interface OpenFoodFactsResponse {
  status: number;
  status_verbose?: string;
  product?: {
    product_name?: string;
    brands?: string;
    categories_tags?: string[];
    serving_size?: string;
    image_front_url?: string;
    nutriments?: OpenFoodFactsNutriments;
  };
}

function parseServingGrams(servingSize?: string): number {
  if (!servingSize) return 30;
  const match = servingSize.match(/(\d+(?:\.\d+)?)\s*(g|ml)/i);
  if (match) {
    const val = Number(match[1]);
    if (Number.isFinite(val) && val > 0 && val <= 1000) return val;
  }
  return 30;
}

export async function lookupBarcode(code: string) {
  // 1. Check local database first
  const localSnack = await prisma.snack.findUnique({
    where: { barcode: code },
    include: { nutrition: true, swapRulesFrom: true },
  });

  if (localSnack && localSnack.nutrition) {
    const allSnacks = await prisma.snack.findMany({ include: { nutrition: true } });
    const gradeAnalysis = evaluateNutritionGrade({
      calories: localSnack.nutrition.calories,
      totalFat: localSnack.nutrition.totalFat,
      saturatedFat: localSnack.nutrition.saturatedFat,
      carbohydrates: localSnack.nutrition.carbohydrates,
      sugar: localSnack.nutrition.sugar,
      protein: localSnack.nutrition.protein,
      fiber: localSnack.nutrition.fiber,
      sodium: localSnack.nutrition.sodium,
      isBeverage: localSnack.nutrition.isBeverage,
    });
    const recommendations = recommendHealthySwaps(
      localSnack,
      allSnacks,
      localSnack.swapRulesFrom.map((r) => ({
        toSnackId: r.toSnackId,
        rationale: r.rationale,
        priorityBoost: r.priorityBoost,
      })),
      3
    );

    return {
      source: 'local_catalog' as const,
      barcode: code,
      product: {
        id: localSnack.id,
        name: localSnack.name,
        brand: 'NutriLens Verified Catalog',
        category: localSnack.category,
        servingLabel: localSnack.servingLabel,
        servingSizeGrams: localSnack.servingSizeGrams,
        servingUnit: localSnack.servingUnit,
        imageUrl: localSnack.imageUrl,
        nutritionPer100g: localSnack.nutrition,
        missingFields: [] as string[],
      },
      gradeAnalysis,
      recommendations,
    };
  }

  // 2. Query Open Food Facts API v2
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  let payload: OpenFoodFactsResponse;
  try {
    const response = await fetch(
      `https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json`,
      {
        signal: controller.signal,
        headers: {
          'User-Agent': 'NutriLens-StudentProject/1.0 (academic-demo)',
        },
      }
    );

    if (!response.ok) {
      throw new AppError(
        502,
        'OFF_API_ERROR',
        `Open Food Facts returned status ${response.status}. Try manual snack search instead.`
      );
    }

    payload = (await response.json()) as OpenFoodFactsResponse;
  } catch (err) {
    if (err instanceof AppError) throw err;
    const isAbort = err instanceof Error && err.name === 'AbortError';
    throw new AppError(
      503,
      'OFF_NETWORK_ERROR',
      isAbort
        ? 'Open Food Facts request timed out. Please check connectivity or use manual search.'
        : 'Unable to reach Open Food Facts API right now. Please use manual search as fallback.'
    );
  } finally {
    clearTimeout(timeout);
  }

  if (payload.status !== 1 || !payload.product) {
    throw new AppError(
      404,
      'BARCODE_NOT_FOUND',
      `No product found in Open Food Facts for barcode ${code}. Try searching the snack manually.`
    );
  }

  const p = payload.product;
  const n = p.nutriments ?? {};
  const missingFields: string[] = [];

  const calories = n['energy-kcal_100g'] ?? n['energy-kcal_value'];
  if (calories === undefined || !Number.isFinite(calories)) missingFields.push('calories');

  const totalFat = n.fat_100g;
  if (totalFat === undefined || !Number.isFinite(totalFat)) missingFields.push('totalFat');

  const saturatedFat = n['saturated-fat_100g'];
  if (saturatedFat === undefined || !Number.isFinite(saturatedFat)) missingFields.push('saturatedFat');

  const carbohydrates = n.carbohydrates_100g;
  if (carbohydrates === undefined || !Number.isFinite(carbohydrates)) missingFields.push('carbohydrates');

  const sugar = n.sugars_100g;
  if (sugar === undefined || !Number.isFinite(sugar)) missingFields.push('sugar');

  const protein = n.proteins_100g;
  if (protein === undefined || !Number.isFinite(protein)) missingFields.push('protein');

  const fiber = n.fiber_100g ?? 0;
  if (n.fiber_100g === undefined) missingFields.push('fiber (defaulted to 0g)');

  // Open Food Facts reports sodium_100g in grams; convert to mg
  let sodiumMg: number | undefined;
  if (n.sodium_100g !== undefined && Number.isFinite(n.sodium_100g)) {
    sodiumMg = n.sodium_100g * 1000;
  } else if (n.salt_100g !== undefined && Number.isFinite(n.salt_100g)) {
    sodiumMg = (n.salt_100g / 2.5) * 1000;
  } else {
    missingFields.push('sodium');
  }

  const isBeverage = (p.categories_tags ?? []).some((tag) =>
    tag.includes('beverage') || tag.includes('drink') || tag.includes('soda')
  );

  const normalizedNutrition = {
    calories: Math.max(0, Number((calories ?? 0).toFixed(1))),
    totalFat: Math.max(0, Number((totalFat ?? 0).toFixed(1))),
    saturatedFat: Math.max(0, Number((saturatedFat ?? 0).toFixed(1))),
    carbohydrates: Math.max(0, Number((carbohydrates ?? 0).toFixed(1))),
    sugar: Math.max(0, Number((sugar ?? 0).toFixed(1))),
    protein: Math.max(0, Number((protein ?? 0).toFixed(1))),
    fiber: Math.max(0, Number((fiber ?? 0).toFixed(1))),
    sodium: Math.max(0, Math.round(sodiumMg ?? 0)),
    isBeverage,
  };

  const hasCoreNutrition =
    calories !== undefined && (totalFat !== undefined || carbohydrates !== undefined || sugar !== undefined);

  if (!hasCoreNutrition) {
    throw new AppError(
      422,
      'INCOMPLETE_NUTRITION',
      `Product "${p.product_name || code}" exists on Open Food Facts, but its nutrition facts table is incomplete. Use manual search to compare similar snacks.`,
      { productName: p.product_name, missingFields }
    );
  }

  const gradeAnalysis = evaluateNutritionGrade(normalizedNutrition);

  // Recommend healthier alternatives from NutriLens catalog using distance matching
  const allSnacks = await prisma.snack.findMany({ include: { nutrition: true } });
  const virtualSource = {
    id: `off-${code}`,
    slug: `off-${code}`,
    name: p.product_name || `Scanned Product (${code})`,
    category: isBeverage ? 'Beverages' : 'Chips & Crisps',
    description: p.brands ? `Scanned brand: ${p.brands}` : 'Open Food Facts product',
    servingSizeGrams: parseServingGrams(p.serving_size),
    servingUnit: isBeverage ? 'ml' : 'g',
    servingLabel: p.serving_size || '1 serving (30g)',
    isHealthyAlternative: false,
    texture: isBeverage ? 'liquid' : 'crunchy',
    tasteProfile: normalizedNutrition.sugar > 12 ? 'sweet' : 'salty',
    priceInrMin: 20,
    priceInrMax: 50,
    availability: 'Supermarket',
    imageUrl: p.image_front_url || '',
    barcode: code,
    dataSource: 'Open Food Facts API',
    verificationStatus: 'Community Database',
    nutrition: {
      ...normalizedNutrition,
      healthGrade: gradeAnalysis.healthGrade,
      gradeScore: gradeAnalysis.gradeScore,
    },
  };

  const recommendations = recommendHealthySwaps(virtualSource, allSnacks, [], 3);

  return {
    source: 'open_food_facts' as const,
    barcode: code,
    product: {
      id: null,
      name: virtualSource.name,
      brand: p.brands || 'Unspecified Brand',
      category: virtualSource.category,
      servingLabel: virtualSource.servingLabel,
      servingSizeGrams: virtualSource.servingSizeGrams,
      servingUnit: virtualSource.servingUnit,
      imageUrl: virtualSource.imageUrl,
      nutritionPer100g: {
        ...normalizedNutrition,
        healthGrade: gradeAnalysis.healthGrade,
        gradeScore: gradeAnalysis.gradeScore,
      },
      missingFields,
    },
    gradeAnalysis,
    recommendations,
  };
}
