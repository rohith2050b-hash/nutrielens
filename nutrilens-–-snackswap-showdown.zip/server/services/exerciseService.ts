export interface ExerciseActivity {
  key: 'walking' | 'jogging' | 'cycling';
  label: string;
  description: string;
  met: number;
  minutes: number;
  kcalPerMinute: number;
}

export interface ExerciseEquivalencyResult {
  calories: number;
  bodyWeightKg: number;
  activities: ExerciseActivity[];
  formula: string;
  disclaimer: string;
}

const ACTIVITIES: Array<{
  key: 'walking' | 'jogging' | 'cycling';
  label: string;
  description: string;
  met: number;
}> = [
  {
    key: 'walking',
    label: 'Brisk Walking',
    description: '~4.8 km/h campus walk',
    met: 3.5,
  },
  {
    key: 'jogging',
    label: 'Moderate Jogging',
    description: '~7.5 km/h steady pace',
    met: 7.0,
  },
  {
    key: 'cycling',
    label: 'Campus Cycling',
    description: '~16 km/h moderate commute',
    met: 6.0,
  },
];

export function calculateExerciseEquivalency(
  calories: number,
  bodyWeightKg = 65
): ExerciseEquivalencyResult {
  const safeCalories = Number.isFinite(calories) && calories > 0 ? calories : 0;
  const safeWeight =
    Number.isFinite(bodyWeightKg) && bodyWeightKg >= 30 && bodyWeightKg <= 200
      ? bodyWeightKg
      : 65;

  const activities: ExerciseActivity[] = ACTIVITIES.map((act) => {
    // Standard ACSM MET energy expenditure equation: kcal/min = (MET * 3.5 * weightKg) / 200
    const kcalPerMinute = (act.met * 3.5 * safeWeight) / 200;
    const minutes = safeCalories === 0 ? 0 : Math.round(safeCalories / kcalPerMinute);
    return {
      key: act.key,
      label: act.label,
      description: act.description,
      met: act.met,
      minutes,
      kcalPerMinute: Number(kcalPerMinute.toFixed(2)),
    };
  });

  return {
    calories: Math.round(safeCalories),
    bodyWeightKg: safeWeight,
    activities,
    formula: 'kcal/min = (MET × 3.5 × bodyWeightKg) ÷ 200 (Compendium of Physical Activities)',
    disclaimer:
      'Approximate energy comparisons for educational context only — not exercise prescriptions or instructions to burn off food.',
  };
}
