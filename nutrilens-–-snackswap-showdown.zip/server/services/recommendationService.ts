import { SnackWithProfile } from './comparisonService.ts';

export interface SwapRuleHint {
  toSnackId: string;
  rationale: string;
  priorityBoost: number;
}

export interface RecommendationItem {
  snack: SnackWithProfile;
  matchScore: number; // 0 to 100
  euclideanDistance: number;
  priceRange: string;
  advantages: string[];
  whySuitable: string;
  matchedDimensions: {
    textureMatch: boolean;
    tasteMatch: boolean;
    beverageMatch: boolean;
    curatedRule: boolean;
  };
}

interface FeatureRange {
  min: number;
  max: number;
}

const DIMENSIONS = ['calories', 'protein', 'fiber', 'sugar', 'sodium', 'saturatedFat'] as const;

// Feature weights emphasize calorie/satFat/sugar/sodium reduction + protein/fiber boost
const DIMENSION_WEIGHTS: Record<(typeof DIMENSIONS)[number], number> = {
  calories: 1.4,
  protein: 1.2,
  fiber: 1.1,
  sugar: 1.3,
  sodium: 1.2,
  saturatedFat: 1.3,
};

function computeRanges(snacks: SnackWithProfile[]): Record<(typeof DIMENSIONS)[number], FeatureRange> {
  const ranges = {} as Record<(typeof DIMENSIONS)[number], FeatureRange>;
  for (const dim of DIMENSIONS) {
    const vals = snacks
      .filter((s) => s.nutrition !== null)
      .map((s) => s.nutrition![dim]);
    const min = vals.length > 0 ? Math.min(...vals) : 0;
    const max = vals.length > 0 ? Math.max(...vals) : 1;
    ranges[dim] = { min, max: max === min ? min + 1 : max };
  }
  return ranges;
}

function normalize(val: number, range: FeatureRange): number {
  return (val - range.min) / (range.max - range.min);
}

/**
 * Computes an ideal healthier target vector anchored to the source snack:
 * lowers calories, saturated fat, sugar, and sodium while elevating protein & fiber.
 */
function buildIdealTargetVector(
  source: NonNullable<SnackWithProfile['nutrition']>,
  ranges: Record<(typeof DIMENSIONS)[number], FeatureRange>
): Record<(typeof DIMENSIONS)[number], number> {
  const targetRaw = {
    calories: source.calories * 0.55,
    saturatedFat: source.saturatedFat * 0.25,
    sugar: source.sugar * 0.25,
    sodium: source.sodium * 0.45,
    protein: Math.max(source.protein * 1.35, source.isBeverage ? 1.0 : 8.0),
    fiber: Math.max(source.fiber * 1.5, source.isBeverage ? 0.5 : 4.5),
  };

  return {
    calories: Math.max(0, Math.min(1, normalize(targetRaw.calories, ranges.calories))),
    saturatedFat: Math.max(0, Math.min(1, normalize(targetRaw.saturatedFat, ranges.saturatedFat))),
    sugar: Math.max(0, Math.min(1, normalize(targetRaw.sugar, ranges.sugar))),
    sodium: Math.max(0, Math.min(1, normalize(targetRaw.sodium, ranges.sodium))),
    protein: Math.max(0, Math.min(1, normalize(targetRaw.protein, ranges.protein))),
    fiber: Math.max(0, Math.min(1, normalize(targetRaw.fiber, ranges.fiber))),
  };
}

export function recommendHealthySwaps(
  sourceSnack: SnackWithProfile,
  allSnacks: SnackWithProfile[],
  swapRules: SwapRuleHint[] = [],
  limit = 3
): RecommendationItem[] {
  if (!sourceSnack.nutrition) return [];

  const sourceNut = sourceSnack.nutrition;
  const ranges = computeRanges(allSnacks);
  const idealTarget = buildIdealTargetVector(sourceNut, ranges);
  const ruleMap = new Map(swapRules.map((r) => [r.toSnackId, r]));

  // Candidates must be distinct snacks, same liquid/solid modality, and healthier grade or marked healthy alternative
  const candidates = allSnacks.filter((cand) => {
    if (cand.id === sourceSnack.id || !cand.nutrition) return false;
    if (cand.nutrition.isBeverage !== sourceNut.isBeverage) return false;
    if (cand.isHealthyAlternative) return true;
    return cand.nutrition.gradeScore < sourceNut.gradeScore;
  });

  const scored = candidates.map((cand) => {
    const candNut = cand.nutrition!;

    // 1. Normalized Weighted Euclidean Distance to Ideal Healthier Profile
    let weightedSqSum = 0;
    let totalWeight = 0;
    for (const dim of DIMENSIONS) {
      const candNorm = normalize(candNut[dim], ranges[dim]);
      const diff = idealTarget[dim] - candNorm;
      const w = DIMENSION_WEIGHTS[dim];
      weightedSqSum += w * diff * diff;
      totalWeight += w;
    }
    const euclideanDistance = Math.sqrt(weightedSqSum / totalWeight);

    // 2. Context & Sensory Compatibility Adjustments (lower penalty = better fit)
    const textureMatch = cand.texture.toLowerCase() === sourceSnack.texture.toLowerCase();
    const tasteMatch = cand.tasteProfile.toLowerCase() === sourceSnack.tasteProfile.toLowerCase();
    const sameCategory = cand.category === sourceSnack.category;

    let contextPenalty = 0;
    if (!textureMatch) contextPenalty += 0.14;
    if (!tasteMatch) contextPenalty += 0.12;
    if (!sameCategory) contextPenalty += 0.05;

    // Affordability penalty if replacement is dramatically more expensive than original
    const priceGap = Math.max(0, cand.priceInrMin - sourceSnack.priceInrMax);
    if (priceGap > 30) {
      contextPenalty += Math.min(0.15, (priceGap - 30) / 200);
    }

    // 3. Curated SwapRule boost (ensures domain-authentic pairings like Potato Chips -> Roasted Makhana rank appropriately)
    const rule = ruleMap.get(cand.id);
    const ruleBoost = rule ? rule.priorityBoost : 0;

    // Penalize candidates that aren't actually nutritionally better on calories/grade
    const gradeImprovement = sourceNut.gradeScore - candNut.gradeScore;
    const gradePenalty = gradeImprovement <= 0 ? 0.3 : 0;

    const effectiveDistance = Math.max(
      0.01,
      euclideanDistance + contextPenalty + gradePenalty - ruleBoost
    );

    const matchScore = Math.max(
      15,
      Math.min(99, Math.round((1 - Math.min(0.85, effectiveDistance)) * 100))
    );

    // Build real dynamic nutritional advantages per 100g/ml
    const advantages: string[] = [];
    const calDiff = Math.round(sourceNut.calories - candNut.calories);
    if (calDiff >= 15) {
      advantages.push(`${calDiff} fewer kcal per 100${cand.servingUnit}`);
    }
    const satDiff = Number((sourceNut.saturatedFat - candNut.saturatedFat).toFixed(1));
    if (satDiff >= 1.0) {
      advantages.push(`${satDiff}g less saturated fat`);
    }
    const sugDiff = Number((sourceNut.sugar - candNut.sugar).toFixed(1));
    if (sugDiff >= 2.0) {
      advantages.push(`${sugDiff}g less sugar`);
    }
    const sodDiff = Math.round(sourceNut.sodium - candNut.sodium);
    if (sodDiff >= 50) {
      advantages.push(`${sodDiff}mg less sodium`);
    }
    const protDiff = Number((candNut.protein - sourceNut.protein).toFixed(1));
    if (protDiff >= 1.0) {
      advantages.push(`+${protDiff}g protein per 100${cand.servingUnit}`);
    }
    const fibDiff = Number((candNut.fiber - sourceNut.fiber).toFixed(1));
    if (fibDiff >= 1.0) {
      advantages.push(`+${fibDiff}g dietary fiber`);
    }
    if (advantages.length === 0) {
      advantages.push(`Improved overall Nutri-Score (${sourceNut.healthGrade} → ${candNut.healthGrade})`);
    }

    const sensoryBits: string[] = [];
    if (textureMatch) sensoryBits.push(`preserves a ${cand.texture} bite`);
    if (tasteMatch) sensoryBits.push(`keeps a ${cand.tasteProfile} flavor profile`);
    if (cand.priceInrMax <= 40) sensoryBits.push(`stays budget-friendly (₹${cand.priceInrMin}–₹${cand.priceInrMax})`);

    const whySuitable = rule
      ? rule.rationale
      : `Matches via normalized nutritional distance (d=${euclideanDistance.toFixed(2)})${
          sensoryBits.length > 0 ? `, ${sensoryBits.join(', ')},` : ''
        } and upgrades Grade ${sourceNut.healthGrade} to Grade ${candNut.healthGrade}.`;

    return {
      snack: cand,
      matchScore,
      euclideanDistance: Number(euclideanDistance.toFixed(3)),
      priceRange: `₹${cand.priceInrMin}–₹${cand.priceInrMax}`,
      advantages: advantages.slice(0, 4),
      whySuitable,
      matchedDimensions: {
        textureMatch,
        tasteMatch,
        beverageMatch: candNut.isBeverage === sourceNut.isBeverage,
        curatedRule: Boolean(rule),
      },
    };
  });

  scored.sort((a, b) => {
    if (b.matchScore !== a.matchScore) return b.matchScore - a.matchScore;
    return a.euclideanDistance - b.euclideanDistance;
  });

  return scored.slice(0, limit);
}
