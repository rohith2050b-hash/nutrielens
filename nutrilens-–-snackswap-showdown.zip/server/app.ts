import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { errorHandler } from './middleware/errorHandler.ts';
import { apiRouter } from './routes/api.ts';
import { sendError } from './utils/apiResponse.ts';

export function createApp() {
  const app = express();

  const allowedOrigins = process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim())
    : true;

  app.use(
    cors({
      origin: allowedOrigins,
      credentials: true,
    })
  );

  app.use(express.json({ limit: '100kb' }));

  const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => process.env.NODE_ENV === 'test',
    handler: (_req, res) => {
      return sendError(
        res,
        429,
        'RATE_LIMITED',
        'Too many requests. Please wait a moment before trying again.'
      );
    },
  });

  app.use('/api', apiLimiter, apiRouter);

  app.use('/api/*', (_req, res) => {
    return sendError(res, 404, 'ENDPOINT_NOT_FOUND', 'API endpoint not found.');
  });

  app.use(errorHandler);

  return app;
}
