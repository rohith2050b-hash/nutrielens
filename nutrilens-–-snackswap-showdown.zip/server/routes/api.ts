import { Router } from 'express';
import {
  compareSnacksController,
  getRecommendationsController,
  getSnackDetailController,
  listSnacksController,
} from '../controllers/snackController.ts';
import {
  createSwapController,
  deleteSwapController,
  getBarcodeController,
  getChallengesController,
  getDashboardController,
  getHostelHacksController,
  listSwapsController,
  postChallengeProgressController,
} from '../controllers/trackerController.ts';
import {
  validateBody,
  validateParams,
  validateQuery,
} from '../middleware/validate.ts';
import {
  barcodeParamSchema,
  challengeProgressSchema,
  compareRequestSchema,
  createSwapSchema,
  snackQuerySchema,
} from '../utils/zodSchemas.ts';
import { sendSuccess } from '../utils/apiResponse.ts';

export const apiRouter = Router();

apiRouter.get('/health', (_req, res) => {
  return sendSuccess(res, { status: 'ok', service: 'nutrilens-api' });
});

// Snack Explorer & Nutrition Lookup
apiRouter.get('/snacks/search', validateQuery(snackQuerySchema), listSnacksController);
apiRouter.get('/snacks', validateQuery(snackQuerySchema), listSnacksController);
apiRouter.get('/snacks/:id/recommendations', getRecommendationsController);
apiRouter.get('/snacks/:id', getSnackDetailController);

// Comparison
apiRouter.post('/compare', validateBody(compareRequestSchema), compareSnacksController);

// Swaps Tracker
apiRouter.get('/swaps', listSwapsController);
apiRouter.post('/swaps', validateBody(createSwapSchema), createSwapController);
apiRouter.delete('/swaps/:id', deleteSwapController);

// Dashboard
apiRouter.get('/dashboard', getDashboardController);

// Weekly Challenge
apiRouter.get('/challenges', getChallengesController);
apiRouter.post(
  '/challenges/:id/progress',
  validateBody(challengeProgressSchema),
  postChallengeProgressController
);

// Barcode Scanner (Local + Open Food Facts)
apiRouter.get('/barcode/:code', validateParams(barcodeParamSchema), getBarcodeController);

// Hostel Room Snack Hacks
apiRouter.get('/hostel-hacks', getHostelHacksController);
