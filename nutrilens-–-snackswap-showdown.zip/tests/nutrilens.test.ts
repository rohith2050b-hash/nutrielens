import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.ts';
import { prisma } from '../server/db.ts';
import { evaluateNutritionGrade } from '../server/services/gradingService.ts';
import { calculateExerciseEquivalency } from '../server/services/exerciseService.ts';
import { compareSnacks } from '../server/services/comparisonService.ts';
import { recommendHealthySwaps } from '../server/services/recommendationService.ts';

const app = createApp();
const TEST_GUEST = `vitest-guest-${Date.now()}`;

describe('NutriLens Comprehensive Backend & Algorithm Suite', () => {
  afterAll(async () => {
    await prisma.user.deleteMany({ where: { guestKey: TEST_GUEST } });
    await prisma.$disconnect();
  });

  // 1. Snack Search & Nutritional Data Retrieval
  it('1. retrieves seeded catalog and searches Potato Chips accurately', async () => {
    const allRes = await request(app).get('/api/snacks?limit=50');
    expect(allRes.status).toBe(200);
    expect(allRes.body.success).toBe(true);
    expect(allRes.body.data.pagination.total).toBeGreaterThanOrEqual(40);

    const searchRes = await request(app).get('/api/snacks/search?q=Potato+Chips');
    expect(searchRes.status).toBe(200);
    expect(searchRes.body.data.items.length).toBeGreaterThanOrEqual(1);
    expect(searchRes.body.data.items[0].name).toBe('Potato Chips');
    expect(searchRes.body.data.items[0].nutrition.calories).toBe(536);
  });

  it('2. handles empty search input gracefully without failing', async () => {
    const res = await request(app).get('/api/snacks/search?q=');
    expect(res.status).toBe(200);
    expect(res.body.data.items.length).toBeGreaterThan(0);
  });

  // 3. Health Grading Algorithm
  it('3. grades Potato Chips poorly (D/E) and Roasted Salted Makhana / Water highly (A/B)', () => {
    const chipsGrade = evaluateNutritionGrade({
      calories: 536,
      totalFat: 34.6,
      saturatedFat: 10.9,
      carbohydrates: 52.9,
      sugar: 0.6,
      protein: 6.5,
      fiber: 4.4,
      sodium: 640,
      isBeverage: false,
    });
    expect(['D', 'E']).toContain(chipsGrade.healthGrade);
    expect(chipsGrade.trafficLights.find((t) => t.nutrient === 'Sodium')?.level).toBe('High');
    expect(chipsGrade.trafficLights.find((t) => t.nutrient === 'Saturated Fat')?.level).toBe('High');

    const makhanaGrade = evaluateNutritionGrade({
      calories: 352,
      totalFat: 1.8,
      saturatedFat: 0.3,
      carbohydrates: 73.5,
      sugar: 0.5,
      protein: 9.8,
      fiber: 7.8,
      sodium: 240,
      isBeverage: false,
    });
    expect(['A', 'B']).toContain(makhanaGrade.healthGrade);

    const waterGrade = evaluateNutritionGrade({
      calories: 3,
      totalFat: 0,
      saturatedFat: 0,
      carbohydrates: 0.8,
      sugar: 0.2,
      protein: 0.1,
      fiber: 0,
      sodium: 12,
      isBeverage: true,
    });
    expect(waterGrade.healthGrade).toBe('A');
  });

  it('4. rejects missing or invalid negative nutrition values in grading engine', () => {
    expect(() =>
      evaluateNutritionGrade({
        calories: -10,
        totalFat: 5,
        saturatedFat: 1,
        carbohydrates: 10,
        sugar: 1,
        protein: 2,
        fiber: 1,
        sodium: 50,
      })
    ).toThrow();
  });

  // 4 & 5. Nutritional Distance & Recommendations
  it('5. recommends Roasted Salted Makhana for Potato Chips using Euclidean distance', async () => {
    const recRes = await request(app).get('/api/snacks/potato-chips/recommendations');
    expect(recRes.status).toBe(200);
    const recs = recRes.body.data.recommendations;
    expect(recs.length).toBeGreaterThanOrEqual(2);
    expect(recs.some((r: { snack: { slug: string } }) => r.snack.slug === 'roasted-salted-makhana')).toBe(true);
    expect(recs[0].euclideanDistance).toBeGreaterThan(0);
    expect(recs[0].advantages.length).toBeGreaterThan(0);
  });

  it('6. filters recommendations directly by solid/beverage modality', async () => {
    const allSnacks = await prisma.snack.findMany({ include: { nutrition: true } });
    const cola = allSnacks.find((s) => s.slug === 'cola')!;
    const recs = recommendHealthySwaps(cola, allSnacks, [], 3);
    expect(recs.length).toBeGreaterThan(0);
    expect(recs.every((r) => r.snack.nutrition?.isBeverage === true)).toBe(true);
  });

  // 6. Nutritional Comparison Calculations
  it('7. computes accurate serving vs 100g comparison deltas and handles zero values', async () => {
    const chips = await prisma.snack.findUnique({ where: { slug: 'potato-chips' }, include: { nutrition: true } });
    const makhana = await prisma.snack.findUnique({ where: { slug: 'roasted-salted-makhana' }, include: { nutrition: true } });
    expect(chips).not.toBeNull();
    expect(makhana).not.toBeNull();

    const servingComp = compareSnacks(chips!, makhana!, 'serving');
    expect(servingComp.savings.caloriesSaved).toBeGreaterThan(40);
    expect(servingComp.savings.saturatedFatReduced).toBeGreaterThan(2);
    expect(servingComp.savings.proteinGained).toBeGreaterThan(0.5);

    const hundredGComp = compareSnacks(chips!, makhana!, '100g');
    expect(hundredGComp.snackA.scaledNutrition.calories).toBe(536);
    expect(hundredGComp.snackB.scaledNutrition.calories).toBe(352);
  });

  // 7. Exercise Equivalency (including zero calories edge case)
  it('8. computes MET-based exercise durations and handles zero calories safely', () => {
    const res = calculateExerciseEquivalency(260, 65);
    expect(res.activities).toHaveLength(3);
    const walking = res.activities.find((a) => a.key === 'walking')!;
    const jogging = res.activities.find((a) => a.key === 'jogging')!;
    expect(walking.minutes).toBeGreaterThan(jogging.minutes);

    const zeroRes = calculateExerciseEquivalency(0, 65);
    expect(zeroRes.activities.every((a) => a.minutes === 0)).toBe(true);
  });

  // 8 & 9. Swap Tracking, Duplicate Prevention & Dashboard Aggregation
  it('9. records a swap, prevents duplicate submission, updates dashboard, and supports undo', async () => {
    // Initially empty for fresh guest
    const initialDash = await request(app).get('/api/dashboard').set('x-guest-id', TEST_GUEST);
    expect(initialDash.status).toBe(200);
    expect(initialDash.body.data.swapSummary.totalSwaps).toBe(0);

    // Record Potato Chips -> Roasted Salted Makhana swap
    const swapRes = await request(app)
      .post('/api/swaps')
      .set('x-guest-id', TEST_GUEST)
      .send({
        originalSnackId: 'potato-chips',
        replacementSnackId: 'roasted-salted-makhana',
        basis: 'serving',
      });
    expect(swapRes.status).toBe(201);
    const swapId = swapRes.body.data.swapLog.id;
    expect(swapRes.body.data.swapLog.caloriesSaved).toBeGreaterThan(0);

    // Duplicate swap within 10s must return 409
    const dupRes = await request(app)
      .post('/api/swaps')
      .set('x-guest-id', TEST_GUEST)
      .send({
        originalSnackId: 'potato-chips',
        replacementSnackId: 'roasted-salted-makhana',
        basis: 'serving',
      });
    expect(dupRes.status).toBe(409);

    // Dashboard reflects updated totals & challenge progress
    const updatedDash = await request(app).get('/api/dashboard').set('x-guest-id', TEST_GUEST);
    expect(updatedDash.status).toBe(200);
    expect(updatedDash.body.data.swapSummary.totalSwaps).toBe(1);
    expect(updatedDash.body.data.swapSummary.caloriesSaved).toBeGreaterThan(0);
    expect(updatedDash.body.data.challengeSummary.completedCount).toBe(1);

    // Undo / Delete swap restores clean totals
    const delRes = await request(app)
      .delete(`/api/swaps/${swapId}`)
      .set('x-guest-id', TEST_GUEST);
    expect(delRes.status).toBe(200);

    const afterUndoDash = await request(app).get('/api/dashboard').set('x-guest-id', TEST_GUEST);
    expect(afterUndoDash.body.data.swapSummary.totalSwaps).toBe(0);
  });

  // 10. API Error Handling & Barcode Edge Cases
  it('10. returns structured 404/400/422/503 responses for invalid snack IDs, invalid barcodes, and missing OFF data', async () => {
    const missingSnack = await request(app).get('/api/snacks/non-existent-snack-999');
    expect(missingSnack.status).toBe(404);
    expect(missingSnack.body.success).toBe(false);

    const badBarcode = await request(app).get('/api/barcode/abc');
    expect(badBarcode.status).toBe(400);

    // Local verified barcode works directly
    const localBarcode = await request(app).get('/api/barcode/8901491101813');
    expect(localBarcode.status).toBe(200);
    expect(localBarcode.body.data.product.name).toBe('Potato Chips');

    // Mock Open Food Facts returning incomplete nutrition
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        status: 1,
        product: { product_name: 'Unlabelled Candy', nutriments: {} },
      }),
    } as Response);

    const incompleteBarcode = await request(app).get('/api/barcode/9999999999999');
    expect(incompleteBarcode.status).toBe(422);
    expect(incompleteBarcode.body.error.code).toBe('INCOMPLETE_NUTRITION');
    fetchSpy.mockRestore();

    // Mock Open Food Facts network outage
    const failSpy = vi.spyOn(globalThis, 'fetch').mockRejectedValueOnce(new Error('Network down'));
    const netFailBarcode = await request(app).get('/api/barcode/8888888888888');
    expect(netFailBarcode.status).toBe(503);
    expect(netFailBarcode.body.error.code).toBe('OFF_NETWORK_ERROR');
    failSpy.mockRestore();
  });
});
